﻿namespace PloidyInfer
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        
        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.RunButton = new System.Windows.Forms.ToolStripButton();
            this.AbortButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.ChainLenLabel = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel7 = new System.Windows.Forms.ToolStripLabel();
            this.FeedBackFreqBox = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.AboutButton = new System.Windows.Forms.ToolStripButton();
            this.ManualButton = new System.Windows.Forms.ToolStripButton();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.splitContainer7 = new System.Windows.Forms.SplitContainer();
            this.SimDRBox = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.SimDioeciousBox = new System.Windows.Forms.CheckBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.SimMaxFalseAllelesBox = new System.Windows.Forms.NumericUpDown();
            this.SimFalseAlleleRateaBox = new System.Windows.Forms.NumericUpDown();
            this.label39 = new System.Windows.Forms.Label();
            this.SimSampleRatioBOx = new System.Windows.Forms.NumericUpDown();
            this.SimFemaleRatioBox = new System.Windows.Forms.NumericUpDown();
            this.SimBetaBox = new System.Windows.Forms.NumericUpDown();
            this.SimSelfingRateBox = new System.Windows.Forms.NumericUpDown();
            this.label41 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.SimParBox = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.PhenotypeBox = new System.Windows.Forms.TextBox();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.FounderButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel4 = new System.Windows.Forms.ToolStripLabel();
            this.Reproduce1Button = new System.Windows.Forms.ToolStripButton();
            this.Reproduce10Button = new System.Windows.Forms.ToolStripButton();
            this.Reproduce100Button = new System.Windows.Forms.ToolStripButton();
            this.Reproduce1000Button = new System.Windows.Forms.ToolStripButton();
            this.ReproduceGstButton = new System.Windows.Forms.ToolStripButton();
            this.GstBox = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.SeedButton = new System.Windows.Forms.ToolStripButton();
            this.Seedbox = new System.Windows.Forms.ToolStripTextBox();
            this.GstLabel = new System.Windows.Forms.ToolStripLabel();
            this.GenLabel = new System.Windows.Forms.ToolStripLabel();
            this.App3Button = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.splitContainer5 = new System.Windows.Forms.SplitContainer();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.DrBox = new System.Windows.Forms.ComboBox();
            this.label57 = new System.Windows.Forms.Label();
            this.UpdatePrioriBox = new System.Windows.Forms.CheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.MaxIterationAssignBox = new System.Windows.Forms.ComboBox();
            this.MaxDiffAssignBox = new System.Windows.Forms.ComboBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.WarningBox = new System.Windows.Forms.CheckBox();
            this.PreHeightBox = new System.Windows.Forms.NumericUpDown();
            this.PicHeightBox = new System.Windows.Forms.NumericUpDown();
            this.PreWidthBox = new System.Windows.Forms.NumericUpDown();
            this.PicWidthBox = new System.Windows.Forms.NumericUpDown();
            this.DecimalBox = new System.Windows.Forms.NumericUpDown();
            this.label33 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.groupbox11 = new System.Windows.Forms.GroupBox();
            this.ThreadBox = new System.Windows.Forms.NumericUpDown();
            this.MaxFalseAllelesBox = new System.Windows.Forms.NumericUpDown();
            this.FalseAlleleRateBox = new System.Windows.Forms.NumericUpDown();
            this.SelfingBox = new System.Windows.Forms.CheckBox();
            this.BetaBox = new System.Windows.Forms.CheckBox();
            this.NullBox = new System.Windows.Forms.CheckBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.MaxDiffSimplexBox = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.MaxDiffFreqBox = new System.Windows.Forms.ComboBox();
            this.MaxIterationSimplexBox = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.MaxIterationFreqBox = new System.Windows.Forms.ComboBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.DebugOutput2 = new System.Windows.Forms.TextBox();
            this.DebugOutput1 = new System.Windows.Forms.TextBox();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.PosterProbBox = new System.Windows.Forms.TextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.ModelInfoBox = new System.Windows.Forms.TextBox();
            this.splitContainer6 = new System.Windows.Forms.SplitContainer();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.PreviewBox = new System.Windows.Forms.PictureBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.AFOutBox = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button18 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.PicBox = new System.Windows.Forms.PictureBox();
            this.toolStrip4 = new System.Windows.Forms.ToolStrip();
            this.SortButton = new System.Windows.Forms.ToolStripButton();
            this.SortPButton = new System.Windows.Forms.ToolStripButton();
            this.SortOriButton = new System.Windows.Forms.ToolStripButton();
            this.SaveImageButton = new System.Windows.Forms.ToolStripButton();
            this.PrintButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.Iter1Button = new System.Windows.Forms.ToolStripButton();
            this.Iter5Button = new System.Windows.Forms.ToolStripButton();
            this.Iter20Button = new System.Windows.Forms.ToolStripButton();
            this.Iter100Button = new System.Windows.Forms.ToolStripButton();
            this.IterResetButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.BottomToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.TopToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.RightToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.LeftToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.ContentPanel = new System.Windows.Forms.ToolStripContentPanel();
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.toolStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).BeginInit();
            this.splitContainer7.Panel1.SuspendLayout();
            this.splitContainer7.Panel2.SuspendLayout();
            this.splitContainer7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SimMaxFalseAllelesBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimFalseAlleleRateaBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimSampleRatioBOx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimFemaleRatioBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimBetaBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimSelfingRateBox)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).BeginInit();
            this.splitContainer5.Panel1.SuspendLayout();
            this.splitContainer5.Panel2.SuspendLayout();
            this.splitContainer5.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PreHeightBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicHeightBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PreWidthBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicWidthBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DecimalBox)).BeginInit();
            this.groupbox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ThreadBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MaxFalseAllelesBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FalseAlleleRateBox)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).BeginInit();
            this.splitContainer6.Panel1.SuspendLayout();
            this.splitContainer6.Panel2.SuspendLayout();
            this.splitContainer6.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PreviewBox)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox)).BeginInit();
            this.toolStrip4.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RunButton,
            this.AbortButton,
            this.toolStripSeparator4,
            this.toolStripProgressBar1,
            this.toolStripSeparator10,
            this.ChainLenLabel,
            this.toolStripSeparator11,
            this.toolStripLabel7,
            this.FeedBackFreqBox,
            this.toolStripSeparator1,
            this.AboutButton,
            this.ManualButton});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.toolStrip1.Size = new System.Drawing.Size(1300, 30);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // RunButton
            // 
            this.RunButton.BackColor = System.Drawing.Color.Cornsilk;
            this.RunButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.RunButton.Image = ((System.Drawing.Image)(resources.GetObject("RunButton.Image")));
            this.RunButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.RunButton.Name = "RunButton";
            this.RunButton.Size = new System.Drawing.Size(38, 27);
            this.RunButton.Text = "&Run";
            this.RunButton.Click += new System.EventHandler(this.Run);
            // 
            // AbortButton
            // 
            this.AbortButton.BackColor = System.Drawing.Color.Cornsilk;
            this.AbortButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AbortButton.Image = ((System.Drawing.Image)(resources.GetObject("AbortButton.Image")));
            this.AbortButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AbortButton.Name = "AbortButton";
            this.AbortButton.Size = new System.Drawing.Size(51, 27);
            this.AbortButton.Text = "A&bort";
            this.AbortButton.Click += new System.EventHandler(this.Abort);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 30);
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(267, 27);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(6, 30);
            // 
            // ChainLenLabel
            // 
            this.ChainLenLabel.Name = "ChainLenLabel";
            this.ChainLenLabel.Size = new System.Drawing.Size(77, 27);
            this.ChainLenLabel.Text = "Chain len: ";
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(6, 30);
            // 
            // toolStripLabel7
            // 
            this.toolStripLabel7.Name = "toolStripLabel7";
            this.toolStripLabel7.Size = new System.Drawing.Size(106, 27);
            this.toolStripLabel7.Text = "Feedback freq.";
            // 
            // FeedBackFreqBox
            // 
            this.FeedBackFreqBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.FeedBackFreqBox.Items.AddRange(new object[] {
            "per 1 iter",
            "per 2 iter",
            "per 5 iter",
            "per 10 iter",
            "per 20 iter",
            "per 50 iter",
            "per 100 iter",
            "never"});
            this.FeedBackFreqBox.Name = "FeedBackFreqBox";
            this.FeedBackFreqBox.Size = new System.Drawing.Size(98, 30);
            this.FeedBackFreqBox.SelectedIndexChanged += new System.EventHandler(this.UpdateFeedBack);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 30);
            // 
            // AboutButton
            // 
            this.AboutButton.BackColor = System.Drawing.Color.Cornsilk;
            this.AboutButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AboutButton.Image = ((System.Drawing.Image)(resources.GetObject("AboutButton.Image")));
            this.AboutButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AboutButton.Name = "AboutButton";
            this.AboutButton.Size = new System.Drawing.Size(54, 27);
            this.AboutButton.Text = "&About";
            this.AboutButton.Click += new System.EventHandler(this.About);
            // 
            // ManualButton
            // 
            this.ManualButton.BackColor = System.Drawing.Color.Cornsilk;
            this.ManualButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ManualButton.Image = ((System.Drawing.Image)(resources.GetObject("ManualButton.Image")));
            this.ManualButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ManualButton.Name = "ManualButton";
            this.ManualButton.Size = new System.Drawing.Size(62, 27);
            this.ManualButton.Text = "&Manual";
            this.ManualButton.Click += new System.EventHandler(this.toolStripButton6_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 30;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 30);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1300, 805);
            this.tabControl1.TabIndex = 1;
            this.tabControl1.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabControl1_Selected);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.splitContainer2);
            this.tabPage1.Controls.Add(this.toolStrip2);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tabPage1.Size = new System.Drawing.Size(1292, 776);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Input";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer2.Location = new System.Drawing.Point(4, 31);
            this.splitContainer2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.groupBox1);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.groupBox2);
            this.splitContainer2.Size = new System.Drawing.Size(1284, 742);
            this.splitContainer2.SplitterDistance = 248;
            this.splitContainer2.SplitterWidth = 5;
            this.splitContainer2.TabIndex = 5;
            this.splitContainer2.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.SaveFile);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.splitContainer7);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox1.Size = new System.Drawing.Size(1284, 248);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Simulation parameters";
            // 
            // splitContainer7
            // 
            this.splitContainer7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer7.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer7.Location = new System.Drawing.Point(4, 21);
            this.splitContainer7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.splitContainer7.Name = "splitContainer7";
            // 
            // splitContainer7.Panel1
            // 
            this.splitContainer7.Panel1.Controls.Add(this.SimDRBox);
            this.splitContainer7.Panel1.Controls.Add(this.label13);
            this.splitContainer7.Panel1.Controls.Add(this.SimDioeciousBox);
            this.splitContainer7.Panel1.Controls.Add(this.label30);
            this.splitContainer7.Panel1.Controls.Add(this.label14);
            this.splitContainer7.Panel1.Controls.Add(this.label37);
            this.splitContainer7.Panel1.Controls.Add(this.SimMaxFalseAllelesBox);
            this.splitContainer7.Panel1.Controls.Add(this.SimFalseAlleleRateaBox);
            this.splitContainer7.Panel1.Controls.Add(this.label39);
            this.splitContainer7.Panel1.Controls.Add(this.SimSampleRatioBOx);
            this.splitContainer7.Panel1.Controls.Add(this.SimFemaleRatioBox);
            this.splitContainer7.Panel1.Controls.Add(this.SimBetaBox);
            this.splitContainer7.Panel1.Controls.Add(this.SimSelfingRateBox);
            this.splitContainer7.Panel1.Controls.Add(this.label41);
            this.splitContainer7.Panel1.Controls.Add(this.label36);
            // 
            // splitContainer7.Panel2
            // 
            this.splitContainer7.Panel2.Controls.Add(this.SimParBox);
            this.splitContainer7.Size = new System.Drawing.Size(1276, 224);
            this.splitContainer7.SplitterDistance = 275;
            this.splitContainer7.TabIndex = 3;
            // 
            // SimDRBox
            // 
            this.SimDRBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SimDRBox.FormattingEnabled = true;
            this.SimDRBox.Items.AddRange(new object[] {
            "RCS",
            "PRCS",
            "CES",
            "PES_0.25",
            "PES_0.5",
            "PES_rand (0~100 cM)"});
            this.SimDRBox.Location = new System.Drawing.Point(167, 240);
            this.SimDRBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.SimDRBox.Name = "SimDRBox";
            this.SimDRBox.Size = new System.Drawing.Size(173, 23);
            this.SimDRBox.TabIndex = 403;
            this.SimDRBox.SelectedIndexChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(14, 242);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(135, 15);
            this.label13.TabIndex = 401;
            this.label13.Text = "Double-reduction";
            // 
            // SimDioeciousBox
            // 
            this.SimDioeciousBox.AutoSize = true;
            this.SimDioeciousBox.Location = new System.Drawing.Point(16, 12);
            this.SimDioeciousBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.SimDioeciousBox.Name = "SimDioeciousBox";
            this.SimDioeciousBox.Size = new System.Drawing.Size(101, 19);
            this.SimDioeciousBox.TabIndex = 203;
            this.SimDioeciousBox.Text = "Dioecious";
            this.SimDioeciousBox.UseVisualStyleBackColor = true;
            this.SimDioeciousBox.CheckedChanged += new System.EventHandler(this.DioeciousBox_CheckedChanged);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(14, 175);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(143, 15);
            this.label30.TabIndex = 0;
            this.label30.Text = "Max false alleles";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(14, 142);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(143, 15);
            this.label14.TabIndex = 0;
            this.label14.Text = "False allele rate";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(14, 108);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(119, 15);
            this.label37.TabIndex = 0;
            this.label37.Text = "Sampling ratio";
            // 
            // SimMaxFalseAllelesBox
            // 
            this.SimMaxFalseAllelesBox.Location = new System.Drawing.Point(206, 173);
            this.SimMaxFalseAllelesBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.SimMaxFalseAllelesBox.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.SimMaxFalseAllelesBox.Name = "SimMaxFalseAllelesBox";
            this.SimMaxFalseAllelesBox.Size = new System.Drawing.Size(132, 25);
            this.SimMaxFalseAllelesBox.TabIndex = 205;
            this.SimMaxFalseAllelesBox.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.SimMaxFalseAllelesBox.ValueChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // SimFalseAlleleRateaBox
            // 
            this.SimFalseAlleleRateaBox.DecimalPlaces = 4;
            this.SimFalseAlleleRateaBox.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.SimFalseAlleleRateaBox.Location = new System.Drawing.Point(206, 140);
            this.SimFalseAlleleRateaBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.SimFalseAlleleRateaBox.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.SimFalseAlleleRateaBox.Name = "SimFalseAlleleRateaBox";
            this.SimFalseAlleleRateaBox.Size = new System.Drawing.Size(132, 25);
            this.SimFalseAlleleRateaBox.TabIndex = 205;
            this.SimFalseAlleleRateaBox.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.SimFalseAlleleRateaBox.ValueChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(14, 42);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(103, 15);
            this.label39.TabIndex = 0;
            this.label39.Text = "Female ratio";
            // 
            // SimSampleRatioBOx
            // 
            this.SimSampleRatioBOx.DecimalPlaces = 4;
            this.SimSampleRatioBOx.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.SimSampleRatioBOx.Location = new System.Drawing.Point(206, 107);
            this.SimSampleRatioBOx.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.SimSampleRatioBOx.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.SimSampleRatioBOx.Name = "SimSampleRatioBOx";
            this.SimSampleRatioBOx.Size = new System.Drawing.Size(132, 25);
            this.SimSampleRatioBOx.TabIndex = 205;
            this.SimSampleRatioBOx.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.SimSampleRatioBOx.ValueChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // SimFemaleRatioBox
            // 
            this.SimFemaleRatioBox.DecimalPlaces = 4;
            this.SimFemaleRatioBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.SimFemaleRatioBox.Location = new System.Drawing.Point(206, 40);
            this.SimFemaleRatioBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.SimFemaleRatioBox.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            131072});
            this.SimFemaleRatioBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.SimFemaleRatioBox.Name = "SimFemaleRatioBox";
            this.SimFemaleRatioBox.Size = new System.Drawing.Size(132, 25);
            this.SimFemaleRatioBox.TabIndex = 201;
            this.SimFemaleRatioBox.Value = new decimal(new int[] {
            99,
            0,
            0,
            131072});
            this.SimFemaleRatioBox.ValueChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // SimBetaBox
            // 
            this.SimBetaBox.DecimalPlaces = 4;
            this.SimBetaBox.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.SimBetaBox.Location = new System.Drawing.Point(206, 207);
            this.SimBetaBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.SimBetaBox.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.SimBetaBox.Name = "SimBetaBox";
            this.SimBetaBox.Size = new System.Drawing.Size(132, 25);
            this.SimBetaBox.TabIndex = 202;
            this.SimBetaBox.ValueChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // SimSelfingRateBox
            // 
            this.SimSelfingRateBox.DecimalPlaces = 4;
            this.SimSelfingRateBox.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.SimSelfingRateBox.Location = new System.Drawing.Point(206, 73);
            this.SimSelfingRateBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.SimSelfingRateBox.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.SimSelfingRateBox.Name = "SimSelfingRateBox";
            this.SimSelfingRateBox.Size = new System.Drawing.Size(132, 25);
            this.SimSelfingRateBox.TabIndex = 202;
            this.SimSelfingRateBox.ValueChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(14, 208);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(191, 15);
            this.label41.TabIndex = 0;
            this.label41.Text = "Neg. amplification rate";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(14, 75);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(103, 15);
            this.label36.TabIndex = 0;
            this.label36.Text = "Selfing rate";
            // 
            // SimParBox
            // 
            this.SimParBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SimParBox.HideSelection = false;
            this.SimParBox.Location = new System.Drawing.Point(0, 0);
            this.SimParBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.SimParBox.MaxLength = 32767000;
            this.SimParBox.Multiline = true;
            this.SimParBox.Name = "SimParBox";
            this.SimParBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.SimParBox.Size = new System.Drawing.Size(997, 224);
            this.SimParBox.TabIndex = 2;
            this.SimParBox.Text = resources.GetString("SimParBox.Text");
            this.SimParBox.WordWrap = false;
            this.SimParBox.TextChanged += new System.EventHandler(this.PreSaveFile);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.PhenotypeBox);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox2.Size = new System.Drawing.Size(1284, 489);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Input phenotypes";
            // 
            // PhenotypeBox
            // 
            this.PhenotypeBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PhenotypeBox.HideSelection = false;
            this.PhenotypeBox.Location = new System.Drawing.Point(4, 21);
            this.PhenotypeBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.PhenotypeBox.MaxLength = 32767000;
            this.PhenotypeBox.Multiline = true;
            this.PhenotypeBox.Name = "PhenotypeBox";
            this.PhenotypeBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.PhenotypeBox.Size = new System.Drawing.Size(1276, 465);
            this.PhenotypeBox.TabIndex = 1;
            this.PhenotypeBox.WordWrap = false;
            this.PhenotypeBox.TextChanged += new System.EventHandler(this.PreSaveFile);
            // 
            // toolStrip2
            // 
            this.toolStrip2.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FounderButton,
            this.toolStripSeparator3,
            this.toolStripLabel4,
            this.Reproduce1Button,
            this.Reproduce10Button,
            this.Reproduce100Button,
            this.Reproduce1000Button,
            this.ReproduceGstButton,
            this.GstBox,
            this.toolStripSeparator7,
            this.SeedButton,
            this.Seedbox,
            this.GstLabel,
            this.GenLabel,
            this.App3Button,
            this.toolStripButton1,
            this.toolStripButton2});
            this.toolStrip2.Location = new System.Drawing.Point(4, 3);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.toolStrip2.Size = new System.Drawing.Size(1284, 28);
            this.toolStrip2.TabIndex = 4;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // FounderButton
            // 
            this.FounderButton.BackColor = System.Drawing.Color.Cornsilk;
            this.FounderButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FounderButton.Image = ((System.Drawing.Image)(resources.GetObject("FounderButton.Image")));
            this.FounderButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.FounderButton.Name = "FounderButton";
            this.FounderButton.Size = new System.Drawing.Size(67, 25);
            this.FounderButton.Text = "&Founder";
            this.FounderButton.Click += new System.EventHandler(this.GenerateFounderPopulation);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripLabel4
            // 
            this.toolStripLabel4.Name = "toolStripLabel4";
            this.toolStripLabel4.Size = new System.Drawing.Size(88, 25);
            this.toolStripLabel4.Text = "Reproduce: ";
            // 
            // Reproduce1Button
            // 
            this.Reproduce1Button.BackColor = System.Drawing.Color.Cornsilk;
            this.Reproduce1Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Reproduce1Button.Image = ((System.Drawing.Image)(resources.GetObject("Reproduce1Button.Image")));
            this.Reproduce1Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Reproduce1Button.Name = "Reproduce1Button";
            this.Reproduce1Button.Size = new System.Drawing.Size(23, 25);
            this.Reproduce1Button.Text = "1";
            this.Reproduce1Button.Click += new System.EventHandler(this.ReproduceGenerations);
            // 
            // Reproduce10Button
            // 
            this.Reproduce10Button.BackColor = System.Drawing.Color.Cornsilk;
            this.Reproduce10Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Reproduce10Button.Image = ((System.Drawing.Image)(resources.GetObject("Reproduce10Button.Image")));
            this.Reproduce10Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Reproduce10Button.Name = "Reproduce10Button";
            this.Reproduce10Button.Size = new System.Drawing.Size(29, 25);
            this.Reproduce10Button.Text = "10";
            this.Reproduce10Button.Click += new System.EventHandler(this.ReproduceGenerations);
            // 
            // Reproduce100Button
            // 
            this.Reproduce100Button.BackColor = System.Drawing.Color.Cornsilk;
            this.Reproduce100Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Reproduce100Button.Image = ((System.Drawing.Image)(resources.GetObject("Reproduce100Button.Image")));
            this.Reproduce100Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Reproduce100Button.Name = "Reproduce100Button";
            this.Reproduce100Button.Size = new System.Drawing.Size(37, 25);
            this.Reproduce100Button.Text = "100";
            this.Reproduce100Button.Click += new System.EventHandler(this.ReproduceGenerations);
            // 
            // Reproduce1000Button
            // 
            this.Reproduce1000Button.BackColor = System.Drawing.Color.Cornsilk;
            this.Reproduce1000Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Reproduce1000Button.Image = ((System.Drawing.Image)(resources.GetObject("Reproduce1000Button.Image")));
            this.Reproduce1000Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Reproduce1000Button.Name = "Reproduce1000Button";
            this.Reproduce1000Button.Size = new System.Drawing.Size(45, 25);
            this.Reproduce1000Button.Text = "1000";
            this.Reproduce1000Button.Click += new System.EventHandler(this.ReproduceGenerations);
            // 
            // ReproduceGstButton
            // 
            this.ReproduceGstButton.BackColor = System.Drawing.Color.Cornsilk;
            this.ReproduceGstButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ReproduceGstButton.Image = ((System.Drawing.Image)(resources.GetObject("ReproduceGstButton.Image")));
            this.ReproduceGstButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ReproduceGstButton.Name = "ReproduceGstButton";
            this.ReproduceGstButton.Size = new System.Drawing.Size(85, 25);
            this.ReproduceGstButton.Text = "until Gst = ";
            this.ReproduceGstButton.Click += new System.EventHandler(this.ReproduceGst);
            // 
            // GstBox
            // 
            this.GstBox.Items.AddRange(new object[] {
            "0.01",
            "0.02",
            "0.05",
            "0.07",
            "0.10",
            "0.12",
            "0.15"});
            this.GstBox.Name = "GstBox";
            this.GstBox.Size = new System.Drawing.Size(98, 28);
            this.GstBox.Text = "0.05";
            this.GstBox.SelectedIndexChanged += new System.EventHandler(this.UpdateFeedBack);
            this.GstBox.TextChanged += new System.EventHandler(this.UpdateFeedBack);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 28);
            // 
            // SeedButton
            // 
            this.SeedButton.BackColor = System.Drawing.Color.Cornsilk;
            this.SeedButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SeedButton.Image = ((System.Drawing.Image)(resources.GetObject("SeedButton.Image")));
            this.SeedButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SeedButton.Name = "SeedButton";
            this.SeedButton.Size = new System.Drawing.Size(49, 25);
            this.SeedButton.Text = "Seed:";
            this.SeedButton.Click += new System.EventHandler(this.ChangeSeed);
            // 
            // Seedbox
            // 
            this.Seedbox.Name = "Seedbox";
            this.Seedbox.Size = new System.Drawing.Size(105, 28);
            this.Seedbox.TextChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // GstLabel
            // 
            this.GstLabel.Name = "GstLabel";
            this.GstLabel.Size = new System.Drawing.Size(37, 25);
            this.GstLabel.Text = "Gst: ";
            // 
            // GenLabel
            // 
            this.GenLabel.Name = "GenLabel";
            this.GenLabel.Size = new System.Drawing.Size(89, 25);
            this.GenLabel.Text = "Generation: ";
            // 
            // App3Button
            // 
            this.App3Button.BackColor = System.Drawing.Color.Cornsilk;
            this.App3Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.App3Button.Image = ((System.Drawing.Image)(resources.GetObject("App3Button.Image")));
            this.App3Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.App3Button.Name = "App3Button";
            this.App3Button.Size = new System.Drawing.Size(47, 25);
            this.App3Button.Text = "APP3";
            this.App3Button.Visible = false;
            this.App3Button.Click += new System.EventHandler(this.App3);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(117, 25);
            this.toolStripButton1.Text = "Run Commands";
            this.toolStripButton1.Visible = false;
            this.toolStripButton1.Click += new System.EventHandler(this.RunCommands);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(91, 25);
            this.toolStripButton2.Text = "Calc Results";
            this.toolStripButton2.Visible = false;
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.flowLayoutPanel1);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tabPage4.Size = new System.Drawing.Size(1292, 776);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Parameters";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Controls.Add(this.splitContainer5);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(4, 3);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(1284, 770);
            this.flowLayoutPanel1.TabIndex = 6;
            // 
            // splitContainer5
            // 
            this.splitContainer5.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer5.Location = new System.Drawing.Point(4, 3);
            this.splitContainer5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.splitContainer5.Name = "splitContainer5";
            // 
            // splitContainer5.Panel1
            // 
            this.splitContainer5.Panel1.Controls.Add(this.groupBox8);
            // 
            // splitContainer5.Panel2
            // 
            this.splitContainer5.Panel2.Controls.Add(this.groupBox12);
            this.splitContainer5.Panel2.Controls.Add(this.groupBox13);
            this.splitContainer5.Panel2.Controls.Add(this.groupbox11);
            this.splitContainer5.Size = new System.Drawing.Size(1099, 493);
            this.splitContainer5.SplitterDistance = 195;
            this.splitContainer5.SplitterWidth = 5;
            this.splitContainer5.TabIndex = 0;
            // 
            // groupBox8
            // 
            this.groupBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox8.Location = new System.Drawing.Point(0, 0);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox8.Size = new System.Drawing.Size(195, 493);
            this.groupBox8.TabIndex = 1;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Possible ploidies and prioris";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.label8);
            this.groupBox12.Controls.Add(this.DrBox);
            this.groupBox12.Controls.Add(this.label57);
            this.groupBox12.Controls.Add(this.UpdatePrioriBox);
            this.groupBox12.Controls.Add(this.label17);
            this.groupBox12.Controls.Add(this.label43);
            this.groupBox12.Controls.Add(this.label56);
            this.groupBox12.Controls.Add(this.label19);
            this.groupBox12.Controls.Add(this.MaxIterationAssignBox);
            this.groupBox12.Controls.Add(this.MaxDiffAssignBox);
            this.groupBox12.Location = new System.Drawing.Point(4, 3);
            this.groupBox12.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox12.Size = new System.Drawing.Size(290, 235);
            this.groupBox12.TabIndex = 1;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Ploidy assignment";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(176, 25);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 15);
            this.label8.TabIndex = 9;
            this.label8.Text = "(PES)";
            // 
            // DrBox
            // 
            this.DrBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.DrBox.FormattingEnabled = true;
            this.DrBox.Items.AddRange(new object[] {
            "RCS",
            "PRCS",
            "CES",
            "PES_0.25",
            "PES_0.5",
            "PES"});
            this.DrBox.Location = new System.Drawing.Point(45, 52);
            this.DrBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.DrBox.Name = "DrBox";
            this.DrBox.Size = new System.Drawing.Size(173, 23);
            this.DrBox.TabIndex = 400;
            this.DrBox.SelectedIndexChanged += new System.EventHandler(this.DrModeBox_SelectedIndexChanged);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(18, 140);
            this.label57.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(119, 15);
            this.label57.TabIndex = 2;
            this.label57.Text = "Max iterations";
            // 
            // UpdatePrioriBox
            // 
            this.UpdatePrioriBox.AutoSize = true;
            this.UpdatePrioriBox.Location = new System.Drawing.Point(20, 197);
            this.UpdatePrioriBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.UpdatePrioriBox.Name = "UpdatePrioriBox";
            this.UpdatePrioriBox.Size = new System.Drawing.Size(141, 19);
            this.UpdatePrioriBox.TabIndex = 300;
            this.UpdatePrioriBox.Text = "Update prioris";
            this.UpdatePrioriBox.UseVisualStyleBackColor = true;
            this.UpdatePrioriBox.CheckedChanged += new System.EventHandler(this.NullBox_CheckedChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(18, 85);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(167, 15);
            this.label17.TabIndex = 2;
            this.label17.Text = "Max assignment diff:";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(18, 25);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(151, 15);
            this.label43.TabIndex = 5;
            this.label43.Text = "Approximation mode";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(179, 165);
            this.label56.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(55, 15);
            this.label56.TabIndex = 2;
            this.label56.Text = "(1000)";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(179, 110);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(79, 15);
            this.label19.TabIndex = 2;
            this.label19.Text = "(0.00001)";
            // 
            // MaxIterationAssignBox
            // 
            this.MaxIterationAssignBox.FormattingEnabled = true;
            this.MaxIterationAssignBox.Items.AddRange(new object[] {
            "100",
            "200",
            "500",
            "1000",
            "2000",
            "5000",
            "10000"});
            this.MaxIterationAssignBox.Location = new System.Drawing.Point(45, 162);
            this.MaxIterationAssignBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaxIterationAssignBox.Name = "MaxIterationAssignBox";
            this.MaxIterationAssignBox.Size = new System.Drawing.Size(116, 23);
            this.MaxIterationAssignBox.TabIndex = 103;
            this.MaxIterationAssignBox.Text = "1000";
            this.MaxIterationAssignBox.SelectedIndexChanged += new System.EventHandler(this.UpdateParameters);
            this.MaxIterationAssignBox.TextChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // MaxDiffAssignBox
            // 
            this.MaxDiffAssignBox.FormattingEnabled = true;
            this.MaxDiffAssignBox.Items.AddRange(new object[] {
            "0.001",
            "0.0001",
            "0.00001",
            "0.000001",
            "0.0000001"});
            this.MaxDiffAssignBox.Location = new System.Drawing.Point(45, 107);
            this.MaxDiffAssignBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaxDiffAssignBox.Name = "MaxDiffAssignBox";
            this.MaxDiffAssignBox.Size = new System.Drawing.Size(116, 23);
            this.MaxDiffAssignBox.TabIndex = 102;
            this.MaxDiffAssignBox.Text = "0.00001";
            this.MaxDiffAssignBox.SelectedIndexChanged += new System.EventHandler(this.UpdateParameters);
            this.MaxDiffAssignBox.TextChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.WarningBox);
            this.groupBox13.Controls.Add(this.PreHeightBox);
            this.groupBox13.Controls.Add(this.PicHeightBox);
            this.groupBox13.Controls.Add(this.PreWidthBox);
            this.groupBox13.Controls.Add(this.PicWidthBox);
            this.groupBox13.Controls.Add(this.DecimalBox);
            this.groupBox13.Controls.Add(this.label33);
            this.groupBox13.Controls.Add(this.label21);
            this.groupBox13.Controls.Add(this.label34);
            this.groupBox13.Controls.Add(this.label22);
            this.groupBox13.Controls.Add(this.label20);
            this.groupBox13.Location = new System.Drawing.Point(4, 245);
            this.groupBox13.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox13.Size = new System.Drawing.Size(290, 247);
            this.groupBox13.TabIndex = 5;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Output";
            // 
            // WarningBox
            // 
            this.WarningBox.AutoSize = true;
            this.WarningBox.Location = new System.Drawing.Point(16, 217);
            this.WarningBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.WarningBox.Name = "WarningBox";
            this.WarningBox.Size = new System.Drawing.Size(141, 19);
            this.WarningBox.TabIndex = 505;
            this.WarningBox.Text = "Enable warning";
            this.WarningBox.UseVisualStyleBackColor = true;
            this.WarningBox.CheckedChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // PreHeightBox
            // 
            this.PreHeightBox.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.PreHeightBox.Location = new System.Drawing.Point(156, 178);
            this.PreHeightBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.PreHeightBox.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.PreHeightBox.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.PreHeightBox.Name = "PreHeightBox";
            this.PreHeightBox.Size = new System.Drawing.Size(99, 25);
            this.PreHeightBox.TabIndex = 504;
            this.PreHeightBox.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.PreHeightBox.ValueChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // PicHeightBox
            // 
            this.PicHeightBox.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.PicHeightBox.Location = new System.Drawing.Point(156, 103);
            this.PicHeightBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.PicHeightBox.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.PicHeightBox.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.PicHeightBox.Name = "PicHeightBox";
            this.PicHeightBox.Size = new System.Drawing.Size(99, 25);
            this.PicHeightBox.TabIndex = 502;
            this.PicHeightBox.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.PicHeightBox.ValueChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // PreWidthBox
            // 
            this.PreWidthBox.Increment = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.PreWidthBox.Location = new System.Drawing.Point(156, 142);
            this.PreWidthBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.PreWidthBox.Maximum = new decimal(new int[] {
            50000,
            0,
            0,
            0});
            this.PreWidthBox.Minimum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.PreWidthBox.Name = "PreWidthBox";
            this.PreWidthBox.Size = new System.Drawing.Size(99, 25);
            this.PreWidthBox.TabIndex = 503;
            this.PreWidthBox.Value = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.PreWidthBox.ValueChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // PicWidthBox
            // 
            this.PicWidthBox.Increment = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.PicWidthBox.Location = new System.Drawing.Point(156, 67);
            this.PicWidthBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.PicWidthBox.Maximum = new decimal(new int[] {
            50000,
            0,
            0,
            0});
            this.PicWidthBox.Minimum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.PicWidthBox.Name = "PicWidthBox";
            this.PicWidthBox.Size = new System.Drawing.Size(99, 25);
            this.PicWidthBox.TabIndex = 501;
            this.PicWidthBox.Value = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.PicWidthBox.ValueChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // DecimalBox
            // 
            this.DecimalBox.Location = new System.Drawing.Point(156, 28);
            this.DecimalBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.DecimalBox.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.DecimalBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.DecimalBox.Name = "DecimalBox";
            this.DecimalBox.Size = new System.Drawing.Size(99, 25);
            this.DecimalBox.TabIndex = 500;
            this.DecimalBox.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.DecimalBox.ValueChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(13, 182);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(119, 15);
            this.label33.TabIndex = 0;
            this.label33.Text = "Preview height";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(13, 143);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(111, 15);
            this.label21.TabIndex = 0;
            this.label21.Text = "Preview width";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(13, 107);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(119, 15);
            this.label34.TabIndex = 0;
            this.label34.Text = "Picture height";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(13, 68);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(111, 15);
            this.label22.TabIndex = 0;
            this.label22.Text = "Picture width";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(13, 32);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(119, 15);
            this.label20.TabIndex = 0;
            this.label20.Text = "Decimal places";
            // 
            // groupbox11
            // 
            this.groupbox11.Controls.Add(this.ThreadBox);
            this.groupbox11.Controls.Add(this.MaxFalseAllelesBox);
            this.groupbox11.Controls.Add(this.FalseAlleleRateBox);
            this.groupbox11.Controls.Add(this.SelfingBox);
            this.groupbox11.Controls.Add(this.BetaBox);
            this.groupbox11.Controls.Add(this.NullBox);
            this.groupbox11.Controls.Add(this.label38);
            this.groupbox11.Controls.Add(this.label12);
            this.groupbox11.Controls.Add(this.label16);
            this.groupbox11.Controls.Add(this.label11);
            this.groupbox11.Controls.Add(this.label32);
            this.groupbox11.Controls.Add(this.label55);
            this.groupbox11.Controls.Add(this.MaxDiffSimplexBox);
            this.groupbox11.Controls.Add(this.label28);
            this.groupbox11.Controls.Add(this.label10);
            this.groupbox11.Controls.Add(this.MaxDiffFreqBox);
            this.groupbox11.Controls.Add(this.MaxIterationSimplexBox);
            this.groupbox11.Controls.Add(this.label18);
            this.groupbox11.Controls.Add(this.MaxIterationFreqBox);
            this.groupbox11.Controls.Add(this.label35);
            this.groupbox11.Controls.Add(this.label15);
            this.groupbox11.Controls.Add(this.label9);
            this.groupbox11.Controls.Add(this.label31);
            this.groupbox11.Controls.Add(this.label54);
            this.groupbox11.Location = new System.Drawing.Point(301, 3);
            this.groupbox11.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupbox11.Name = "groupbox11";
            this.groupbox11.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupbox11.Size = new System.Drawing.Size(285, 487);
            this.groupbox11.TabIndex = 3;
            this.groupbox11.TabStop = false;
            this.groupbox11.Text = "Allele frequency estimator";
            // 
            // ThreadBox
            // 
            this.ThreadBox.Location = new System.Drawing.Point(66, 443);
            this.ThreadBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.ThreadBox.Maximum = new decimal(new int[] {
            32,
            0,
            0,
            0});
            this.ThreadBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ThreadBox.Name = "ThreadBox";
            this.ThreadBox.Size = new System.Drawing.Size(114, 25);
            this.ThreadBox.TabIndex = 503;
            this.ThreadBox.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.ThreadBox.ValueChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // MaxFalseAllelesBox
            // 
            this.MaxFalseAllelesBox.Location = new System.Drawing.Point(66, 287);
            this.MaxFalseAllelesBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaxFalseAllelesBox.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.MaxFalseAllelesBox.Name = "MaxFalseAllelesBox";
            this.MaxFalseAllelesBox.Size = new System.Drawing.Size(114, 25);
            this.MaxFalseAllelesBox.TabIndex = 503;
            this.MaxFalseAllelesBox.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.MaxFalseAllelesBox.ValueChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // FalseAlleleRateBox
            // 
            this.FalseAlleleRateBox.DecimalPlaces = 4;
            this.FalseAlleleRateBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.FalseAlleleRateBox.Location = new System.Drawing.Point(68, 237);
            this.FalseAlleleRateBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.FalseAlleleRateBox.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.FalseAlleleRateBox.Name = "FalseAlleleRateBox";
            this.FalseAlleleRateBox.Size = new System.Drawing.Size(114, 25);
            this.FalseAlleleRateBox.TabIndex = 503;
            this.FalseAlleleRateBox.Value = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.FalseAlleleRateBox.ValueChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // SelfingBox
            // 
            this.SelfingBox.AutoSize = true;
            this.SelfingBox.Location = new System.Drawing.Point(20, 83);
            this.SelfingBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.SelfingBox.Name = "SelfingBox";
            this.SelfingBox.Size = new System.Drawing.Size(157, 19);
            this.SelfingBox.TabIndex = 300;
            this.SelfingBox.Text = "Consider selfing";
            this.SelfingBox.UseVisualStyleBackColor = true;
            this.SelfingBox.CheckedChanged += new System.EventHandler(this.NullBox_CheckedChanged);
            // 
            // BetaBox
            // 
            this.BetaBox.AutoSize = true;
            this.BetaBox.Location = new System.Drawing.Point(20, 57);
            this.BetaBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BetaBox.Name = "BetaBox";
            this.BetaBox.Size = new System.Drawing.Size(197, 19);
            this.BetaBox.TabIndex = 300;
            this.BetaBox.Text = "Consider negative PCR";
            this.BetaBox.UseVisualStyleBackColor = true;
            this.BetaBox.CheckedChanged += new System.EventHandler(this.NullBox_CheckedChanged);
            // 
            // NullBox
            // 
            this.NullBox.AutoSize = true;
            this.NullBox.Location = new System.Drawing.Point(20, 28);
            this.NullBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.NullBox.Name = "NullBox";
            this.NullBox.Size = new System.Drawing.Size(197, 19);
            this.NullBox.TabIndex = 300;
            this.NullBox.Text = "Consider null alleles";
            this.NullBox.UseVisualStyleBackColor = true;
            this.NullBox.CheckedChanged += new System.EventHandler(this.NullBox_CheckedChanged);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(188, 447);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(31, 15);
            this.label38.TabIndex = 2;
            this.label38.Text = "(2)";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(18, 320);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(111, 15);
            this.label12.TabIndex = 2;
            this.label12.Text = "Max rs/s diff";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(18, 112);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(175, 15);
            this.label16.TabIndex = 2;
            this.label16.Text = "Max allele freq. diff";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(188, 395);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(47, 15);
            this.label11.TabIndex = 2;
            this.label11.Text = "(100)";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(188, 290);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(31, 15);
            this.label32.TabIndex = 2;
            this.label32.Text = "(2)";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(188, 187);
            this.label55.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(47, 15);
            this.label55.TabIndex = 2;
            this.label55.Text = "(100)";
            // 
            // MaxDiffSimplexBox
            // 
            this.MaxDiffSimplexBox.FormattingEnabled = true;
            this.MaxDiffSimplexBox.Items.AddRange(new object[] {
            "0.01",
            "0.003",
            "0.001",
            "0.0003",
            "0.0001",
            "0.00003",
            "0.00001",
            "0.000003",
            "0.000001",
            "0.0000003",
            "0.0000001"});
            this.MaxDiffSimplexBox.Location = new System.Drawing.Point(68, 342);
            this.MaxDiffSimplexBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaxDiffSimplexBox.Name = "MaxDiffSimplexBox";
            this.MaxDiffSimplexBox.Size = new System.Drawing.Size(111, 23);
            this.MaxDiffSimplexBox.TabIndex = 100;
            this.MaxDiffSimplexBox.Text = "0.001";
            this.MaxDiffSimplexBox.SelectedIndexChanged += new System.EventHandler(this.UpdateParameters);
            this.MaxDiffSimplexBox.TextChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(188, 242);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(55, 15);
            this.label28.TabIndex = 2;
            this.label28.Text = "(0.01)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(188, 345);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 15);
            this.label10.TabIndex = 2;
            this.label10.Text = "(0.001)";
            // 
            // MaxDiffFreqBox
            // 
            this.MaxDiffFreqBox.FormattingEnabled = true;
            this.MaxDiffFreqBox.Items.AddRange(new object[] {
            "0.01",
            "0.003",
            "0.001",
            "0.0003",
            "0.0001",
            "0.00003",
            "0.00001",
            "0.000003",
            "0.000001",
            "0.0000003",
            "0.0000001"});
            this.MaxDiffFreqBox.Location = new System.Drawing.Point(68, 135);
            this.MaxDiffFreqBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaxDiffFreqBox.Name = "MaxDiffFreqBox";
            this.MaxDiffFreqBox.Size = new System.Drawing.Size(111, 23);
            this.MaxDiffFreqBox.TabIndex = 100;
            this.MaxDiffFreqBox.Text = "0.001";
            this.MaxDiffFreqBox.SelectedIndexChanged += new System.EventHandler(this.UpdateParameters);
            this.MaxDiffFreqBox.TextChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // MaxIterationSimplexBox
            // 
            this.MaxIterationSimplexBox.FormattingEnabled = true;
            this.MaxIterationSimplexBox.Items.AddRange(new object[] {
            "10",
            "20",
            "50",
            "100",
            "200",
            "500",
            "1000",
            "2000",
            "5000",
            "10000"});
            this.MaxIterationSimplexBox.Location = new System.Drawing.Point(68, 395);
            this.MaxIterationSimplexBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaxIterationSimplexBox.Name = "MaxIterationSimplexBox";
            this.MaxIterationSimplexBox.Size = new System.Drawing.Size(111, 23);
            this.MaxIterationSimplexBox.TabIndex = 101;
            this.MaxIterationSimplexBox.Text = "100";
            this.MaxIterationSimplexBox.SelectedIndexChanged += new System.EventHandler(this.UpdateParameters);
            this.MaxIterationSimplexBox.TextChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(188, 137);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(63, 15);
            this.label18.TabIndex = 2;
            this.label18.Text = "(0.001)";
            // 
            // MaxIterationFreqBox
            // 
            this.MaxIterationFreqBox.FormattingEnabled = true;
            this.MaxIterationFreqBox.Items.AddRange(new object[] {
            "10",
            "20",
            "50",
            "100",
            "200",
            "500",
            "1000",
            "2000",
            "5000",
            "10000"});
            this.MaxIterationFreqBox.Location = new System.Drawing.Point(68, 187);
            this.MaxIterationFreqBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaxIterationFreqBox.Name = "MaxIterationFreqBox";
            this.MaxIterationFreqBox.Size = new System.Drawing.Size(111, 23);
            this.MaxIterationFreqBox.TabIndex = 101;
            this.MaxIterationFreqBox.Text = "100";
            this.MaxIterationFreqBox.SelectedIndexChanged += new System.EventHandler(this.UpdateParameters);
            this.MaxIterationFreqBox.TextChanged += new System.EventHandler(this.UpdateParameters);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(18, 427);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(143, 15);
            this.label35.TabIndex = 2;
            this.label35.Text = "Number of threads";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(18, 218);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(143, 15);
            this.label15.TabIndex = 2;
            this.label15.Text = "False allele rate";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(18, 373);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(191, 15);
            this.label9.TabIndex = 2;
            this.label9.Text = "Max iterations for rs/f";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(18, 268);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(143, 15);
            this.label31.TabIndex = 2;
            this.label31.Text = "Max false alleles";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(18, 167);
            this.label54.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(255, 15);
            this.label54.TabIndex = 2;
            this.label54.Text = "Max freq. estimation iterations";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.DebugOutput2);
            this.tabPage2.Controls.Add(this.DebugOutput1);
            this.tabPage2.Controls.Add(this.splitContainer3);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tabPage2.Size = new System.Drawing.Size(1292, 776);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Output";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // DebugOutput2
            // 
            this.DebugOutput2.Location = new System.Drawing.Point(324, 187);
            this.DebugOutput2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.DebugOutput2.MaxLength = 327670000;
            this.DebugOutput2.Multiline = true;
            this.DebugOutput2.Name = "DebugOutput2";
            this.DebugOutput2.ReadOnly = true;
            this.DebugOutput2.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.DebugOutput2.Size = new System.Drawing.Size(476, 156);
            this.DebugOutput2.TabIndex = 6;
            this.DebugOutput2.Visible = false;
            this.DebugOutput2.WordWrap = false;
            // 
            // DebugOutput1
            // 
            this.DebugOutput1.Location = new System.Drawing.Point(324, 38);
            this.DebugOutput1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.DebugOutput1.MaxLength = 327670000;
            this.DebugOutput1.Multiline = true;
            this.DebugOutput1.Name = "DebugOutput1";
            this.DebugOutput1.ReadOnly = true;
            this.DebugOutput1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.DebugOutput1.Size = new System.Drawing.Size(476, 141);
            this.DebugOutput1.TabIndex = 5;
            this.DebugOutput1.Visible = false;
            this.DebugOutput1.WordWrap = false;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(4, 3);
            this.splitContainer3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.splitContainer4);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.splitContainer6);
            this.splitContainer3.Size = new System.Drawing.Size(1284, 770);
            this.splitContainer3.SplitterDistance = 607;
            this.splitContainer3.SplitterWidth = 5;
            this.splitContainer3.TabIndex = 2;
            this.splitContainer3.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.SaveFile);
            this.splitContainer3.SizeChanged += new System.EventHandler(this.SaveFile);
            // 
            // splitContainer4
            // 
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(0, 0);
            this.splitContainer4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.splitContainer4.Name = "splitContainer4";
            this.splitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.groupBox3);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.groupBox7);
            this.splitContainer4.Size = new System.Drawing.Size(607, 770);
            this.splitContainer4.SplitterDistance = 368;
            this.splitContainer4.SplitterWidth = 5;
            this.splitContainer4.TabIndex = 1;
            this.splitContainer4.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.SaveFile);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.PosterProbBox);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(0, 0);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox3.Size = new System.Drawing.Size(607, 368);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Posterior probabilities";
            // 
            // PosterProbBox
            // 
            this.PosterProbBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PosterProbBox.Location = new System.Drawing.Point(4, 21);
            this.PosterProbBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.PosterProbBox.MaxLength = 327670000;
            this.PosterProbBox.Multiline = true;
            this.PosterProbBox.Name = "PosterProbBox";
            this.PosterProbBox.ReadOnly = true;
            this.PosterProbBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.PosterProbBox.Size = new System.Drawing.Size(599, 344);
            this.PosterProbBox.TabIndex = 1;
            this.PosterProbBox.WordWrap = false;
            this.PosterProbBox.TextChanged += new System.EventHandler(this.SaveFile);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.ModelInfoBox);
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox7.Location = new System.Drawing.Point(0, 0);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox7.Size = new System.Drawing.Size(607, 397);
            this.groupBox7.TabIndex = 1;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Model Information";
            // 
            // ModelInfoBox
            // 
            this.ModelInfoBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ModelInfoBox.Location = new System.Drawing.Point(4, 21);
            this.ModelInfoBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.ModelInfoBox.MaxLength = 327670000;
            this.ModelInfoBox.Multiline = true;
            this.ModelInfoBox.Name = "ModelInfoBox";
            this.ModelInfoBox.ReadOnly = true;
            this.ModelInfoBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ModelInfoBox.Size = new System.Drawing.Size(599, 373);
            this.ModelInfoBox.TabIndex = 1;
            this.ModelInfoBox.WordWrap = false;
            this.ModelInfoBox.TextChanged += new System.EventHandler(this.SaveFile);
            // 
            // splitContainer6
            // 
            this.splitContainer6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer6.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer6.IsSplitterFixed = true;
            this.splitContainer6.Location = new System.Drawing.Point(0, 0);
            this.splitContainer6.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.splitContainer6.Name = "splitContainer6";
            this.splitContainer6.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer6.Panel1
            // 
            this.splitContainer6.Panel1.Controls.Add(this.groupBox10);
            // 
            // splitContainer6.Panel2
            // 
            this.splitContainer6.Panel2.Controls.Add(this.groupBox4);
            this.splitContainer6.Size = new System.Drawing.Size(672, 770);
            this.splitContainer6.SplitterDistance = 150;
            this.splitContainer6.SplitterWidth = 5;
            this.splitContainer6.TabIndex = 2;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.PreviewBox);
            this.groupBox10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox10.Location = new System.Drawing.Point(0, 0);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox10.Size = new System.Drawing.Size(672, 150);
            this.groupBox10.TabIndex = 0;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Preview";
            // 
            // PreviewBox
            // 
            this.PreviewBox.BackColor = System.Drawing.SystemColors.Control;
            this.PreviewBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PreviewBox.Location = new System.Drawing.Point(4, 21);
            this.PreviewBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.PreviewBox.Name = "PreviewBox";
            this.PreviewBox.Size = new System.Drawing.Size(664, 126);
            this.PreviewBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PreviewBox.TabIndex = 0;
            this.PreviewBox.TabStop = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.AFOutBox);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox4.Location = new System.Drawing.Point(0, 0);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox4.Size = new System.Drawing.Size(672, 615);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Allele frequencies";
            // 
            // AFOutBox
            // 
            this.AFOutBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AFOutBox.Location = new System.Drawing.Point(4, 21);
            this.AFOutBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.AFOutBox.MaxLength = 327670000;
            this.AFOutBox.Multiline = true;
            this.AFOutBox.Name = "AFOutBox";
            this.AFOutBox.ReadOnly = true;
            this.AFOutBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.AFOutBox.Size = new System.Drawing.Size(664, 591);
            this.AFOutBox.TabIndex = 2;
            this.AFOutBox.WordWrap = false;
            this.AFOutBox.TextChanged += new System.EventHandler(this.SaveFile);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.splitContainer1);
            this.tabPage3.Controls.Add(this.toolStrip4);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tabPage3.Size = new System.Drawing.Size(1292, 776);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Figure";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(4, 30);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.groupBox5);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.groupBox6);
            this.splitContainer1.Size = new System.Drawing.Size(1284, 743);
            this.splitContainer1.SplitterDistance = 109;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 9;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button18);
            this.groupBox5.Controls.Add(this.button6);
            this.groupBox5.Controls.Add(this.button17);
            this.groupBox5.Controls.Add(this.button5);
            this.groupBox5.Controls.Add(this.button16);
            this.groupBox5.Controls.Add(this.button4);
            this.groupBox5.Controls.Add(this.button15);
            this.groupBox5.Controls.Add(this.button3);
            this.groupBox5.Controls.Add(this.button14);
            this.groupBox5.Controls.Add(this.button2);
            this.groupBox5.Controls.Add(this.button13);
            this.groupBox5.Controls.Add(this.button1);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.label27);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.label26);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.label25);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.label24);
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Controls.Add(this.label23);
            this.groupBox5.Controls.Add(this.label1);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox5.Location = new System.Drawing.Point(0, 0);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox5.Size = new System.Drawing.Size(109, 743);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Legend";
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(43, 470);
            this.button18.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(32, 25);
            this.button18.TabIndex = 112;
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Visible = false;
            this.button18.Click += new System.EventHandler(this.ChangeColor);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(11, 430);
            this.button6.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(32, 25);
            this.button6.TabIndex = 111;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.ChangeColor);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(43, 390);
            this.button17.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(32, 25);
            this.button17.TabIndex = 110;
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.ChangeColor);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(11, 350);
            this.button5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(32, 25);
            this.button5.TabIndex = 109;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.ChangeColor);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(43, 310);
            this.button16.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(32, 25);
            this.button16.TabIndex = 108;
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.ChangeColor);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(11, 270);
            this.button4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(32, 25);
            this.button4.TabIndex = 107;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.ChangeColor);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(43, 230);
            this.button15.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(32, 25);
            this.button15.TabIndex = 106;
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.ChangeColor);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(11, 190);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(32, 25);
            this.button3.TabIndex = 105;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.ChangeColor);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(43, 148);
            this.button14.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(32, 25);
            this.button14.TabIndex = 104;
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.ChangeColor);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(11, 110);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(32, 25);
            this.button2.TabIndex = 103;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.ChangeColor);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(43, 70);
            this.button13.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(32, 25);
            this.button13.TabIndex = 102;
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.ChangeColor);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(11, 30);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(32, 25);
            this.button1.TabIndex = 101;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.ChangeColor);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(83, 475);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 15);
            this.label7.TabIndex = 13;
            this.label7.Text = "Dodeca";
            this.label7.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(83, 395);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 15);
            this.label6.TabIndex = 20;
            this.label6.Text = "Deca";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(51, 435);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(63, 15);
            this.label27.TabIndex = 22;
            this.label27.Text = "Hendeca";
            this.label27.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(83, 315);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 15);
            this.label5.TabIndex = 24;
            this.label5.Text = "Octo";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(51, 355);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(39, 15);
            this.label26.TabIndex = 23;
            this.label26.Text = "Nonu";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(83, 235);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 15);
            this.label4.TabIndex = 19;
            this.label4.Text = "Hexa";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(51, 275);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(47, 15);
            this.label25.TabIndex = 15;
            this.label25.Text = "Septu";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(83, 155);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 15);
            this.label3.TabIndex = 14;
            this.label3.Text = "Tetra";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(51, 195);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(47, 15);
            this.label24.TabIndex = 16;
            this.label24.Text = "Penta";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(83, 75);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 15);
            this.label2.TabIndex = 18;
            this.label2.Text = "Di";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(51, 115);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(31, 15);
            this.label23.TabIndex = 17;
            this.label23.Text = "Tri";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(51, 35);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 15);
            this.label1.TabIndex = 9;
            this.label1.Text = "Ha";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.PicBox);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox6.Location = new System.Drawing.Point(0, 0);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox6.Size = new System.Drawing.Size(1170, 743);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Picture";
            // 
            // PicBox
            // 
            this.PicBox.BackColor = System.Drawing.SystemColors.Control;
            this.PicBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PicBox.Location = new System.Drawing.Point(4, 21);
            this.PicBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.PicBox.Name = "PicBox";
            this.PicBox.Size = new System.Drawing.Size(1162, 719);
            this.PicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicBox.TabIndex = 0;
            this.PicBox.TabStop = false;
            // 
            // toolStrip4
            // 
            this.toolStrip4.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SortButton,
            this.SortPButton,
            this.SortOriButton,
            this.SaveImageButton,
            this.PrintButton,
            this.toolStripSeparator6,
            this.toolStripLabel1,
            this.Iter1Button,
            this.Iter5Button,
            this.Iter20Button,
            this.Iter100Button,
            this.IterResetButton});
            this.toolStrip4.Location = new System.Drawing.Point(4, 3);
            this.toolStrip4.Name = "toolStrip4";
            this.toolStrip4.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.toolStrip4.Size = new System.Drawing.Size(1284, 27);
            this.toolStrip4.TabIndex = 8;
            this.toolStrip4.Text = "toolStrip4";
            // 
            // SortButton
            // 
            this.SortButton.BackColor = System.Drawing.Color.Cornsilk;
            this.SortButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SortButton.Image = ((System.Drawing.Image)(resources.GetObject("SortButton.Image")));
            this.SortButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SortButton.Name = "SortButton";
            this.SortButton.Size = new System.Drawing.Size(40, 24);
            this.SortButton.Text = "So&rt";
            this.SortButton.Click += new System.EventHandler(this.Sort);
            // 
            // SortPButton
            // 
            this.SortPButton.BackColor = System.Drawing.Color.Cornsilk;
            this.SortPButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SortPButton.Image = ((System.Drawing.Image)(resources.GetObject("SortPButton.Image")));
            this.SortPButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SortPButton.Name = "SortPButton";
            this.SortPButton.Size = new System.Drawing.Size(72, 24);
            this.SortPButton.Text = "Sort by &P";
            this.SortPButton.Click += new System.EventHandler(this.SortbyQ);
            // 
            // SortOriButton
            // 
            this.SortOriButton.BackColor = System.Drawing.Color.Cornsilk;
            this.SortOriButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SortOriButton.Image = ((System.Drawing.Image)(resources.GetObject("SortOriButton.Image")));
            this.SortOriButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SortOriButton.Name = "SortOriButton";
            this.SortOriButton.Size = new System.Drawing.Size(66, 24);
            this.SortOriButton.Text = "&Original";
            this.SortOriButton.Click += new System.EventHandler(this.OriginalOrder);
            // 
            // SaveImageButton
            // 
            this.SaveImageButton.BackColor = System.Drawing.Color.Cornsilk;
            this.SaveImageButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SaveImageButton.Image = ((System.Drawing.Image)(resources.GetObject("SaveImageButton.Image")));
            this.SaveImageButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SaveImageButton.Name = "SaveImageButton";
            this.SaveImageButton.Size = new System.Drawing.Size(90, 24);
            this.SaveImageButton.Text = "&Save Image";
            this.SaveImageButton.Click += new System.EventHandler(this.SaveImage);
            // 
            // PrintButton
            // 
            this.PrintButton.BackColor = System.Drawing.Color.Cornsilk;
            this.PrintButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.PrintButton.Image = ((System.Drawing.Image)(resources.GetObject("PrintButton.Image")));
            this.PrintButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.PrintButton.Name = "PrintButton";
            this.PrintButton.Size = new System.Drawing.Size(43, 24);
            this.PrintButton.Text = "&Print";
            this.PrintButton.Visible = false;
            this.PrintButton.Click += new System.EventHandler(this.Print);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(71, 24);
            this.toolStripLabel1.Text = "Stepwise:";
            // 
            // Iter1Button
            // 
            this.Iter1Button.BackColor = System.Drawing.Color.Cornsilk;
            this.Iter1Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Iter1Button.Image = ((System.Drawing.Image)(resources.GetObject("Iter1Button.Image")));
            this.Iter1Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Iter1Button.Name = "Iter1Button";
            this.Iter1Button.Size = new System.Drawing.Size(70, 24);
            this.Iter1Button.Text = "Iter 1 (&Z)";
            this.Iter1Button.Click += new System.EventHandler(this.Stepwise);
            // 
            // Iter5Button
            // 
            this.Iter5Button.BackColor = System.Drawing.Color.Cornsilk;
            this.Iter5Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Iter5Button.Image = ((System.Drawing.Image)(resources.GetObject("Iter5Button.Image")));
            this.Iter5Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Iter5Button.Name = "Iter5Button";
            this.Iter5Button.Size = new System.Drawing.Size(70, 24);
            this.Iter5Button.Text = "Iter 5 (&X)";
            this.Iter5Button.Click += new System.EventHandler(this.Stepwise);
            // 
            // Iter20Button
            // 
            this.Iter20Button.BackColor = System.Drawing.Color.Cornsilk;
            this.Iter20Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Iter20Button.Image = ((System.Drawing.Image)(resources.GetObject("Iter20Button.Image")));
            this.Iter20Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Iter20Button.Name = "Iter20Button";
            this.Iter20Button.Size = new System.Drawing.Size(78, 24);
            this.Iter20Button.Text = "Iter 20 (&C)";
            this.Iter20Button.Click += new System.EventHandler(this.Stepwise);
            // 
            // Iter100Button
            // 
            this.Iter100Button.BackColor = System.Drawing.Color.Cornsilk;
            this.Iter100Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Iter100Button.Image = ((System.Drawing.Image)(resources.GetObject("Iter100Button.Image")));
            this.Iter100Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Iter100Button.Name = "Iter100Button";
            this.Iter100Button.Size = new System.Drawing.Size(86, 24);
            this.Iter100Button.Text = "Iter 100 (&V)";
            this.Iter100Button.Click += new System.EventHandler(this.Stepwise);
            // 
            // IterResetButton
            // 
            this.IterResetButton.BackColor = System.Drawing.Color.Cornsilk;
            this.IterResetButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.IterResetButton.Image = ((System.Drawing.Image)(resources.GetObject("IterResetButton.Image")));
            this.IterResetButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.IterResetButton.Name = "IterResetButton";
            this.IterResetButton.Size = new System.Drawing.Size(49, 24);
            this.IterResetButton.Text = "R&eset";
            this.IterResetButton.Click += new System.EventHandler(this.ResetStepwise);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "BMP|*.bmp|GIF|*.gif|JPG|*.jpg|PNG|*.png|TIF|*.tif|EMF|*.emf|WMF|*.wmf";
            // 
            // BottomToolStripPanel
            // 
            this.BottomToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.BottomToolStripPanel.Name = "BottomToolStripPanel";
            this.BottomToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.BottomToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.BottomToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // TopToolStripPanel
            // 
            this.TopToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.TopToolStripPanel.Name = "TopToolStripPanel";
            this.TopToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.TopToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.TopToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // RightToolStripPanel
            // 
            this.RightToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.RightToolStripPanel.Name = "RightToolStripPanel";
            this.RightToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.RightToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.RightToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // LeftToolStripPanel
            // 
            this.LeftToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.LeftToolStripPanel.Name = "LeftToolStripPanel";
            this.LeftToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.LeftToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.LeftToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // ContentPanel
            // 
            this.ContentPanel.Size = new System.Drawing.Size(150, 175);
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(1300, 814);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(1300, 835);
            this.toolStripContainer1.TabIndex = 0;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // timer2
            // 
            this.timer2.Enabled = true;
            this.timer2.Interval = 10000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1300, 835);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.toolStripContainer1);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form1";
            this.Text = "PloidyInfer V1.3";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.SizeChanged += new System.EventHandler(this.SaveFile);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.splitContainer7.Panel1.ResumeLayout(false);
            this.splitContainer7.Panel1.PerformLayout();
            this.splitContainer7.Panel2.ResumeLayout(false);
            this.splitContainer7.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).EndInit();
            this.splitContainer7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.SimMaxFalseAllelesBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimFalseAlleleRateaBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimSampleRatioBOx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimFemaleRatioBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimBetaBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimSelfingRateBox)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.splitContainer5.Panel1.ResumeLayout(false);
            this.splitContainer5.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).EndInit();
            this.splitContainer5.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PreHeightBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicHeightBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PreWidthBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicWidthBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DecimalBox)).EndInit();
            this.groupbox11.ResumeLayout(false);
            this.groupbox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ThreadBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MaxFalseAllelesBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FalseAlleleRateBox)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.splitContainer6.Panel1.ResumeLayout(false);
            this.splitContainer6.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).EndInit();
            this.splitContainer6.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PreviewBox)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PicBox)).EndInit();
            this.toolStrip4.ResumeLayout(false);
            this.toolStrip4.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.ToolStripButton RunButton;
        private System.Windows.Forms.ToolStripButton AboutButton;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.ToolStripButton AbortButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox SimParBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox PhenotypeBox;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripButton FounderButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripButton SeedButton;
        private System.Windows.Forms.ToolStripTextBox Seedbox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripLabel ChainLenLabel;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripLabel toolStripLabel7;
        private System.Windows.Forms.ToolStripComboBox FeedBackFreqBox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.TextBox PosterProbBox;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox ModelInfoBox;
        private System.Windows.Forms.TextBox AFOutBox;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.SplitContainer splitContainer5;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.SplitContainer splitContainer6;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.PictureBox PreviewBox;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.ComboBox MaxDiffFreqBox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox MaxDiffAssignBox;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.NumericUpDown PicHeightBox;
        private System.Windows.Forms.NumericUpDown PicWidthBox;
        private System.Windows.Forms.NumericUpDown DecimalBox;
        private System.Windows.Forms.NumericUpDown PreHeightBox;
        private System.Windows.Forms.NumericUpDown PreWidthBox;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton Reproduce1Button;
        private System.Windows.Forms.ToolStripLabel GstLabel;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripLabel toolStripLabel4;
        private System.Windows.Forms.ToolStripButton Reproduce10Button;
        private System.Windows.Forms.ToolStripButton Reproduce100Button;
        private System.Windows.Forms.ToolStripButton Reproduce1000Button;
        private System.Windows.Forms.NumericUpDown SimFemaleRatioBox;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.ToolStripLabel GenLabel;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.NumericUpDown SimSelfingRateBox;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ToolStripButton ReproduceGstButton;
        private System.Windows.Forms.ToolStripComboBox GstBox;
        private System.Windows.Forms.GroupBox groupbox11;
        private System.Windows.Forms.CheckBox NullBox;
        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.ToolStrip toolStrip4;
        private System.Windows.Forms.ToolStripButton SortButton;
        private System.Windows.Forms.ToolStripButton SortPButton;
        private System.Windows.Forms.ToolStripButton SortOriButton;
        private System.Windows.Forms.ToolStripButton SaveImageButton;
        private System.Windows.Forms.ToolStripButton PrintButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripButton Iter1Button;
        private System.Windows.Forms.ToolStripButton Iter5Button;
        private System.Windows.Forms.ToolStripButton Iter20Button;
        private System.Windows.Forms.ToolStripButton Iter100Button;
        private System.Windows.Forms.ToolStripButton IterResetButton;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.PictureBox PicBox;
        private System.Windows.Forms.ToolStripPanel BottomToolStripPanel;
        private System.Windows.Forms.ToolStripPanel TopToolStripPanel;
        private System.Windows.Forms.ToolStripPanel RightToolStripPanel;
        private System.Windows.Forms.ToolStripPanel LeftToolStripPanel;
        private System.Windows.Forms.ToolStripContentPanel ContentPanel;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.ComboBox MaxIterationFreqBox;
        private System.Windows.Forms.ComboBox MaxIterationAssignBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox DrBox;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.CheckBox WarningBox;
        private System.Windows.Forms.ToolStripButton App3Button;
        private System.Windows.Forms.ToolStripButton ManualButton;
        private System.Windows.Forms.TextBox DebugOutput2;
        private System.Windows.Forms.TextBox DebugOutput1;
        private System.Windows.Forms.CheckBox SimDioeciousBox;
        private System.Windows.Forms.CheckBox BetaBox;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.SplitContainer splitContainer7;
        private System.Windows.Forms.NumericUpDown SimSampleRatioBOx;
        private System.Windows.Forms.ComboBox SimDRBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.NumericUpDown SimFalseAlleleRateaBox;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.NumericUpDown SimMaxFalseAllelesBox;
        private System.Windows.Forms.NumericUpDown MaxFalseAllelesBox;
        private System.Windows.Forms.NumericUpDown FalseAlleleRateBox;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.NumericUpDown ThreadBox;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.NumericUpDown SimBetaBox;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox MaxDiffSimplexBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox MaxIterationSimplexBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox SelfingBox;
        private System.Windows.Forms.CheckBox UpdatePrioriBox;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
    }
}

