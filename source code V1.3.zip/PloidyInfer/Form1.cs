﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.IO;
using System.Threading;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Management;
using System.Diagnostics;
using System.Threading.Tasks;

namespace PloidyInfer
{
    public partial class Form1 : Form
    {
        #region DLL_IMPORT
        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool TerminateProcess(IntPtr hProcess, uint uExitCode);

        [DllImport("user32.dll", EntryPoint = "GetWindowText")]
        public static extern int GetWindowText(IntPtr hwnd, StringBuilder text, int len);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiiiiiiii(double a1, double a2, double pi);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiiiiiiij(double a1, double a2, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiiiiiijj(double a1, double a2, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiiiiiijk(double a1, double a2, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiiiiijjj(double a1, double a2, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiiiiijjk(double a1, double a2, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiiiiijkl(double a1, double a2, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiiiijjjj(double a1, double a2, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiiiijjjk(double a1, double a2, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiiiijjkk(double a1, double a2, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiiiijjkl(double a1, double a2, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiiiijklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiiijjjjj(double a1, double a2, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiiijjjjk(double a1, double a2, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiiijjjkk(double a1, double a2, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiiijjjkl(double a1, double a2, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiiijjkkl(double a1, double a2, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiiijjklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiiijklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiijjjjkk(double a1, double a2, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiijjjjkl(double a1, double a2, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiijjjkkk(double a1, double a2, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiijjjkkl(double a1, double a2, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiijjjklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiijjkkll(double a1, double a2, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiijjkklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiijjklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiiijklmno(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiijjjkkkl(double a1, double a2, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiijjjkkll(double a1, double a2, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiijjjkklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiijjjklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiijjkkllm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiijjkklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiijjklmno(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iiijklmnop(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iijjkkllmm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iijjkkllmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iijjkklmno(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iijjklmnop(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_iijklmnopq(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp, double pq);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ10_ijklmnopqr(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp, double pq, double pr);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ10_i(double a1, double a2, double pi);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ10_ij(double a1, double a2, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ10_ijk(double a1, double a2, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ10_ijkl(double a1, double a2, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ10_ijklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ10_ijklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ10_ijklmno(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ10_ijklmnop(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ10_ijklmnopq(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp, double pq);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ10_ijklmnopqr(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp, double pq, double pr);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFG10_iiiii(double a1, double a2, double pi);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFG10_iiiij(double a1, double a2, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFG10_iiijj(double a1, double a2, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFG10_iiijk(double a1, double a2, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFG10_iijjk(double a1, double a2, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFG10_iijkl(double a1, double a2, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFG10_ijklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFG10_i(double a1, double a2, double pi);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFG10_ij(double a1, double a2, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFG10_ijk(double a1, double a2, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFG10_ijkl(double a1, double a2, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFG10_ijklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ8_iiiiiiii(double a1, double a2, double pi);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ8_iiiiiiij(double a1, double a2, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ8_iiiiiijj(double a1, double a2, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ8_iiiiiijk(double a1, double a2, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ8_iiiiijjj(double a1, double a2, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ8_iiiiijjk(double a1, double a2, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ8_iiiiijkl(double a1, double a2, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ8_iiiijjjj(double a1, double a2, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ8_iiiijjjk(double a1, double a2, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ8_iiiijjkk(double a1, double a2, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ8_iiiijjkl(double a1, double a2, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ8_iiiijklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ8_iiijjjkk(double a1, double a2, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ8_iiijjjkl(double a1, double a2, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ8_iiijjkkl(double a1, double a2, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ8_iiijjklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ8_iiijklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ8_iijjkkll(double a1, double a2, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ8_iijjkklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ8_iijjklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ8_iijklmno(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ8_ijklmnop(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ8_i(double a1, double a2, double pi);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ8_ij(double a1, double a2, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ8_ijk(double a1, double a2, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ8_ijkl(double a1, double a2, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ8_ijklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ8_ijklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ8_ijklmno(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ8_ijklmnop(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFG8_iiii(double a1, double a2, double pi);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFG8_iiij(double a1, double a2, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFG8_iijj(double a1, double a2, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFG8_iijk(double a1, double a2, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFG8_ijkl(double a1, double a2, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFG8_i(double a1, double a2, double pi);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFG8_ij(double a1, double a2, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFG8_ijk(double a1, double a2, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFG8_ijkl(double a1, double a2, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ6_iiiiii(double a1, double pi);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ6_iiiiij(double a1, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ6_iiiijj(double a1, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ6_iiiijk(double a1, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ6_iiijjj(double a1, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ6_iiijjk(double a1, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ6_iiijkl(double a1, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ6_iijjkk(double a1, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ6_iijjkl(double a1, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ6_iijklm(double a1, double pi, double pj, double pk, double pl, double pm);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ6_ijklmn(double a1, double pi, double pj, double pk, double pl, double pm, double pn);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ6_i(double a1, double pi);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ6_ij(double a1, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ6_ijk(double a1, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ6_ijkl(double a1, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ6_ijklm(double a1, double pi, double pj, double pk, double pl, double pm);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ6_ijklmn(double a1, double pi, double pj, double pk, double pl, double pm, double pn);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFG6_iii(double a1, double pi);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFG6_iij(double a1, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFG6_ijk(double a1, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFG6_i(double a1, double pi);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFG6_ij(double a1, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFG6_ijk(double a1, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ4_iiii(double a1, double pi);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ4_iiij(double a1, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ4_iijj(double a1, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ4_iijk(double a1, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFZ4_ijkl(double a1, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ4_i(double a1, double pi);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ4_ij(double a1, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ4_ijk(double a1, double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ4_ijkl(double a1, double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFG4_ii(double a1, double pi);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double GFG4_ij(double a1, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFG4_i(double a1, double pi);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFG4_ij(double a1, double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ3_i(double pi);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ3_ij(double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ3_ijk(double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ5_i(double pi);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ5_ij(double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ5_ijk(double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ5_ijkl(double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ5_ijklm(double pi, double pj, double pk, double pl, double pm);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ7_i(double pi);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ7_ij(double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ7_ijk(double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ7_ijkl(double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ7_ijklm(double pi, double pj, double pk, double pl, double pm);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ7_ijklmn(double pi, double pj, double pk, double pl, double pm, double pn);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ7_ijklmno(double pi, double pj, double pk, double pl, double pm, double pn, double po);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ9_i(double pi);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ9_ij(double pi, double pj);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ9_ijk(double pi, double pj, double pk);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ9_ijkl(double pi, double pj, double pk, double pl);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ9_ijklm(double pi, double pj, double pk, double pl, double pm);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ9_ijklmn(double pi, double pj, double pk, double pl, double pm, double pn);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ9_ijklmno(double pi, double pj, double pk, double pl, double pm, double pn, double po);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ9_ijklmnop(double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp);

        [DllImport("dre", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        private static extern double PFZ9_ijklmnopq(double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp, double pq);


        #endregion 

        #region GLOBAL_VARS

        public enum runstates
        {
            notstart,
            running,
            end,
            pause,
            pauseend,
            simulating,
            simulated,
            simulatedend
        };

        //  constant var       

        public static string[] PLOIDY_NAME = new string[] { "None", "Ha", "Di", "Tri", "Tetra", "Penta", "Hexa", "Septu", "Octo", "Nonu", "Deca", "Hendeca", "Dodeca" };
                                                             //0            1               2           3              4            5                          6              7               8                     9                        10
        public static Color[] PLOIDY_COLOR = new Color[]{ Color.White, Color.DarkRed, Color.Red, Color.DarkBlue, Color.Blue, Color.FromArgb(200,100,0), Color.Orange, Color.DarkGreen, Color.FromArgb(0,180,0), Color.DarkMagenta, Color.Magenta,
                                                        //     11               2           3                      4               5           6              7                8                9                20
                                                         Color.FromArgb(196,196,0), Color.Yellow};//, Color.FromArgb(249,94,77), Color.DarkSalmon, Color.DarkGoldenrod, Color.Goldenrod, Color.DarkKhaki, Color.Khaki, Color.DarkSlateBlue, Color.SlateBlue, Color.DarkViolet, Color.Violet, 
        //     21               22           23              24      
        //Color.DarkSeaGreen, Color.SeaGreen, Color.DarkCyan, Color.Cyan};

        public static string[] ARGS; //program arguments
        public static int PICORDER = 0; //individual order of barplot
        public static int MAXBUF = 4096; //buffer
        public static string DECIMAL = "F5"; //decimal places
        public static string DECIMAL2 = "F5"; //half decimal places
        public static int PICHEIGHT = 500;//pic width and height
        public static int PICWIDTH = 5000;//pic width and height
        public static int PREHEIGHT = 100;//pic width and height
        public static int PREWIDTH = 1000; //pic width and height
        public static int NUM_ITER = 0; //current iteration number

        public static int MAX_ITER_FREQ = 1000; //maximum iteration used in allele frequency estimation
        public static double MAX_DIFF_FREQ = 0.001; //difference threshold to break allele frequency estimation
        public static int MAX_ITER_SIMPLEX = 20;
        public static double MAX_DIFF_SIMPLEX = 0.001;
        public static int MAX_ITER_ASSIGN = 800; //maximum iteration used in analysis
        public static double MAX_DIFF_ASSIGN = 0.00001; //difference threshold to break ploidy assignment

        public static bool CONSIDER_NULL = true; //consider null alleles
        public static bool CONSIDER_BETA = true; //consider negative amplification
        public static bool CONSIDER_SELFING = true; //consider selfing
        public static double GST_TERMINAL = 0.05; //simulation, Gst terminal value

        public static int FINAL_TICK = 20; //prograssbar maximum
        public static int DR_MODE = 3; //double reduction model used in analysis
        public static double FALSE_RATE = 0.05; //false allele rate in analysis
        public static int MAX_FALSE = 2;//maximum number of false allelesin analysis
        
        public static int MAX_PLOIDY = 10;//maximum level of ploidy this program supported
        public static bool SIM_DIOECIOUS = true; //dioecious or monocious
        public static double SIM_FEMALE_RATIO = 0.5; //femal ratio
        public static double SIM_SELFING_RATIO = 0; //selfing ratio
        public static double SIM_SAMPLING_RATIO = 1; //sampling ratio
        public static int SIM_MAX_FALSE = 2;//maximum number of false alleles in simulation
        public static double SIM_BETA = 0.05;//false allele rate in simulation
        public static double SIM_FALSE_RATE = 0.05;//false allele rate in simulation
        public static int SIM_DR_MODE = 3; //double reduction model in simulation

        public static int CURRENT_PAGE; //current page (used to show figure)
        public static int N_THREADS = 2;//maximum level of ploidy this program supported
        public static int MAX_PLOIDY_USED;//maximum level of ploidy used in current analysis
        public static List<int> CANDIDATE_PLOIDY; //candidate ploidy levels
        public static int DRAW_FREQ = 100000; //frequency to draw barplot
        public static int MAX_ALLELESID = 65535; //max allele identifier
        public static int MAX_ALLELES = 150; //maximum number of alleles
        public static int MAX_LOCI = 5000; //maximum number of loci
        public static int MAX_INDS = 6553500;//maximum number of individuals
        public static bool ALLOW_WARNING = true;

        public static double[,][] ALPHA = new double[0, MAX_PLOIDY + 1][];//double-reduction rate in a gamete 
        public static double[,] LAMBDA = new double[0, MAX_PLOIDY + 1];// sum_i i * alpha_i
        public static double[,] PHENO_COUNT = new double[MAX_PLOIDY + 5, MAX_ALLELES + 2];//number of possible phenotypes at a locus
        public static double[,] BINOMIAL;//combination number (n choose k)
        public static double[] FALSE_RATE_POWER = new double[MAX_ALLELES + 2];
        public static double[] ONEMINUS_FALSE_RATE_POWER = new double[MAX_ALLELES + 2];

        public static bool UPDATE_PRIORI = true; //debug flag
        public static string IDENTIFIER = "\r\n%%ID%%\r\n";//used to separe contents in config.ini
        public static int NULL_ALLELE = 16777211;

        private bool PRESAVE = false;
        private bool LOADING = false;

        public static List<POP> pops = new List<POP>();
        public static POP all;
        public static Thread thread;

        public static string PHENO_INPUT = "";
        private static string CDIR = Directory.GetCurrentDirectory() + "\\";
        public static Random grnd = new Random();
        public static runstates runstate = 0;
        public static double ninf = double.NegativeInfinity;

        public static double CURRENT_ASSIGNMENT_DIFF = 1;
        public static double CURRENT_FREQ_DIFF = 1;

        public static bool FEEKBACKFLAG = false;
        public static StringBuilder FEEDBACK_INDIVIDUAL = new StringBuilder();
        public static StringBuilder FEEDBACK_LOCUS = new StringBuilder();
        public static StringBuilder FEEDBACK_MODEL = new StringBuilder();

        public static Image OIMAGE;
        public static bool TESTING = true; //debug flag

        public static CheckBox[] chbox = new CheckBox[MAX_PLOIDY + 1];
        public static NumericUpDown[] numbox = new NumericUpDown[MAX_PLOIDY + 1];

        public static int NUM_REPRODUCE = 0;
        public static int NUM_REPRODUCE_START = 0;
        public static double GST = 0;

        Process[] PROC; 
        public static int APPLOOP = 0;
        public static bool APP1 = false, APP2 = false, APP3 = false;

        public static int APP2_STAGE = 0, APP2_MODEL = 0;
        public static int[] APP2_CORRECT = new int[8];
        public static double[] APP2_BIC = new double[8];

        public static int APP3_STAGE = 0, APP3_MODEL = 0;

        #endregion

        #region HASH
        public static uint[] cryptTable = new uint[0];

        public static void prepareCryptTable()
        {
            cryptTable = new uint[0x500];
            uint dwHih, dwLow, seed = 0x00100001, index1 = 0, index2 = 0, i;
            for (index1 = 0; index1 < 0x100; index1++)
            {
                for (index2 = index1, i = 0; i < 5; i++, index2 += 0x100)
                {
                    seed = (seed * 125 + 3) % 0x2AAAAB;
                    dwHih = (seed & 0xFFFF) << 0x10;
                    seed = (seed * 125 + 3) % 0x2AAAAB;
                    dwLow = (seed & 0xFFFF);
                    cryptTable[index2] = (dwHih | dwLow);
                }
            }
        }

        public static int HashString(string str, int type = 0x100)
        {
            uint dwSeed1 = 0x7FED7FED;
            uint dwSeed2 = 0xEEEEEEEE;
            uint b1, b2;
            for (int i = 0; i < str.Length; ++i)
            {
                b1 = (uint)str[i] >> 8;
                b2 = (uint)str[i] & 0xFF;
                dwSeed1 = cryptTable[type + b1] ^ (dwSeed1 + dwSeed2);
                dwSeed2 = b1 + dwSeed1 + dwSeed2 + (dwSeed2 << 5) + 3;
                dwSeed1 = cryptTable[type + b2] ^ (dwSeed1 + dwSeed2);
                dwSeed2 = b2 + dwSeed1 + dwSeed2 + (dwSeed2 << 5) + 3;
            }
            return (int)dwSeed1;
        }

        public static int HashIntList(List<int> alleles, int type = 0x100)
        {
            uint dwSeed1 = 0x7FED7FED;
            uint dwSeed2 = 0xEEEEEEEE;
            uint b1, b2;
            foreach (int a in alleles)
            {
                uint t = (uint)a;
                b1 = t & 0xFF; t >>= 8;
                b2 = t & 0xFF;
                dwSeed1 = cryptTable[type + b1] ^ (dwSeed1 + dwSeed2);
                dwSeed2 = b1 + dwSeed1 + dwSeed2 + (dwSeed2 << 5) + 3;
                dwSeed1 = cryptTable[type + b2] ^ (dwSeed1 + dwSeed2);
                dwSeed2 = b2 + dwSeed1 + dwSeed2 + (dwSeed2 << 5) + 3;
            }
            return (int)dwSeed1;
        }

        public static int HashIntList(int[] alleles, int type = 0x100)
        {
            if (alleles.Length == 0)
                return 0;
            for (int i = 0; i < alleles.Length; ++i)
                for (int j = i + 1; j < alleles.Length; ++j)
                    if (alleles[i] > alleles[j])
                    {
                        int t = alleles[i];
                        alleles[i] = alleles[j];
                        alleles[j] = t;
                    }

            uint dwSeed1 = 0x7FED7FED;
            uint dwSeed2 = 0xEEEEEEEE;
            uint b1, b2;
            foreach (int a in alleles)
            {
                uint t = (uint)a;
                b1 = t & 0xFF; t >>= 8;
                b2 = t & 0xFF;
                dwSeed1 = cryptTable[type + b1] ^ (dwSeed1 + dwSeed2);
                dwSeed2 = b1 + dwSeed1 + dwSeed2 + (dwSeed2 << 5) + 3;
                dwSeed1 = cryptTable[type + b2] ^ (dwSeed1 + dwSeed2);
                dwSeed2 = b2 + dwSeed1 + dwSeed2 + (dwSeed2 << 5) + 3;
            }
            return (int)dwSeed1;
        }

        public static long HashIntListLong(List<int> alleles, int type = 0x100)
        {
            return (((long)HashIntList(alleles, type)) << 32) | ((long)HashIntList(alleles, type + 0x100));
        }

        public static long HashIntListLong(int[] alleles, int type = 0x100)
        {
            return (((long)HashIntList(alleles, type)) << 32) | ((long)HashIntList(alleles, type + 0x100));
        }
        #endregion

        #region POINT
        public class POINT
        {
            public double image;//ranges from -inf to inf
            public double real;//ranges from 0 to 1
            public double li;//natural logarithm of likelihood

            public POINT()
            {
                image = 0;
                real = 1;
                li = 0;
            }

            public POINT(POINT a)
            {
                image = a.image;
                real = a.real;
                li = a.li;
            }

            public static bool operator >(POINT a, POINT b)
            {
                return a.li > b.li;
            }

            public static bool operator >=(POINT a, POINT b)
            {
                return a.li >= b.li;
            }

            public static bool operator <(POINT a, POINT b)
            {
                return a.li < b.li;
            }

            public static bool operator <=(POINT a, POINT b)
            {
                return a.li <= b.li;
            }

            public static bool operator ==(POINT a, POINT b)
            {
                return a.li == b.li;
            }

            public static bool operator !=(POINT a, POINT b)
            {
                return a.li != b.li;
            }

            public static POINT operator +(POINT a, POINT b)
            {
                POINT t = new POINT(a);
                t.image = a.image + b.image;
                t.li = 0;
                return t;
            }

            public static POINT operator -(POINT a, POINT b)
            {
                POINT t = new POINT(a);
                t.image = a.image - b.image;
                t.li = 0;
                return t;
            }

            public static POINT operator *(POINT a, double b)
            {
                POINT t = new POINT(a);
                t.image = a.image * b;
                return t;
            }

            public static POINT operator /(POINT a, double b)
            {
                POINT t = new POINT(a);
                t.image = a.image / b;
                return t;
            }

            public void Image2Real()
            {
                real = 1.0 / (1 + Math.Exp(-image));
            }

            public void Real2Image()
            {
                image = -Math.Log(1 / real - 1);
            }

            //Get distance between points
            public static double Distance(POINT a, POINT b)
            {
                return Math.Sqrt((a.real - b.real) * (a.real - b.real));
            }


            //Is all simplex points within a range, if yes, break the down-hill simplex algorithm
            /*
            public static bool IsBreak(POINT[] xx, double eps)
            {
                return Distance(xx[0], xx[xx.Length - 1]) < eps;
            }
            */

            //Sort the points by likelihoods
            public static void Order(POINT[] xx)
            {
                POINT t;
                for (int i = 0; i < xx.Length; ++i)
                {
                    for (int j = i + 1; j < xx.Length; ++j)
                    {
                        if (xx[i] < xx[j])
                        {
                            t = xx[i];
                            xx[i] = xx[j];
                            xx[j] = t;
                        }
                    }
                }
            }
        };
        #endregion

        #region RNG
        //Random number generator

        public static int[] GetRandSequence(Random rnd, int nn)
        {
            List<int> td = new List<int>();
            for (int i = 0; i < nn; ++i)
                td.Add((rnd.Next() << 16) | i);
            td.Sort();
            for (int i = 0; i < nn; ++i)
                td[i] &= 0xFFFF;
            return td.ToArray();
        }

        public static void Swap<T>(ref T val1, ref T val2)
        {
            T t = val1;
            val1 = val2;
            val2 = t;
        }

        public static void Permute<T>(T[] val, Random rnd, int n = -1)
        {
            for (int i = n == -1 ? val.Length : n; i > 1; --i)
                Swap(ref val[i - 1], ref val[rnd.Next(i)]);
        }

        public static int NextAvoid(Random rnd, int n, int aval)
        {
            int re = rnd.Next(n - 1);
            if (re >= aval) re++;
            return re;
        }

        //Draw a random variable according to Normal distribution 
        public static double GetRNorm(Random rnd)
        {
            double U1 = Math.Sqrt(-2 * Math.Log(rnd.NextDouble()));
            double U2 = 2 * Math.PI * rnd.NextDouble();
            return U1 * Math.Cos(U2);
        }

        //Draw a random variable according to Gamma distribution 
        public static double GetRGamma(Random rnd, double alpha, double beta = 1)
        {
            if (alpha < 1) return GetRGamma(rnd, 1.0 + alpha, beta) * Math.Pow(rnd.NextDouble(), 1.0 / alpha);
            double x, v, u;
            double d = alpha - 1.0 / 3.0;
            double c = (1.0 / 3.0) / Math.Sqrt(d);

            while (true)
            {
                do
                {
                    x = GetRNorm(rnd);
                    v = 1.0 + c * x;
                }
                while (v <= 0);

                v = v * v * v;
                u = rnd.NextDouble();

                if (u < 1 - 0.0331 * x * x * x * x) break;
                if (Math.Log(u) < 0.5 * x * x + d * (1 - v + Math.Log(v))) break;
            }
            return beta * d * v;
        }

        //Draw a random variable according to Gamma Dirichlet 
        public static void GetRDirichlet(Random rnd, double[] a, double[] res)
        {
            double sum = 0;
            for (int i = 0; i < res.Length; ++i)
            {
                res[i] = GetRGamma(rnd, a[i]);
                sum += res[i];
            }
            for (int i = 0; i < res.Length; ++i)
                res[i] /= sum;
        }

        public static double[] GetRDirichletOne(Random rnd, int k)
        {
            double[] re = new double[k];
            double sum = 0;
            for (int i = 0; i < k; ++i)
            {
                re[i] = GetRGamma(rnd, 1.0);
                sum += re[i];
            }
            for (int i = 0; i < k; ++i)
                re[i] /= sum;
            return re;
        }

        #endregion

        #region CHI_DIST

        //chi dist
        private static double[] Gamma1Coef = new double[] { 0.99999999999980993, 676.5203681218851, -1259.1392167224028, 771.32342877765313, -176.61502916214059, 12.507343278686905, -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7 };
        
        private static double Gamma1(double x)
        {
            int g = 7;
            if (x < 0.5) return Math.PI / (Math.Sin(Math.PI * x) * Gamma1(1 - x));
            x -= 1;
            double a = Gamma1Coef[0];
            double t = x + g + 0.5;
            for (int i = 1; i < 9; ++i)
                a += Gamma1Coef[i] / (x + i);
            return 2.5066282746310005 * Math.Pow(t, x + 0.5) * Math.Exp(-t) * a;
        }

        private static double[] LogGamma1Coef = { 1.000000000190015, 76.18009172947146, -86.50532032941677, 24.01409824083091, -1.231739572450155, 0.0012086509738662, -0.000005395239385 };
        
        private static double LogGamma1(double x)
        {
            if (x < 3.72008E-44) return LogGamma1(3.72008E-44);
            double y = x, ser = LogGamma1Coef[0];
            for (int i = 1; i < 7; ++i)
                ser += (LogGamma1Coef[i] / ++y);
            return Math.Log(2.5066282746310005 * ser / x) - (x + 5.5 - (x + 0.5) * Math.Log(x + 5.5));
        }

        private static double Gamma2(double a, double x)
        {
            int n;
            double p, q, d, s, s1, p0, q0, p1, q1, qln;
            if (a <= 0.0 || x < 0.0)
                return -1;

            if (x + 1.0 == 1.0) return 0;
            if (x > 1.0e+35) return 1;
            qln = q = a * Math.Log(x);
            if (x < 1.0 + a)
            {
                p = a;
                d = 1.0 / a;
                s = d;
                for (n = 1; n <= 100; n++)
                {
                    p = 1.0 + p;
                    d = d * x / p;
                    s = s + d;
                    if (Math.Abs(d) < Math.Abs(s) * 1.0e-07)
                    {
                        //s *= Math.Exp(-x) * qq / Gamma1(a);
                        s *= Math.Exp(-x + qln - LogGamma1(a));
                        return s;
                    }
                }
            }
            else
            {
                s = 1.0 / x;
                p0 = 0.0;
                p1 = 1.0;
                q0 = 1.0;
                q1 = x;
                for (n = 1; n <= 100; n++)
                {
                    p0 = p1 + (n - a) * p0;
                    q0 = q1 + (n - a) * q0;
                    p = x * p0 + n * p1;
                    q = x * q0 + n * q1;
                    if (Math.Abs(q) + 1.0 != 1.0)
                    {
                        s1 = p / q;
                        p1 = p;
                        q1 = q;
                        if (Math.Abs((s1 - s) / s1) < 1.0e-07)
                        {
                            //s = s1 * Math.Exp(-x) * qq / Gamma1(a);
                            s = Math.Exp(Math.Log(s1) - x + qln - LogGamma1(a));
                            return 1.0 - s;
                        }
                        s = s1;
                    }
                    p1 = p;
                    q1 = q;
                }
            }
            //s = 1.0 - s * Math.Exp(-x) * qq / Gamma1(a);
            s = 1.0 - Math.Exp(Math.Log(s) - x + qln - LogGamma1(a));
            return s;
        }

        private static double LogGamma2(double a, double x)
        {
            int n;
            double p, q, d, s, s1, p0, q0, p1, q1, qq;
            if (a <= 0.0 || x < 0.0)
                return -1;

            if (x + 1.0 == 1.0) return 0;
            if (x > 1.0e+35) return 1;
            q = a * Math.Log(x);
            qq = Math.Exp(q);
            if (x < 1.0 + a)
            {
                p = a;
                d = 1.0 / a;
                s = d;
                for (n = 1; n <= 100; n++)
                {
                    p = 1.0 + p;
                    d = d * x / p;
                    s = s + d;
                    if (Math.Abs(d) < Math.Abs(s) * 1.0e-07)
                    {
                        s = s * Math.Exp(-x) * qq / Gamma1(a);
                        return s;
                    }
                }
            }
            else
            {
                s = 1.0 / x;
                p0 = 0.0;
                p1 = 1.0;
                q0 = 1.0;
                q1 = x;
                for (n = 1; n <= 100; n++)
                {
                    p0 = p1 + (n - a) * p0;
                    q0 = q1 + (n - a) * q0;
                    p = x * p0 + n * p1;
                    q = x * q0 + n * q1;
                    if (Math.Abs(q) + 1.0 != 1.0)
                    {
                        s1 = p / q;
                        p1 = p;
                        q1 = q;
                        if (Math.Abs((s1 - s) / s1) < 1.0e-07)
                        {
                            s = s1 * Math.Exp(-x) * qq / Gamma1(a);
                            return 1.0 - s;
                        }
                        s = s1;
                    }
                    p1 = p;
                    q1 = q;
                }
            }
            s = 1.0 - s * Math.Exp(-x) * qq / Gamma1(a);
            return s;
        }

        //Right-tail probability of ChiSquared Distribution   (1 - Cumulative distribution function)
        private static double ChiDist(double x2, double df)
        {
            if (x2 < 0.0) x2 = -x2;
            return 1 - Gamma2(df / 2.0, x2 / 2.0);
        }
        #endregion

        public Form1(string[] a1)
        {
            ARGS = a1;
            InitializeComponent();
        }

        #region MISC

        private static double s2f(double s, int v, int l)
        {
            double lambda = LAMBDA[l, v];
            return (8 * lambda + s * v) / (8 * lambda + v * (s + v - s * v));
        }

        private string ColorToString(Color a)
        {
            return a.R + "," + a.G + "," + a.B;
        }

        private Color StringToColor(string a)
        {
            string[] t = a.Split(new char[] { ',' });
            try
            {
                return Color.FromArgb(int.Parse(t[0]), int.Parse(t[1]), int.Parse(t[2]));
            }
            catch
            {
                return Color.White;
            }
        }

        public static double Factorial(int n)
        {
            switch (n)
            {
                case 0: return 1;
                case 1: return 1;
                case 2: return 2;
                case 3: return 6;
                case 4: return 24;
                case 5: return 120;
                case 6: return 720;
                case 7: return 5040;
                case 8: return 40320;
                case 9: return 362880;
                case 10: return 3628800;
                case 11: return 39916800;
                case 12: return 479001600;
                case 13: return 6227020800;
                case 14: return 87178291200;
                case 15: return 1307674368000;
                case 16: return 20922789888000;
                case 17: return 355687428096000;
                case 18: return 6402373705728000;
                case 19: return 121645100408832000;
                case 20: return 2432902008176640000;
                case 21: return 51090942171709440000.0;
                case 22: return 1124000727777607680000.0;
                case 23: return 25852016738884976640000.0;
                case 24: return 620448401733239439360000.0;
                default:
                    double re = 620448401733239439360000.0;
                    for (int i = 25; i <= n; ++i)
                        re *= i;
                    return re;
            }
        }

        public static double Binomial(int n, int r)
        {
            return Factorial(n) / Factorial(r) / Factorial(n - r);
        }

        public static double Mean(List<double> a)
        {
            double t = 0;
            foreach (double t1 in a)
                t += t1;
            return t / a.Count;
        }

        private static double Sum(double[] a)
        {
            double re = 0;
            foreach (double v in a)
                re += v;
            return re;
        }

        public static double GetGst(LOC[][] loc, double[] weight)
        {
            Unify(weight);

            //initialize total pop
            int L = loc[0].Length, P = loc.Length;

            double v1 = 0, v2 = 0;
            for (int l = 0; l < L; ++l)
            {
                //count total allele frequency
                Dictionary<int, double> total = new Dictionary<int, double>();
                foreach (int a in loc[0][l].allele.Keys)
                    total[a] = 0;

                double meanhs = 0;
                for (int p = 0; p < P; ++p)
                {
                    double hs = 1;
                    foreach (int a in loc[0][l].allele.Keys)
                    {
                        hs -= loc[p][l].allele[a] * loc[p][l].allele[a];
                        total[a] += loc[p][l].allele[a] * weight[p];
                    }
                    meanhs += hs * weight[p];
                }

                double ht = 1;
                foreach (int a in loc[0][l].allele.Keys)
                    ht -= total[a] * total[a];

                v1 += ht - meanhs;
                v2 += ht;
            }
            return v1 / v2;
        }

        public static List<T> Clone<T>(List<T> source)
        {
            List<T> newList = new List<T>(source.Count);
            foreach (var item in source)
                newList.Add(item);
            return newList;
        }

        public static T[] Clone<T>(T[] source)
        {
            T[] newList = new T[source.Length];
            Array.Copy(source, newList, source.Length);
            return newList;
        }

        public static T[,] Clone<T>(T[,] source)
        {
            int m = source.GetLength(0);
            int n = source.GetLength(1);
            T[,] newList = new T[m, n];
            Array.Copy(source, newList, m * n);
            return newList;
        }

        public static Dictionary<T1, T2> Clone<T1, T2>(Dictionary<T1, T2> source)
        {
            Dictionary<T1, T2> newList = new Dictionary<T1, T2>(source.Count);
            foreach (var item in source.Keys)
                newList[item] = source[item];
            return newList;
        }

        public static void SetVal<T>(T[] a, T val)
        {
            int n = a.Length;
            for (int i = 0; i < n; ++i)
                a[i] = val;
        }

        public static void SetVal<T>(T[,] a, T val)
        {
            int m = a.GetLength(0);
            int n = a.GetLength(1);
            for (int i = 0; i < m; ++i)
                for (int j = 0; j < n; ++j)
                    a[i, j] = val;
        }

        public static void SetVal<T>(T[,] a, int i, T val)
        {
            int n = a.GetLength(1);
            for (int j = 0; j < n; ++j)
                a[i, j] = val;
        }

        public static void SetVal<T>(T[] a, T[] b, int st, int n)
        {
            n += st;
            for (int i = st; i < n; ++i)
                a[i] = b[i];
        }

        public static void SetVal<T>(T[,] a, int i, T[] val)
        {
            int n = a.GetLength(1);
            for (int j = 0; j < n; ++j)
                a[i, j] = val[j];
        }

        public static void SetVal<T1, T2>(Dictionary<T1, T2> a, Dictionary<T1, T2> r, T2 val)
        {
            foreach (T1 v in r.Keys)
                a[v] = val;
        }

        public static void Unify<T>(Dictionary<T, double> a)
        {
            double s = 0;
            foreach (double v in a.Values)
                s += v + 1e-10;
            s = 1.0 / s;
            foreach (T k in a.Keys.ToArray())
                a[k] = (a[k] + 1e-10) * s;
        }

        public static void Unify(LOC[] loci)
        {
            foreach (LOC lo in loci)
                Unify(lo);
        }

        public static void Unify(LOC locus)
        {
            Unify(locus.allele);
        }

        public static void Unify(List<double> a)
        {
            double s = 0;
            for (int i = 0; i < a.Count; ++i)
                s += a[i] + 1e-10;
            s = 1.0 / s;
            for (int i = 0; i < a.Count; ++i)
                a[i] = (a[i] + 1e-10) * s;
        }

        public static void Unify(double[] a)
        {
            double s = 0;
            for (int i = 0; i < a.Length; ++i)
                s += a[i] + 1e-10;
            s = 1.0 / s;
            for (int i = 0; i < a.Length; ++i)
                a[i] = (a[i] + 1e-10) * s;
        }

        public static void Unify(double[,] a)
        {
            int m = a.GetLength(0), n = a.GetLength(1);
            for (int i = 0; i < m; ++i)
            {
                double s = 0;
                for (int j = 0; j < n; ++j)
                    s += a[i, j] + 1e-10;
                s = 1.0 / s;
                for (int j = 0; j < n; ++j)
                    a[i, j] = (a[i, j] + 1e-10) * s;
            }
        }

        public static string GetPhenotype(List<int> obs)
        {
            if (obs.Count == 0)
            {
                return "Empty";
            }
            else
            {
                obs.Sort();
                string re = "";
                for (int i = 0; i < obs.Count - 1; ++i)
                    re += obs[i] + ",";
                re += obs[obs.Count - 1];
                return re;
            }
        }
        #endregion

        #region PREDICT

        private bool InitializeInference()
        {
            all = new POP(ref PHENO_INPUT);
            return all.loc != null;
        }

        private void Inference()
        {
            if (runstate == runstates.running && !InitializeInference())
            {
                runstate = runstates.end;
                return;
            }
            all.Iteration();
            all.Outcome(false, 0);
            runstate = runstates.end;
        }

        private void Stepwise()
        {
            if (runstate != runstates.pauseend)
            {
                //first run
                runstate = runstates.running;
                if (!InitializeInference())
                {
                    runstate = runstates.end;
                    return;
                }

                //prepare phenotype count
                all.chainlen = 0;
                foreach (int v in CANDIDATE_PLOIDY)
                    for (int l = 0; l < all.L; ++l)
                        foreach (IND ind in all.inds)
                            all.phenotypes[v, l][ind.phenotypes[l].hash].count += ind.pr[v];
            }

            runstate = runstates.running;
            all.IterationStepwise();
            all.Outcome(false, 0);
            if (runstate != runstates.notstart)
                runstate = runstates.pause;
        }
        #endregion

        #region CLASS
        public class GENOTYPE
        {
            public Dictionary<int, int> alleles = new Dictionary<int, int>();//<allele id, allele copy>
            public int[] alleles2; //in descending order of allele copies
            public int nfalse;
            public long allelepattern = 0; //each 16-bit digit denote the number of allele copies, in descending order, e.g. 0x31 denotes genotype AAAB 

            public double hwecoef
            {
                get
                {
                    switch (allelepattern)
                    {
                        default: return 1;
                        case 0x1: return 1.0;
                        case 0x2: return 1.0;
                        case 0x11: return 2.0;
                        case 0x3: return 1.0;
                        case 0x21: return 3.0;
                        case 0x111: return 6.0;
                        case 0x4: return 1.0;
                        case 0x31: return 4.0;
                        case 0x22: return 6.0;
                        case 0x211: return 12.0;
                        case 0x1111: return 24.0;
                        case 0x5: return 1.0;
                        case 0x41: return 5.0;
                        case 0x32: return 10.0;
                        case 0x311: return 20.0;
                        case 0x221: return 30.0;
                        case 0x2111: return 60.0;
                        case 0x11111: return 120.0;
                        case 0x6: return 1.0;
                        case 0x51: return 6.0;
                        case 0x42: return 15.0;
                        case 0x411: return 30.0;
                        case 0x33: return 20.0;
                        case 0x321: return 60.0;
                        case 0x3111: return 120.0;
                        case 0x222: return 90.0;
                        case 0x2211: return 180.0;
                        case 0x21111: return 360.0;
                        case 0x111111: return 720.0;
                        case 0x7: return 1.0;
                        case 0x61: return 7.0;
                        case 0x52: return 21.0;
                        case 0x511: return 42.0;
                        case 0x43: return 35.0;
                        case 0x421: return 105.0;
                        case 0x4111: return 210.0;
                        case 0x331: return 140.0;
                        case 0x322: return 210.0;
                        case 0x3211: return 420.0;
                        case 0x31111: return 840.0;
                        case 0x2221: return 630.0;
                        case 0x22111: return 1260.0;
                        case 0x211111: return 2520.0;
                        case 0x1111111: return 5040.0;
                        case 0x8: return 1.0;
                        case 0x71: return 8.0;
                        case 0x62: return 28.0;
                        case 0x611: return 56.0;
                        case 0x53: return 56.0;
                        case 0x521: return 168.0;
                        case 0x5111: return 336.0;
                        case 0x44: return 70.0;
                        case 0x431: return 280.0;
                        case 0x422: return 420.0;
                        case 0x4211: return 840.0;
                        case 0x41111: return 1680.0;
                        case 0x332: return 560.0;
                        case 0x3311: return 1120.0;
                        case 0x3221: return 1680.0;
                        case 0x32111: return 3360.0;
                        case 0x311111: return 6720.0;
                        case 0x2222: return 2520.0;
                        case 0x22211: return 5040.0;
                        case 0x221111: return 10080.0;
                        case 0x2111111: return 20160.0;
                        case 0x11111111: return 40320.0;
                        case 0x9: return 1.0;
                        case 0x81: return 9.0;
                        case 0x72: return 36.0;
                        case 0x711: return 72.0;
                        case 0x63: return 84.0;
                        case 0x621: return 252.0;
                        case 0x6111: return 504.0;
                        case 0x54: return 126.0;
                        case 0x531: return 504.0;
                        case 0x522: return 756.0;
                        case 0x5211: return 1512.0;
                        case 0x51111: return 3024.0;
                        case 0x441: return 630.0;
                        case 0x432: return 1260.0;
                        case 0x4311: return 2520.0;
                        case 0x4221: return 3780.0;
                        case 0x42111: return 7560.0;
                        case 0x411111: return 15120.0;
                        case 0x333: return 1680.0;
                        case 0x3321: return 5040.0;
                        case 0x33111: return 10080.0;
                        case 0x3222: return 7560.0;
                        case 0x32211: return 15120.0;
                        case 0x321111: return 30240.0;
                        case 0x3111111: return 60480.0;
                        case 0x22221: return 22680.0;
                        case 0x222111: return 45360.0;
                        case 0x2211111: return 90720.0;
                        case 0x21111111: return 181440.0;
                        case 0x111111111: return 362880.0;
                        case 0xA: return 1.0;
                        case 0x91: return 10.0;
                        case 0x82: return 45.0;
                        case 0x811: return 90.0;
                        case 0x73: return 120.0;
                        case 0x721: return 360.0;
                        case 0x7111: return 720.0;
                        case 0x64: return 210.0;
                        case 0x631: return 840.0;
                        case 0x622: return 1260.0;
                        case 0x6211: return 2520.0;
                        case 0x61111: return 5040.0;
                        case 0x55: return 252.0;
                        case 0x541: return 1260.0;
                        case 0x532: return 2520.0;
                        case 0x5311: return 5040.0;
                        case 0x5221: return 7560.0;
                        case 0x52111: return 15120.0;
                        case 0x511111: return 30240.0;
                        case 0x442: return 3150.0;
                        case 0x4411: return 6300.0;
                        case 0x433: return 4200.0;
                        case 0x4321: return 12600.0;
                        case 0x43111: return 25200.0;
                        case 0x4222: return 18900.0;
                        case 0x42211: return 37800.0;
                        case 0x421111: return 75600.0;
                        case 0x4111111: return 151200.0;
                        case 0x3331: return 16800.0;
                        case 0x3322: return 25200.0;
                        case 0x33211: return 50400.0;
                        case 0x331111: return 100800.0;
                        case 0x32221: return 75600.0;
                        case 0x322111: return 151200.0;
                        case 0x3211111: return 302400.0;
                        case 0x31111111: return 604800.0;
                        case 0x22222: return 113400.0;
                        case 0x222211: return 226800.0;
                        case 0x2221111: return 453600.0;
                        case 0x22111111: return 907200.0;
                        case 0x211111111: return 1814400.0;
                        case 0x1111111111: return 3628800.0;
                    }
                }
            }

            public double GFZ(Dictionary<int, double> fre, double[] alpha, int v)
            {
                if (alleles2.Length == 0) return 0;
                if (DR_MODE == 0 || v <= 2 || v % 2 == 1)
                {
                    double re = hwecoef;
                    foreach (var b in alleles)
                        re *= Math.Pow(fre[b.Key], b.Value);
                    return re;
                }

                switch (v)
                {
                    case 4:
                        switch (allelepattern)
                        {
                            case 0x4: return GFZ4_iiii(alpha[1], fre[alleles2[0]]);
                            case 0x31: return GFZ4_iiij(alpha[1], fre[alleles2[0]], fre[alleles2[1]]);
                            case 0x22: return GFZ4_iijj(alpha[1], fre[alleles2[0]], fre[alleles2[1]]);
                            case 0x211: return GFZ4_iijk(alpha[1], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]]);
                            case 0x1111: return GFZ4_ijkl(alpha[1], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]]);
                        }
                        return -1;
                    case 6:
                        switch (allelepattern)
                        {
                            case 0x6: return GFZ6_iiiiii(alpha[1], fre[alleles2[0]]);
                            case 0x51: return GFZ6_iiiiij(alpha[1], fre[alleles2[0]], fre[alleles2[1]]);
                            case 0x42: return GFZ6_iiiijj(alpha[1], fre[alleles2[0]], fre[alleles2[1]]);
                            case 0x411: return GFZ6_iiiijk(alpha[1], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]]);
                            case 0x33: return GFZ6_iiijjj(alpha[1], fre[alleles2[0]], fre[alleles2[1]]);
                            case 0x321: return GFZ6_iiijjk(alpha[1], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]]);
                            case 0x3111: return GFZ6_iiijkl(alpha[1], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]]);
                            case 0x222: return GFZ6_iijjkk(alpha[1], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]]);
                            case 0x2211: return GFZ6_iijjkl(alpha[1], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]]);
                            case 0x21111: return GFZ6_iijklm(alpha[1], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]]);
                            case 0x111111: return GFZ6_ijklmn(alpha[1], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]], fre[alleles2[5]]);
                            default: return -1;
                        }
                    case 8:
                        switch (allelepattern)
                        {
                            case 0x8: return GFZ8_iiiiiiii(alpha[1], alpha[2], fre[alleles2[0]]);
                            case 0x71: return GFZ8_iiiiiiij(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]]);
                            case 0x62: return GFZ8_iiiiiijj(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]]);
                            case 0x611: return GFZ8_iiiiiijk(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]]);
                            case 0x53: return GFZ8_iiiiijjj(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]]);
                            case 0x521: return GFZ8_iiiiijjk(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]]);
                            case 0x5111: return GFZ8_iiiiijkl(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]]);
                            case 0x44: return GFZ8_iiiijjjj(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]]);
                            case 0x431: return GFZ8_iiiijjjk(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]]);
                            case 0x422: return GFZ8_iiiijjkk(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]]);
                            case 0x4211: return GFZ8_iiiijjkl(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]]);
                            case 0x41111: return GFZ8_iiiijklm(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]]);
                            case 0x332: return GFZ8_iiijjjkk(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]]);
                            case 0x3311: return GFZ8_iiijjjkl(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]]);
                            case 0x3221: return GFZ8_iiijjkkl(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]]);
                            case 0x32111: return GFZ8_iiijjklm(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]]);
                            case 0x311111: return GFZ8_iiijklmn(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]], fre[alleles2[5]]);
                            case 0x2222: return GFZ8_iijjkkll(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]]);
                            case 0x22211: return GFZ8_iijjkklm(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]]);
                            case 0x221111: return GFZ8_iijjklmn(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]], fre[alleles2[5]]);
                            case 0x2111111: return GFZ8_iijklmno(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]], fre[alleles2[5]], fre[alleles2[6]]);
                            case 0x11111111: return GFZ8_ijklmnop(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]], fre[alleles2[5]], fre[alleles2[6]], fre[alleles2[7]]);
                            default: return -1;
                        }
                    case 10:
                        switch (allelepattern)
                        {
                            case 0xA: return GFZ10_iiiiiiiiii(alpha[1], alpha[2], fre[alleles2[0]]);
                            case 0x91: return GFZ10_iiiiiiiiij(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]]);
                            case 0x82: return GFZ10_iiiiiiiijj(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]]);
                            case 0x811: return GFZ10_iiiiiiiijk(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]]);
                            case 0x73: return GFZ10_iiiiiiijjj(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]]);
                            case 0x721: return GFZ10_iiiiiiijjk(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]]);
                            case 0x7111: return GFZ10_iiiiiiijkl(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]]);
                            case 0x64: return GFZ10_iiiiiijjjj(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]]);
                            case 0x631: return GFZ10_iiiiiijjjk(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]]);
                            case 0x622: return GFZ10_iiiiiijjkk(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]]);
                            case 0x6211: return GFZ10_iiiiiijjkl(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]]);
                            case 0x61111: return GFZ10_iiiiiijklm(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]]);
                            case 0x55: return GFZ10_iiiiijjjjj(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]]);
                            case 0x541: return GFZ10_iiiiijjjjk(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]]);
                            case 0x532: return GFZ10_iiiiijjjkk(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]]);
                            case 0x5311: return GFZ10_iiiiijjjkl(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]]);
                            case 0x5221: return GFZ10_iiiiijjkkl(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]]);
                            case 0x52111: return GFZ10_iiiiijjklm(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]]);
                            case 0x511111: return GFZ10_iiiiijklmn(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]], fre[alleles2[5]]);
                            case 0x442: return GFZ10_iiiijjjjkk(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]]);
                            case 0x4411: return GFZ10_iiiijjjjkl(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]]);
                            case 0x433: return GFZ10_iiiijjjkkk(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]]);
                            case 0x4321: return GFZ10_iiiijjjkkl(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]]);
                            case 0x43111: return GFZ10_iiiijjjklm(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]]);
                            case 0x4222: return GFZ10_iiiijjkkll(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]]);
                            case 0x42211: return GFZ10_iiiijjkklm(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]]);
                            case 0x421111: return GFZ10_iiiijjklmn(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]], fre[alleles2[5]]);
                            case 0x4111111: return GFZ10_iiiijklmno(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]], fre[alleles2[5]], fre[alleles2[6]]);
                            case 0x3331: return GFZ10_iiijjjkkkl(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]]);
                            case 0x3322: return GFZ10_iiijjjkkll(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]]);
                            case 0x33211: return GFZ10_iiijjjkklm(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]]);
                            case 0x331111: return GFZ10_iiijjjklmn(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]], fre[alleles2[5]]);
                            case 0x32221: return GFZ10_iiijjkkllm(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]]);
                            case 0x322111: return GFZ10_iiijjkklmn(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]], fre[alleles2[5]]);
                            case 0x3211111: return GFZ10_iiijjklmno(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]], fre[alleles2[5]], fre[alleles2[6]]);
                            case 0x31111111: return GFZ10_iiijklmnop(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]], fre[alleles2[5]], fre[alleles2[6]], fre[alleles2[7]]);
                            case 0x22222: return GFZ10_iijjkkllmm(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]]);
                            case 0x222211: return GFZ10_iijjkkllmn(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]], fre[alleles2[5]]);
                            case 0x2221111: return GFZ10_iijjkklmno(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]], fre[alleles2[5]], fre[alleles2[6]]);
                            case 0x22111111: return GFZ10_iijjklmnop(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]], fre[alleles2[5]], fre[alleles2[6]], fre[alleles2[7]]);
                            case 0x211111111: return GFZ10_iijklmnopq(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]], fre[alleles2[5]], fre[alleles2[6]], fre[alleles2[7]], fre[alleles2[8]]);
                            case 0x1111111111: return GFZ10_ijklmnopqr(alpha[1], alpha[2], fre[alleles2[0]], fre[alleles2[1]], fre[alleles2[2]], fre[alleles2[3]], fre[alleles2[4]], fre[alleles2[5]], fre[alleles2[6]], fre[alleles2[7]], fre[alleles2[8]], fre[alleles2[9]]);
                            default: return -1;
                        }
                }
                return -1;
            }

            public double GFZ(Dictionary<int, double> fre, double f, int v)
            {
                //RCS + inbreeding
                if (alleles2.Length == 0) return 0;
                if (f <= 1e-20) f = 1e-20;
                if (f >= 0.99999999999999) f = 0.99999999999999;

                double re = hwecoef;
                double re2 = 1;                f = 1.0 / f - 1;
                foreach (var b in alleles)
                    for (int j = 0; j < b.Value; ++j)
                        re *= fre[b.Key] * f + j;
                for (int j = 0; j < v; ++j)
                    re2 *= f + j;
                return re / re2;
            }

            public GENOTYPE(int[] als)
            {
                foreach (int a in als)
                {
                    if (alleles.ContainsKey(a))
                        alleles[a]++;
                    else
                        alleles[a] = 1;
                }
                alleles2 = new int[alleles.Count];
                int c = 0;
                allelepattern = 0;
                foreach (var a in from o in alleles orderby o.Value descending select o)
                {
                    alleles2[c++] = a.Key;
                    allelepattern = (allelepattern << 4) | (long)a.Value;
                }
            }

            public GENOTYPE(int[] als, List<int> obs)
            {
                foreach (int a in als)
                {
                    if (alleles.ContainsKey(a))
                        alleles[a]++;
                    else
                        alleles[a] = 1;
                }

                nfalse = 0;
                foreach (int a in obs)
                    if (!alleles.ContainsKey(a))
                        nfalse++;

                alleles2 = new int[alleles.Count];

                int c = 0;
                allelepattern = 0;
                foreach (var a in from o in alleles orderby o.Value descending select o)
                {
                    alleles2[c++] = a.Key;
                    allelepattern = (allelepattern << 4) | (long)a.Value;
                }
            }
        }

        public class PHENOTYPE
        {
            public double count;//phenotype count without truncation
            public double count_trun;//truncated phenotype count (each individual is only assigned to one ploidy level)
            public double log;//em algorithm
            public double spr;

            public int hash;
            public int[] allele;//genotype, in simulation
            public List<int> obsallele = new List<int>();//phenotype, in analysis
            public List<GENOTYPE>[] genotypes = new List<GENOTYPE>[MAX_PLOIDY_USED + 1];

            private int maxc;
            private int obsc;
            private int[] tals;

            public double PFZSub(Dictionary<int, double> fre, double beta, double[] alpha, int v)
            {
                if (!CONSIDER_NULL)
                {
                    switch (v)
                    {
                        case 1:
                            switch (obsallele.Count)
                            {
                                case 0: return beta;
                                case 1: return (1 - beta) * fre[obsallele[0]];
                            }
                            break;
                        case 2:
                            switch (obsallele.Count)
                            {
                                case 0: return beta;
                                case 1: return (1 - beta) * fre[obsallele[0]] * fre[obsallele[0]];
                                case 2: return (1 - beta) * 2 * fre[obsallele[0]] * fre[obsallele[1]];
                            }
                            break;
                        case 3:
                            switch (obsallele.Count)
                            {
                                case 0: return beta;
                                case 1: return (1 - beta) * PFZ3_i(fre[obsallele[0]]);
                                case 2: return (1 - beta) * PFZ3_ij(fre[obsallele[0]], fre[obsallele[1]]);
                                case 3: return (1 - beta) * PFZ3_ijk(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]]);
                            }
                            break;
                        case 4:
                            switch (obsallele.Count)
                            {
                                case 0: return beta;
                                case 1: return (1 - beta) * PFZ4_i(alpha[1], fre[obsallele[0]]);
                                case 2: return (1 - beta) * PFZ4_ij(alpha[1], fre[obsallele[0]], fre[obsallele[1]]);
                                case 3: return (1 - beta) * PFZ4_ijk(alpha[1], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]]);
                                case 4: return (1 - beta) * PFZ4_ijkl(alpha[1], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]]);
                            }
                            break;
                        case 5:
                            switch (obsallele.Count)
                            {
                                case 0: return beta;
                                case 1: return (1 - beta) * PFZ5_i(fre[obsallele[0]]);
                                case 2: return (1 - beta) * PFZ5_ij(fre[obsallele[0]], fre[obsallele[1]]);
                                case 3: return (1 - beta) * PFZ5_ijk(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]]);
                                case 4: return (1 - beta) * PFZ5_ijkl(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]]);
                                case 5: return (1 - beta) * PFZ5_ijklm(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]]);
                            }
                            break;
                        case 6:
                            switch (obsallele.Count)
                            {
                                case 0: return beta;
                                case 1: return (1 - beta) * PFZ6_i(alpha[1], fre[obsallele[0]]);
                                case 2: return (1 - beta) * PFZ6_ij(alpha[1], fre[obsallele[0]], fre[obsallele[1]]);
                                case 3: return (1 - beta) * PFZ6_ijk(alpha[1], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]]);
                                case 4: return (1 - beta) * PFZ6_ijkl(alpha[1], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]]);
                                case 5: return (1 - beta) * PFZ6_ijklm(alpha[1], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]]);
                                case 6: return (1 - beta) * PFZ6_ijklmn(alpha[1], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]]);
                            }
                            break;
                        case 7:
                            switch (obsallele.Count)
                            {
                                case 0: return beta;
                                case 1: return (1 - beta) * PFZ7_i(fre[obsallele[0]]);
                                case 2: return (1 - beta) * PFZ7_ij(fre[obsallele[0]], fre[obsallele[1]]);
                                case 3: return (1 - beta) * PFZ7_ijk(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]]);
                                case 4: return (1 - beta) * PFZ7_ijkl(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]]);
                                case 5: return (1 - beta) * PFZ7_ijklm(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]]);
                                case 6: return (1 - beta) * PFZ7_ijklmn(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]]);
                                case 7: return (1 - beta) * PFZ7_ijklmno(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]]);
                            }
                            break;
                        case 8:
                            switch (obsallele.Count)
                            {
                                case 0: return beta;
                                case 1: return (1 - beta) * PFZ8_i(alpha[1], alpha[2], fre[obsallele[0]]);
                                case 2: return (1 - beta) * PFZ8_ij(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]]);
                                case 3: return (1 - beta) * PFZ8_ijk(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]]);
                                case 4: return (1 - beta) * PFZ8_ijkl(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]]);
                                case 5: return (1 - beta) * PFZ8_ijklm(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]]);
                                case 6: return (1 - beta) * PFZ8_ijklmn(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]]);
                                case 7: return (1 - beta) * PFZ8_ijklmno(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]]);
                                case 8: return (1 - beta) * PFZ8_ijklmnop(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]], fre[obsallele[7]]);
                            }
                            break;
                        case 9:
                            switch (obsallele.Count)
                            {
                                case 0: return beta;
                                case 1: return (1 - beta) * PFZ9_i(fre[obsallele[0]]);
                                case 2: return (1 - beta) * PFZ9_ij(fre[obsallele[0]], fre[obsallele[1]]);
                                case 3: return (1 - beta) * PFZ9_ijk(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]]);
                                case 4: return (1 - beta) * PFZ9_ijkl(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]]);
                                case 5: return (1 - beta) * PFZ9_ijklm(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]]);
                                case 6: return (1 - beta) * PFZ9_ijklmn(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]]);
                                case 7: return (1 - beta) * PFZ9_ijklmno(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]]);
                                case 8: return (1 - beta) * PFZ9_ijklmnop(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]], fre[obsallele[7]]);
                                case 9: return (1 - beta) * PFZ9_ijklmnopq(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]], fre[obsallele[7]], fre[obsallele[8]]);
                            }
                            break;
                        case 10:
                            switch (obsallele.Count)
                            {
                                case 0: return beta;
                                case 1: return (1 - beta) * PFZ10_i(alpha[1], alpha[2], fre[obsallele[0]]);
                                case 2: return (1 - beta) * PFZ10_ij(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]]);
                                case 3: return (1 - beta) * PFZ10_ijk(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]]);
                                case 4: return (1 - beta) * PFZ10_ijkl(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]]);
                                case 5: return (1 - beta) * PFZ10_ijklm(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]]);
                                case 6: return (1 - beta) * PFZ10_ijklmn(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]]);
                                case 7: return (1 - beta) * PFZ10_ijklmno(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]]);
                                case 8: return (1 - beta) * PFZ10_ijklmnop(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]], fre[obsallele[7]]);
                                case 9: return (1 - beta) * PFZ10_ijklmnopq(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]], fre[obsallele[7]], fre[obsallele[8]]);
                                case 10: return (1 - beta) * PFZ10_ijklmnopqr(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]], fre[obsallele[7]], fre[obsallele[8]], fre[obsallele[9]]);
                            }
                            break;
                    }
                }
                else
                {
                    switch (v)
                    {
                        case 1:
                            switch (obsallele.Count)
                            {
                                case 0: return beta + (1 - beta) * fre[NULL_ALLELE];
                                case 1: return (1 - beta) * fre[obsallele[0]];
                            }
                            break;
                        case 2:
                            switch (obsallele.Count)
                            {
                                case 0: return beta + (1 - beta) * fre[NULL_ALLELE] * fre[NULL_ALLELE];
                                case 1: return (1 - beta) * (fre[obsallele[0]] * fre[obsallele[0]] + 2 * fre[obsallele[0]] * fre[NULL_ALLELE]);
                                case 2: return (1 - beta) * (2 * fre[obsallele[0]] * fre[obsallele[1]]);
                            }
                            break;
                        case 3:
                            switch (obsallele.Count)
                            {
                                case 0: return beta + (1 - beta) * fre[NULL_ALLELE] * fre[NULL_ALLELE] * fre[NULL_ALLELE];
                                case 1: return (1 - beta) * (PFZ3_i(fre[obsallele[0]]) + PFZ3_ij(fre[obsallele[0]], fre[NULL_ALLELE]));
                                case 2: return (1 - beta) * (PFZ3_ij(fre[obsallele[0]], fre[obsallele[1]]) + PFZ3_ijk(fre[obsallele[0]], fre[obsallele[1]], fre[NULL_ALLELE]));
                                case 3: return (1 - beta) * (PFZ3_ijk(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]]));
                            }
                            break;
                        case 4:
                            switch (obsallele.Count)
                            {
                                case 0: return beta + (1 - beta) * PFZ4_i(alpha[1], fre[NULL_ALLELE]);
                                case 1: return (1 - beta) * (PFZ4_i(alpha[1], fre[obsallele[0]]) + PFZ4_ij(alpha[1], fre[obsallele[0]], fre[NULL_ALLELE]));
                                case 2: return (1 - beta) * (PFZ4_ij(alpha[1], fre[obsallele[0]], fre[obsallele[1]]) + PFZ4_ijk(alpha[1], fre[obsallele[0]], fre[obsallele[1]], fre[NULL_ALLELE]));
                                case 3: return (1 - beta) * (PFZ4_ijk(alpha[1], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]]) + PFZ4_ijkl(alpha[1], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[NULL_ALLELE]));
                                case 4: return (1 - beta) * (PFZ4_ijkl(alpha[1], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]]));
                            }
                            break;
                        case 5:
                            switch (obsallele.Count)
                            {
                                case 0: return beta + (1 - beta) * Math.Pow(fre[NULL_ALLELE], 5);
                                case 1: return (1 - beta) * (PFZ5_i(fre[obsallele[0]]) + PFZ5_ij(fre[obsallele[0]], fre[NULL_ALLELE]));
                                case 2: return (1 - beta) * (PFZ5_ij(fre[obsallele[0]], fre[obsallele[1]]) + PFZ5_ijk(fre[obsallele[0]], fre[obsallele[1]], fre[NULL_ALLELE]));
                                case 3: return (1 - beta) * (PFZ5_ijk(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]]) + PFZ5_ijkl(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[NULL_ALLELE]));
                                case 4: return (1 - beta) * (PFZ5_ijkl(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]]) + PFZ5_ijklm(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[NULL_ALLELE]));
                                case 5: return (1 - beta) * (PFZ5_ijklm(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]]));
                            }
                            break;
                        case 6:
                            switch (obsallele.Count)
                            {
                                case 0: return beta + (1 - beta) * PFZ6_i(alpha[1], fre[NULL_ALLELE]);
                                case 1: return (1 - beta) * (PFZ6_i(alpha[1], fre[obsallele[0]]) + PFZ6_ij(alpha[1], fre[obsallele[0]], fre[NULL_ALLELE]));
                                case 2: return (1 - beta) * (PFZ6_ij(alpha[1], fre[obsallele[0]], fre[obsallele[1]]) + PFZ6_ijk(alpha[1], fre[obsallele[0]], fre[obsallele[1]], fre[NULL_ALLELE]));
                                case 3: return (1 - beta) * (PFZ6_ijk(alpha[1], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]]) + PFZ6_ijkl(alpha[1], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[NULL_ALLELE]));
                                case 4: return (1 - beta) * (PFZ6_ijkl(alpha[1], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]]) + PFZ6_ijklm(alpha[1], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[NULL_ALLELE]));
                                case 5: return (1 - beta) * (PFZ6_ijklm(alpha[1], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]]) + PFZ6_ijklmn(alpha[1], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[NULL_ALLELE]));
                                case 6: return (1 - beta) * (PFZ6_ijklmn(alpha[1], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]]));
                            }
                            break;
                        case 7:
                            switch (obsallele.Count)
                            {
                                case 0: return beta + (1 - beta) * Math.Pow(fre[NULL_ALLELE], 7);
                                case 1: return (1 - beta) * (PFZ7_i(fre[obsallele[0]]) + PFZ7_ij(fre[obsallele[0]], fre[NULL_ALLELE]));
                                case 2: return (1 - beta) * (PFZ7_ij(fre[obsallele[0]], fre[obsallele[1]]) + PFZ7_ijk(fre[obsallele[0]], fre[obsallele[1]], fre[NULL_ALLELE]));
                                case 3: return (1 - beta) * (PFZ7_ijk(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]]) + PFZ7_ijkl(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[NULL_ALLELE]));
                                case 4: return (1 - beta) * (PFZ7_ijkl(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]]) + PFZ7_ijklm(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[NULL_ALLELE]));
                                case 5: return (1 - beta) * (PFZ7_ijklm(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]]) + PFZ7_ijklmn(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[NULL_ALLELE]));
                                case 6: return (1 - beta) * (PFZ7_ijklmn(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]]) + PFZ7_ijklmno(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[NULL_ALLELE]));
                                case 7: return (1 - beta) * (PFZ7_ijklmno(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]]));
                            }
                            break;
                        case 8:
                            switch (obsallele.Count)
                            {
                                case 0: return beta + (1 - beta) * PFZ8_i(alpha[1], alpha[2], fre[NULL_ALLELE]);
                                case 1: return (1 - beta) * (PFZ8_i(alpha[1], alpha[2], fre[obsallele[0]]) + PFZ8_ij(alpha[1], alpha[2], fre[obsallele[0]], fre[NULL_ALLELE]));
                                case 2: return (1 - beta) * (PFZ8_ij(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]]) + PFZ8_ijk(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[NULL_ALLELE]));
                                case 3: return (1 - beta) * (PFZ8_ijk(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]]) + PFZ8_ijkl(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[NULL_ALLELE]));
                                case 4: return (1 - beta) * (PFZ8_ijkl(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]]) + PFZ8_ijklm(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[NULL_ALLELE]));
                                case 5: return (1 - beta) * (PFZ8_ijklm(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]]) + PFZ8_ijklmn(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[NULL_ALLELE]));
                                case 6: return (1 - beta) * (PFZ8_ijklmn(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]]) + PFZ8_ijklmno(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[NULL_ALLELE]));
                                case 7: return (1 - beta) * (PFZ8_ijklmno(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]]) + PFZ8_ijklmnop(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]], fre[NULL_ALLELE]));
                                case 8: return (1 - beta) * (PFZ8_ijklmnop(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]], fre[obsallele[7]]));
                            }
                            break;
                        case 9:
                            switch (obsallele.Count)
                            {
                                case 0: return beta + (1 - beta) * Math.Pow(fre[NULL_ALLELE], 9);
                                case 1: return (1 - beta) * (PFZ9_i(fre[obsallele[0]]) + PFZ9_ij(fre[obsallele[0]], fre[NULL_ALLELE]));
                                case 2: return (1 - beta) * (PFZ9_ij(fre[obsallele[0]], fre[obsallele[1]]) + PFZ9_ijk(fre[obsallele[0]], fre[obsallele[1]], fre[NULL_ALLELE]));
                                case 3: return (1 - beta) * (PFZ9_ijk(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]]) + PFZ9_ijkl(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[NULL_ALLELE]));
                                case 4: return (1 - beta) * (PFZ9_ijkl(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]]) + PFZ9_ijklm(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[NULL_ALLELE]));
                                case 5: return (1 - beta) * (PFZ9_ijklm(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]]) + PFZ9_ijklmn(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[NULL_ALLELE]));
                                case 6: return (1 - beta) * (PFZ9_ijklmn(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]]) + PFZ9_ijklmno(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[NULL_ALLELE]));
                                case 7: return (1 - beta) * (PFZ9_ijklmno(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]]) + PFZ9_ijklmnop(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]], fre[NULL_ALLELE]));
                                case 8: return (1 - beta) * (PFZ9_ijklmnop(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]], fre[obsallele[7]]) + PFZ9_ijklmnopq(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]], fre[obsallele[7]], fre[NULL_ALLELE]));
                                case 9: return (1 - beta) * (PFZ9_ijklmnopq(fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]], fre[obsallele[7]], fre[obsallele[8]]));
                            }
                            break;
                        case 10:
                            switch (obsallele.Count)
                            {
                                case 0: return beta + (1 - beta) * PFZ10_i(alpha[1], alpha[2], fre[NULL_ALLELE]);
                                case 1: return (1 - beta) * (PFZ10_i(alpha[1], alpha[2], fre[obsallele[0]]) + PFZ10_ij(alpha[1], alpha[2], fre[obsallele[0]], fre[NULL_ALLELE]));
                                case 2: return (1 - beta) * (PFZ10_ij(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]]) + PFZ10_ijk(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[NULL_ALLELE]));
                                case 3: return (1 - beta) * (PFZ10_ijk(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]]) + PFZ10_ijkl(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[NULL_ALLELE]));
                                case 4: return (1 - beta) * (PFZ10_ijkl(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]]) + PFZ10_ijklm(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[NULL_ALLELE]));
                                case 5: return (1 - beta) * (PFZ10_ijklm(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]]) + PFZ10_ijklmn(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[NULL_ALLELE]));
                                case 6: return (1 - beta) * (PFZ10_ijklmn(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]]) + PFZ10_ijklmno(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[NULL_ALLELE]));
                                case 7: return (1 - beta) * (PFZ10_ijklmno(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]]) + PFZ10_ijklmnop(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]], fre[NULL_ALLELE]));
                                case 8: return (1 - beta) * (PFZ10_ijklmnop(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]], fre[obsallele[7]]) + PFZ10_ijklmnopq(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]], fre[obsallele[7]], fre[NULL_ALLELE]));
                                case 9: return (1 - beta) * (PFZ10_ijklmnopq(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]], fre[obsallele[7]], fre[obsallele[8]]) + PFZ10_ijklmnopqr(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]], fre[obsallele[7]], fre[obsallele[8]], fre[NULL_ALLELE]));
                                case 10: return (1 - beta) * (PFZ10_ijklmnopqr(alpha[1], alpha[2], fre[obsallele[0]], fre[obsallele[1]], fre[obsallele[2]], fre[obsallele[3]], fre[obsallele[4]], fre[obsallele[5]], fre[obsallele[6]], fre[obsallele[7]], fre[obsallele[8]], fre[obsallele[9]]));
                            }
                            break;
                    }
                }
                return 0;
            }
            
            public double PFZFalse(LOC lo, double[] alpha, int v)
            {
                return PFZFalse(lo.allele, lo.beta, alpha, s2f(lo.s, v, lo.id), v);
            }

            public double PFZFalse(Dictionary<int, double> fre, double beta, double[] alpha, double f, int v)
            {
                double re = 0;
                double punamplified = ONEMINUS_FALSE_RATE_POWER[fre.Count - obsallele.Count - (CONSIDER_NULL ? 1 : 0)];
                if (CONSIDER_SELFING)
                { 
                    foreach (GENOTYPE gh in genotypes[v])
                        re += gh.GFZ(fre, f, v) * FALSE_RATE_POWER[gh.nfalse];
                    return Math.Max(re * (1 - beta) * punamplified, 1e-20) + (obsallele.Count == 0 ? beta : 0);
                }

                re = PFZSub(fre, beta, alpha, v) - (obsallele.Count == 0 ? beta : 0);
                
                if (obsallele.Count >= 1 && MAX_FALSE >= 1)
                {
                    double p1 = 0;
                    for (int i = 0; i < obsallele.Count; ++i)
                    {
                        int a = obsallele[i];
                        obsallele.RemoveAt(i);
                        p1 += PFZSub(fre, beta, alpha, v) - (obsallele.Count == 0 ? beta : 0);
                        obsallele.Insert(i, a);
                    }
                    re += FALSE_RATE_POWER[1] * p1;
                }

                if (obsallele.Count >= 2 && MAX_FALSE >= 2)
                {
                    double p2 = 0;
                    for (int i = 0; i < obsallele.Count; ++i)
                    {
                        int a = obsallele[i];
                        obsallele.RemoveAt(i);
                        for (int j = i; j < obsallele.Count; ++j)
                        {
                            int b = obsallele[j];
                            obsallele.RemoveAt(j);
                            p2 += PFZSub(fre, beta, alpha, v) - (obsallele.Count == 0 ? beta : 0);
                            obsallele.Insert(j, b);
                        }
                        obsallele.Insert(i, a);
                    }
                    re += FALSE_RATE_POWER[2] * p2;
                }

                if (obsallele.Count >= 3 && MAX_FALSE >= 3)
                {
                    double p3 = 0;
                    for (int i = 0; i < obsallele.Count; ++i)
                    {
                        int a = obsallele[i];
                        obsallele.RemoveAt(i);
                        for (int j = i; j < obsallele.Count; ++j)
                        {
                            int b = obsallele[j];
                            obsallele.RemoveAt(j);
                            for (int k = j; k < obsallele.Count; ++k)
                            {
                                int c = obsallele[k];
                                obsallele.RemoveAt(k);
                                p3 += PFZSub(fre, beta, alpha, v) - (obsallele.Count == 0 ? beta : 0);
                                obsallele.Insert(k, c);
                            }
                            obsallele.Insert(j, b);
                        }
                        obsallele.Insert(i, a);
                    }
                    re += FALSE_RATE_POWER[3] * p3;
                }

                if (obsallele.Count >= 4 && MAX_FALSE >= 4)
                {
                    double p4 = 0;
                    for (int i = 0; i < obsallele.Count; ++i)
                    {
                        int a = obsallele[i];
                        obsallele.RemoveAt(i);
                        for (int j = i; j < obsallele.Count; ++j)
                        {
                            int b = obsallele[j];
                            obsallele.RemoveAt(j);
                            for (int k = j; k < obsallele.Count; ++k)
                            {
                                int c = obsallele[k];
                                obsallele.RemoveAt(k);
                                for (int l = k; l < obsallele.Count; ++l)
                                {
                                    int d = obsallele[l];
                                    obsallele.RemoveAt(l);
                                    p4 += PFZSub(fre, beta, alpha, v) - (obsallele.Count == 0 ? beta : 0);
                                    obsallele.Insert(l, d);
                                }
                                obsallele.Insert(k, c);
                            }
                            obsallele.Insert(j, b);
                        }
                        obsallele.Insert(i, a);
                    }
                    re += FALSE_RATE_POWER[4] * p4;
                }

                return Math.Max(re * punamplified, 1e-20) + (obsallele.Count == 0 ? beta : 0); //prevent log(0)
            }

            public void ExtractGenotype(int p, int l)
            {
                if (genotypes[p] != null)
                    return;
                genotypes[p] = new List<GENOTYPE>();

                if (obsallele.Count > p + MAX_FALSE || (!CONSIDER_NULL && obsallele.Count == 0))
                    return;

                obsc = obsallele.Count;
                maxc = p;

                tals = new int[maxc];
                for (int i = 0; i < maxc; ++i)
                    tals[i] = -1;
                ExtractGenotypeSub(0, 0, l);

                tals = null;
            }

            private void ExtractGenotypeSub(int minindex, int cur, int l)
            {
                if (cur == maxc)
                {
                    int nfalse = obsallele.Count;
                    foreach (int a in obsallele)
                        if (tals.Contains(a))
                            nfalse--;

                    if (nfalse > MAX_FALSE)
                        return;

                    genotypes[maxc].Add(new GENOTYPE(tals, obsallele));
                    return;
                }

                for (int i = minindex; i < obsallele.Count; ++i)
                {
                    tals[cur] = obsallele[i];
                    ExtractGenotypeSub(i, cur + 1, l);
                }
                if (CONSIDER_NULL)
                {
                    tals[cur] = NULL_ALLELE;
                    ExtractGenotypeSub(obsallele.Count, cur + 1, l);
                }
            }

            public void GetHash()
            {
                obsallele.Sort();
                if (obsallele.Count == 0)
                    hash = 0;
                else
                    hash = HashIntList(obsallele);
            }
            
            public PHENOTYPE(bool isempty)
            {
                //empty phenotype
                if (isempty)
                {
                    obsallele.Add(NULL_ALLELE);
                    GetHash();
                }
            }

            public PHENOTYPE(PHENOTYPE r)
            {
                genotypes = r.genotypes;
                allele = r.allele;
                obsallele = r.obsallele;
            }

            public PHENOTYPE(int[] als)
            {
                allele = als;

                obsallele = allele.ToList();
                obsallele.Sort();
                for (int i = 1; i < obsallele.Count; ++i)
                    if (obsallele[i] == obsallele[i - 1])
                        obsallele.RemoveAt(i--);
            }

            public PHENOTYPE(List<int> obs)
            {
                obsallele = obs;
                obsallele.Sort();
                GetHash();
            }

            public PHENOTYPE(PHENOTYPE A, PHENOTYPE B, int v, double[] alpha, Random rnd)
            {
                int[] f = GetRandSequence(rnd, v);
                int[] m = GetRandSequence(rnd, v);

                //double reduction
                double mode = 0;

                mode = rnd.NextDouble();
                for (int i = 0; i <= v / 4; ++i)
                {
                    if (i > 0) f[i * 2 - 2] = f[i * 2 - 1];
                    mode -= alpha[i];
                    if (mode < 0) break;
                }

                mode = rnd.NextDouble();
                for (int i = 0; i <= v / 4; ++i)
                {
                    if (i > 0) m[i * 2 - 2] = m[i * 2 - 1];
                    mode -= alpha[i];
                    if (mode < 0) break;
                }

                allele = new int[v];
                for (int i = 0; i < v / 2; ++i)
                {
                    int tallele;
                    tallele = A.allele[f[i]];
                    allele[i * 2] = tallele;
                    if (!obsallele.Contains(tallele))
                        obsallele.Add(tallele);

                    tallele = B.allele[m[i]];
                    allele[i * 2 + 1] = tallele;
                    if (!obsallele.Contains(tallele))
                        obsallele.Add(tallele);
                }
            }
        }

        public class IND
        {
            public string name;
            public int trueploidy;
            public PHENOTYPE[] phenotypes = null;
            public bool isfixed = false;
            public double[] pr = new double[MAX_PLOIDY_USED + 1];
            public double[] pr2 = new double[MAX_PLOIDY_USED + 1];
            public int[] seq;

            public IND(int L)
            {
                phenotypes = new PHENOTYPE[L];
            }

            public IND(IND A, IND B, Random rnd)
            {
                //reproduce
                trueploidy = A.trueploidy;
                int L = A.phenotypes.Length;
                phenotypes = new PHENOTYPE[L];
                for (int l = 0; l < L; ++l)
                    phenotypes[l] = new PHENOTYPE(A.phenotypes[l], B.phenotypes[l], trueploidy, ALPHA[l, trueploidy], rnd);
            }

            public IND(LOC[] loc, Random rnd, int v, bool usegenerator)
            {
                //simulation
                trueploidy = v;
                phenotypes = new PHENOTYPE[loc.Length];
                for (int l = 0; l < loc.Length; ++l)
                    phenotypes[l] = loc[l].CreatePhenotype(rnd, v, usegenerator); 
            }

            public void WritePhenotype(Random rnd, StringBuilder w, LOC[] loc)
            {
                for (int i = 0; i < phenotypes.Length; ++i)
                {
                    w.Append("\t");
                    bool flag = false;

                    if (rnd.NextDouble() > loc[i].beta)
                    {
                        var write = phenotypes[i].obsallele.ToList();

                        int nfalse = 0;
                        foreach(var af in loc[i].allele)
                        {
                            if (phenotypes[i].obsallele.Contains(af.Key) || af.Key == NULL_ALLELE) 
                                continue;
                            if (rnd.NextDouble() < SIM_FALSE_RATE)
                            {
                                write.Add(af.Key);
                                nfalse++;
                            }
                            if (nfalse == SIM_MAX_FALSE) 
                                break;
                        }

                        foreach (int a in write)
                        {
                            if (a != NULL_ALLELE)
                            {
                                w.Append(a.ToString());
                                w.Append(",");
                                flag = true;
                            }
                        }
                    }

                    if (flag)
                        w.Remove(w.Length - 1, 1);
                }
                w.Append("\r\n");
            }

            public void WritePosterProb(StringBuilder o)
            {
                o.Append(name + "\t" + seq[0]);
                foreach (int v in CANDIDATE_PLOIDY)
                    o.Append("\t" + pr[v].ToString(DECIMAL));
                o.Append("\r\n");
            }

            public void SortPloidy()
            {
                double[] prob = new double[CANDIDATE_PLOIDY.Count];
                if (seq == null)
                    seq = new int[CANDIDATE_PLOIDY.Count];

                int c = 0;
                foreach (int v in CANDIDATE_PLOIDY)
                {
                    prob[c] = pr[v];
                    seq[c] = v;
                    c++;
                }

                for (int i = 1; i < CANDIDATE_PLOIDY.Count; ++i)
                {
                    for (int j = 0; j < i; ++j)
                    {
                        if (prob[j] < prob[i])
                        {
                            Swap(ref seq[i], ref seq[j]);
                            Swap(ref prob[i], ref prob[j]);
                        }
                    }
                }
            }
        }

        public class LOC
        {
            public int id;
            public string name = "";
            public Dictionary<int, double> allele = new Dictionary<int, double>();
            public double beta;
            public double s;
            public double rs;

            public GENERATOR_NODE root;

            public LOC(LOC lo)
            {
                id = lo.id;
                allele = Clone(lo.allele);
                name = lo.name;
                beta = lo.beta;
                rs = lo.rs;
                s = lo.s;
            }

            public LOC(int _id, string _name, Random rnd)
            {
                id = _id;
                name = _name;
                rs = SIM_DIOECIOUS ? 0.5 * (1 - Math.Exp(-2 * (rnd.NextDouble() * 100) / 100)) : 0;
                if (APP2) rs = 0.5 * (1 - Math.Exp(-2 * (rnd.NextDouble() * 100) / 100));
                beta = SIM_BETA;
                s = SIM_DIOECIOUS ? 0 : SIM_SELFING_RATIO;
            }

            public LOC(int _id, string _name, Random rnd, int k, bool py)
            {
                //APP1
                id = _id;
                name = _name;
                double[] fre = GetRDirichletOne(rnd, k);
                if (py)
                {
                    allele[NULL_ALLELE] = fre[0];
                    for (int a = 1; a < fre.Length; ++a)
                        allele[a] = fre[a];
                }
                else
                {
                    for (int a = 0; a < fre.Length; ++a)
                        allele[a + 1] = fre[a];
                }
                rs = 0.5 * (1 - Math.Exp(-2 * (rnd.NextDouble() * 100) / 100));
                beta = SIM_BETA;
                s = SIM_DIOECIOUS ? 0 : SIM_SELFING_RATIO;
            }

            public LOC(int _id, string _name, double _beta, double _rs, double _s)
            {
                id = _id;
                //analysis
                name = _name;
                beta = _beta;
                rs = _rs;
                s = _s;
            }

            public class GENERATOR_NODE
            {
                public double sumprob;
                public Dictionary<int, GENERATOR_NODE> nodes;
            }

            public void InitializeGenerator(int v)
            {
                //to generate genotypes according to dre
                root = new GENERATOR_NODE();

                List<int> g_alleles2 = allele.Keys.ToList();
                g_alleles2.Sort();
                int[] alleles = g_alleles2.ToArray();
                int[] genotype = new int[v];
                SetVal(genotype, -999);
                GeneratorSub(0, v, 0, root, alleles, genotype);
            }

            private double GeneratorSub(int clay, int v, int cidx, GENERATOR_NODE node, int[] alleles, int[] genotype)
            {
                if (clay == v)
                {
                    GENOTYPE gb = new GENOTYPE(genotype);
                    node.sumprob = SIM_DIOECIOUS ? gb.GFZ(allele, ALPHA[id, v], v) : gb.GFZ(allele, s2f(SIM_SELFING_RATIO, v, id), v);
                }
                else
                {
                    node.nodes = new Dictionary<int, GENERATOR_NODE>();
                    for (int i = cidx; i < alleles.Length; ++i)
                    {
                        genotype[clay] = alleles[i];
                        node.nodes[genotype[clay]] = new GENERATOR_NODE();
                        node.sumprob += GeneratorSub(clay + 1, v, i, node.nodes[genotype[clay]], alleles, genotype);
                        if (node.sumprob == 0)
                            node.nodes.Remove(genotype[clay]);
                    }
                    for (int i = cidx; i < alleles.Length; ++i)
                    {
                        var t = node.nodes[alleles[i]];
                        t.sumprob /= node.sumprob;
                    }
                }
                return node.sumprob;
            }

            public int GetRandomAllele(Random rnd)
            {
                if (allele.Count == 0)
                    return -999;
                double m = rnd.NextDouble();
                int kbak = 0;
                foreach (int k in allele.Keys)
                {
                    if (m < allele[k])
                        return k;
                    else
                    {
                        kbak = k;
                        m -= allele[k];
                    }
                }
                return kbak;
            }

            public PHENOTYPE CreatePhenotype(Random rnd, int v, bool usegenerator)
            {
                //simulation
                //get genotype as phenotype
                int[] alleles = new int[v];
                if (usegenerator)
                {
                    if (root == null)
                        InitializeGenerator(v);

                    //DRE mode
                    GENERATOR_NODE node = root;
                    for (int i = 0; i < v; ++i)
                    {
                        double mode = rnd.NextDouble();
                        foreach (var a in node.nodes)
                        {
                            if (mode < a.Value.sumprob)
                            {
                                alleles[i] = a.Key;
                                node = a.Value;
                                break;
                            }
                            else
                                mode -= a.Value.sumprob;
                        }
                    }
                }
                else
                {
                    for (int i = 0; i < v; ++i)
                        alleles[i] = GetRandomAllele(rnd);
                }
                //alleles.Sort();
                return new PHENOTYPE(alleles);
            }
        }

        public class POP
        {
            public int v, k, n, L, lnLcount, npar;
            public double lnL = 0, lnL_trun = 0, AIC = 0, AIC_trun = 0, AICc = 0, AICc_trun = 0, BIC = 0, BIC_trun = 0;
            public int npheno = 0;
            public int chainlen = 0;
            public LOC[] loc;
            public LOC[][] loc2;

            public List<IND> inds = new List<IND>();
            public List<int> ind = new List<int>();
            private double[] PrV = new double[MAX_PLOIDY_USED + 1];
            private double[] PrV2 = new double[MAX_PLOIDY_USED + 1];
            private double[] PrV2trun = new double[MAX_PLOIDY_USED + 1];
            private int[] seq;
            public Dictionary<int, PHENOTYPE>[,] phenotypes; 
            public int generation = 0;

            public POP(int _v, int _k, int _n, int _l)
            {
                //APP1
                v = _v;
                k = _k;
                n = _n;
                L = _l;
            }

            public POP(string[] s, ref int i, Random rnd)
            {
                //simulation
                string[] sl = s[i].Split(new char[] { '\t' }, StringSplitOptions.RemoveEmptyEntries);
                v = int.Parse(sl[1]);
                n = int.Parse(sl[3]);
                if (n <= 1 || n > MAX_INDS)
                {
                    MessageBox.Show("Number of individual out of range (" + MAX_INDS + ").", "Error");
                    return;
                }

                //add locus information
                int cc = s[i + 2].Length;
                while (s[i + 2][cc - 1] == ' ' || s[i + 2][cc - 1] == '\t')
                    cc--;
                s[i + 2] = s[i + 2].Substring(0, cc);

                sl = s[i + 1].Split(new char[] { '\t' }, StringSplitOptions.None);
                L = (int)Math.Ceiling(sl.Length / 2.0);
                loc = new LOC[L];
                for (int l = 0; l < L; ++l)
                    loc[l] = new LOC(l, sl[l * 2], rnd);
            }

            public POP(ref string PHENO_INPUT)
            {
                string[] b = PHENO_INPUT.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
                if (b.Length < 2)
                {
                    MessageBox.Show("Empty PHENO_INPUT phenotype. ", "Error");
                    loc = null;
                    return;
                }
                string[] h = b[0].Split(new char[] { '\t' }, StringSplitOptions.RemoveEmptyEntries);

                L = h.Length - 2;
                loc = new LOC[L];
                for (int i = 2; i < h.Length; ++i)
                    loc[i - 2] = new LOC(i - 2, h[i], CONSIDER_BETA ? 0.05 : 0, DR_MODE == 5 ? 0.5 : 0, CONSIDER_SELFING ? 0.1 : 0);

                for (int i = 1; i < b.Length; ++i)
                    if (!AddInds(b[i], i))
                    {
                        loc = null;
                        return;
                    }

                if (ALLOW_WARNING && removedallels.Count > 0)
                {
                    string o = "";
                    for (int i = 0; i < removedallels.Count && i < 500; ++i)
                        o += removedallels[i] + "\t";
                    o = o.Substring(0, o.Length - 2);

                    MessageBox.Show(removedallels.Count + " individuals are found have duplicated alleles in the phenotypes. Although I have removed them, by there may be some errors. Please check, here is the first " + Math.Min(500,removedallels.Count) + " individuals that have duplicated alleles: \r\n" + o, "Warning");
                }

                foreach (LOC l in loc)
                {
                    if (l.allele.Count > MAX_ALLELES)
                    {
                        MessageBox.Show("Number of alleles exceed " + MAX_ALLELES + ". At " + l.name + ".", "Error");
                        loc = null;
                        return;
                    }
                }

                if (!GetAlpha(L, null, DR_MODE))
                {
                    loc = null;
                    return;
                }

                n = inds.Count;
                L = loc.Length;

                Unify(loc);

                phenotypes = new Dictionary<int, PHENOTYPE>[MAX_PLOIDY_USED + 1, L];
                foreach (int v in CANDIDATE_PLOIDY)
                {
                    for (int l = 0; l < L; ++l)
                    {
                        phenotypes[v, l] = new Dictionary<int, PHENOTYPE>();
                        foreach (IND ind in inds)
                        {
                            if (!phenotypes[v, l].ContainsKey(ind.phenotypes[l].hash))
                            {
                                ind.phenotypes[l].ExtractGenotype(v, l);
                                phenotypes[v, l][ind.phenotypes[l].hash] = new PHENOTYPE(ind.phenotypes[l]);
                            }
                            else
                            {
                                ind.phenotypes[l].genotypes = phenotypes[v, l][ind.phenotypes[l].hash].genotypes;
                                //ind.phenotypes[l] = phenotypes[p, l][ind.phenotypes[l].hash];
                            }
                        }
                    }

                    foreach (IND ind in inds)
                        for (int l = 0; l < L; ++l)
                           // if (ind.pr[p] > 0)
                                ind.phenotypes[l].genotypes = phenotypes[v, l][ind.phenotypes[l].hash].genotypes;
                }

                //getinitprob
                if (CONSIDER_NULL)
                    for (int l = 0; l < L; ++l)
                        loc[l].allele[NULL_ALLELE] = 0;

                for (int l = 0; l < L; ++l)
                    foreach (int a in loc[l].allele.Keys.ToList())
                        loc[l].allele[a] = 1.0 / loc[l].allele.Count;

                double sumpriori = 0;
                foreach (int v in CANDIDATE_PLOIDY)
                    sumpriori += (double)numbox[v].Value;
                foreach (int v in CANDIDATE_PLOIDY)
                {
                    double prior = PrV[v] = PrV2[v] = (double)numbox[v].Value / sumpriori;
                    foreach (IND ind in inds)
                        if (!ind.isfixed)
                            ind.pr[v] = prior;
                }

                //initialize freq
                loc2 = new LOC[MAX_PLOIDY_USED + 1][];
                foreach (int v in CANDIDATE_PLOIDY)
                {
                    loc2[v] = new LOC[L];
                    for (int l = 0; l < L; ++l)
                        loc2[v][l] = new LOC(loc[l]);
                }
            }

            public void APP1Sub(Random rnd, bool py)
            {
                if (v % 2 == 1)
                {
                    MessageBox.Show("Can not simulate odd ploidy.", "Error");
                    runstate = runstates.notstart;
                    return;
                }
                //p k n l
                //simulation
                loc = new LOC[L];
                for (int l = 0; l < L; ++l)
                    loc[l] = new LOC(l, "x", rnd, k, py);

                GetAlpha(L, SIM_DR_MODE == 5 ? loc : null, SIM_DR_MODE);

                inds = new List<IND>();
                n = int.Parse(ARGS[7]);
                int ns = 1000;
                double s = double.Parse(ARGS[8]);

                if (true || s > 0.00001)
                {
                    for (int i = 0; i < ns; ++i)
                        inds.Add(new IND(loc, rnd, v, false));

                    for (int i = 0; i < 15; ++i)
                        ReproducePopulation(rnd);

                    List<IND> inds2 = new List<IND>();
                    for (int i = 0; i < n; ++i)
                        inds2.Add(inds[i]);

                    inds.Clear();
                    inds = inds2;
                }
                else
                {
                    for (int i = 0; i < n; ++i)
                        inds.Add(new IND(loc, rnd, v, true));
                }
                Unify(loc);
            }

            public void QuickSort(int v, int[] sv, int left, int right)
            {
                if (left >= right) return;
                int i = left, j = right;
                int temp = sv[left];
                while (i != j)
                {
                    while (inds[sv[j]].pr[v] <= inds[temp].pr[v] && j > i) j--;
                    if (j > i) sv[i++] = sv[j];

                    while (inds[sv[i]].pr[v] >= inds[temp].pr[v] && j > i) i++;
                    if (j > i) sv[j--] = sv[i];
                }
                sv[i] = temp;
                QuickSort(v, sv, left, i - 1);
                QuickSort(v, sv, i + 1, right);
            }

            public void SortIndividuals()
            {
                int[] seq = new int[n];
                int[][] s = new int[MAX_PLOIDY_USED + 1][];
                int[] sc = new int[MAX_PLOIDY_USED + 1];
                foreach (int v in CANDIDATE_PLOIDY)
                    s[v] = new int[n];

                for (int i = 0; i < n; ++i)
                {
                    inds[i].SortPloidy();
                    int v = inds[i].seq[0];
                    s[v][sc[v]++] = i;
                }
                foreach (int v in CANDIDATE_PLOIDY)
                    Array.Resize(ref s[v], sc[v]);

                int c = 0;
                foreach (int v in CANDIDATE_PLOIDY)
                {
                    if (n < 5000) QuickSort(v, s[v], 0, sc[v] - 1);
                    /*
                    for (int i = 0; i < sc[v]; ++i)
                        for (int j = 0; j < i; ++j)
                        {
                            if (inds[s[v][i]].pr[v] > inds[s[v][j]].pr[v])
                            {
                                int t = s[v][i];
                                s[v][i] = s[v][j];
                                s[v][j] = t;
                            }
                        }
                    */
                    foreach (int i in s[v])
                        seq[c++] = i;
                }
                this.seq = seq;

                foreach (int v in CANDIDATE_PLOIDY)
                    PrV2trun[v] = 0;
                foreach (IND ind in inds)
                    PrV2trun[ind.seq[0]]++;
                foreach (int v in CANDIDATE_PLOIDY)
                    PrV2trun[v] /= inds.Count;

                foreach (int v in CANDIDATE_PLOIDY)
                    for (int l = 0; l < L; ++l)
                        foreach (PHENOTYPE ph in phenotypes[v, l].Values)
                            ph.count_trun = 0;

                for (int l = 0; l < L; ++l)
                    foreach (IND ind in inds)
                        phenotypes[ind.seq[0], l][ind.phenotypes[l].hash].count_trun++;
            }

            public void ReproducePopulation(Random rnd)
            {
                int fcount = (int)Math.Round(SIM_FEMALE_RATIO * n);
                int mcount = n - fcount;
                List<IND> inds2 = new List<IND>();

                //Parallel.For(0, n, new ParallelOptions() { MaxDegreeOfParallelism = N_THREADS }, i =>
                for (int i = 0; i < n; ++i)
                {
                    int fid, mid;
                    if (SIM_DIOECIOUS)
                    {
                        fid = rnd.Next(fcount);
                        mid = rnd.Next(mcount) + fcount;
                    }
                    else
                    {
                        mid = rnd.Next(n);

                        if (rnd.NextDouble() < SIM_SELFING_RATIO)
                            fid = mid;
                        else
                            fid = NextAvoid(rnd, n, mid);
                    }
                    IND tind = new IND(inds[fid], inds[mid], rnd);
                    lock (inds2)
                    {
                        inds2.Add(tind);
                    }
                }

                inds = inds2;
                generation++;
            }

            public void CountAlleles()
            {
                //in simulation
                for (int l = 0; l < L; ++l)
                {
                    List<int> b = loc[l].allele.Keys.ToList();
                    foreach (int a in b)
                        loc[l].allele[a] = 0;
                    foreach (IND ind in inds)
                        foreach (int a in ind.phenotypes[l].allele)
                            loc[l].allele[a]++;
                }
                Unify(loc);
            }

            public void LociToString(LOC[] lo, StringBuilder o)
            {
                int maxallele = 0;
                for (int l = 0; l < L; ++l)
                    if (maxallele < lo[l].allele.Count)
                        maxallele = lo[l].allele.Count;

                string[,] s = new string[maxallele + (CONSIDER_BETA ? 1 : 0) + (CONSIDER_SELFING ? 1 : 0) + (DR_MODE == 5 ? 1 : 0), L];
                for (int l = 0; l < L; ++l)
                {
                    int j = 0;
                    if (DR_MODE == 5)
                        s[j++, l] = "rs\t" + lo[l].rs.ToString(DECIMAL);
                    if (CONSIDER_SELFING)
                        s[j++, l] = "s\t" + lo[l].s.ToString(DECIMAL);
                    if (CONSIDER_BETA)
                        s[j++, l] = "Beta\t" + lo[l].beta.ToString(DECIMAL);
                    if (CONSIDER_NULL)
                        s[j++, l] = "Null\t" + lo[l].allele[NULL_ALLELE].ToString(DECIMAL);
                    foreach (int k in lo[l].allele.Keys.OrderBy(a => a))
                        if (k != NULL_ALLELE)
                            s[j++, l] = k + "\t" + lo[l].allele[k].ToString(DECIMAL);
                }

                for (int i = 0; i < s.GetLength(0); ++i)
                {
                    for (int l = 0; l < L; ++l)
                        o.Append((s[i, l] == null ? "\t" : s[i, l]) + "\t");
                    o.Append("\r\n");
                }
            }

            public void WriteHeader(StringBuilder w)
            {
                w.Append("ID\tPloidy");
                for (int i = 0; i < loc.Length; ++i)
                    w.Append("\t" + loc[i].name);
                w.Append("\r\n");
            }

            public void WritePhenotypes(Random rnd, StringBuilder w)
            {
                //in simulation
                string ploidystr = v + "_";
                w.Append(ploidystr);
                w.Append("1\t");
                inds[0].WritePhenotype(rnd, w, loc);
                for (int i = 1; i < n * SIM_SAMPLING_RATIO; ++i)
                {
                    w.Append(ploidystr);
                    w.Append((i + 1).ToString());
                    w.Append("\t");
                    inds[i].WritePhenotype(rnd, w, loc);
                }
            }

            public List<string> removedallels = new List<string>();

            public bool AddInds(string a, int id)
            {
                bool removed = false;
                //from observed genotype
                string[] b = a.Split(new char[] { '\t' });

                L = loc.Length;
                IND tind = new IND(L);

                try
                {
                    //add empty loci

                    if (b.Length >= MAX_LOCI + 2)
                    {
                        MessageBox.Show("Number of loci out of range (" + MAX_LOCI + "). \r\nAt individual '" + b[0] + "'.", "Error");
                        return false;
                    }

                    if (b.Length != L + 2)
                    {
                        MessageBox.Show("Number of loci mismatch the header row. \r\nAt individual '" + b[0] + "'.", "Error");
                        return false;
                    }

                    //add individual
                    tind.name = b[0];
                    if (b[1] != "")
                    {
                        int prioriploidy = int.Parse(b[1]);
                        if (CANDIDATE_PLOIDY.Contains(prioriploidy))
                        {
                            tind.pr[int.Parse(b[1])] = 1;
                            tind.isfixed = true;
                        }
                        else
                        {
                            MessageBox.Show("The known ploidy should be inside the candidate levels of ploidy. \r\nChange the known ploidy of individual: '" + tind.name + "' or check the candidate ploidy in 'Parameters' page.", "Error");
                            return false;
                        }
                    }

                }
                catch (Exception e1)
                {
                    MessageBox.Show("Individual format error, at row " + (id + 1) + ".\r\n" + e1.ToString(), "Error");
                    return false;
                }

                for (int l = 0; l < b.Length - 2; ++l)
                {
                    try
                    {
                        List<int> obsalleles = new List<int>();
                        string[] c = b[l + 2].Split(new char[] { ',' });

                        //remove replicate alleles
                        for (int j = 0; j < c.Length; ++j)
                        {
                            if (c[j] == "")
                                continue;
                            for (int k = j + 1; k < c.Length; ++k)
                                if (c[k] == "")
                                    continue;
                                else if (c[j] == c[k])
                                {
                                    c[k] = "";
                                    if (!removed) removedallels.Add(b[0]);
                                    removed = true;
                                    continue;
                                }
                        }
                        int count = 0;

                        for (int j = 0; j < c.Length; ++j)
                            if (c[j] != "")
                                count++;

                        for (int j = 0; j < c.Length; ++j)
                        {
                            if (c[j] == "")
                                continue;
                            int al = 0;

                            try
                            {
                                al = int.Parse(c[j]);
                            }
                            catch
                            {
                                MessageBox.Show("Cannot recognize alleles '" + c[j] + "', it should be an integer. \r\nAt individual '" + tind.name + "'.", "Error");
                                return false;
                            }
                            if (al > MAX_ALLELESID)
                            {
                                MessageBox.Show("The allele idendifier out of range, it should between 0 and " + MAX_ALLELESID + ". \r\nAt individual '" + tind.name + "'.", "Error");
                                return false;
                            }

                            if (CONSIDER_NULL && al == NULL_ALLELE)
                            {
                                MessageBox.Show("Null alleles should not be appeared in the PHENO_INPUT phenotypes. \r\nAt individual '" + tind.name + "'.", "Error");
                                return false;
                            }
                            obsalleles.Add(al);

                            if (!loc[l].allele.ContainsKey(al))
                                loc[l].allele[al] = 0;
                        }

                        tind.phenotypes[l] = new PHENOTYPE(obsalleles);
                        if (tind.phenotypes[l].obsallele.Count > 0)
                            npheno++;
                    }
                    catch (Exception e1)
                    {
                        MessageBox.Show("Individual format error, at row " + (id + 1) + " col " + (l + 3) + ".\r\n" + e1.ToString(), "Error");
                        return false;
                    }
                }
                inds.Add(tind);
                n = inds.Count;
                return true;
            }

            private double UpdatePosterProb()
            {
                foreach (IND ind in inds)
                    Array.Copy(ind.pr, ind.pr2, ind.pr.Length);

                foreach (int v in CANDIDATE_PLOIDY)
                {
                    // update log of phenotypes[v, l]
                    Parallel.For(0, L, new ParallelOptions() { MaxDegreeOfParallelism = N_THREADS }, l =>
                    //for (int l = 0; l < L; ++l)
                    {
                        if (runstate != runstates.end)
                        {
                            foreach (PHENOTYPE ph in phenotypes[v, l].Values)
                            {
                                if (ph.obsallele.Count == 0 && !CONSIDER_BETA && !CONSIDER_NULL)
                                    ph.log = 0;
                                else
                                    ph.log = Math.Log(ph.PFZFalse(loc2[v][l], ALPHA[l, v], v));
                            }
                        }
                    });

                    // calc poster prob of ploidy
                    Parallel.ForEach(inds, new ParallelOptions() { MaxDegreeOfParallelism = N_THREADS }, ind =>
                    //foreach (IND ind in inds)
                    {
                        if (!ind.isfixed && runstate != runstates.end)
                        {
                            double prlog = 0;
                            int l = -1;
                            foreach(PHENOTYPE ph in ind.phenotypes)
                            {
                                l++;
                                if (ph.obsallele.Count == 0 && !CONSIDER_NULL && !CONSIDER_BETA)//untyped
                                    continue;
                                prlog += phenotypes[v, l][ph.hash].log;
                            }
                            ind.pr[v] = prlog + Math.Log(PrV[v]);
                        }
                    });
                }

                /*
                StringBuilder sb = new StringBuilder();
                foreach (IND ind in inds)
                {
                    sb.Append("\r\n" + ind.name);
                    foreach (int v in CANDIDATE_PLOIDY)
                    {
                        sb.Append("\tploidy=" + v);
                        for (int l = 0; l < L; ++l)
                        {
                            PHENOTYPE ph = ind.phenotypes[l];
                            double li = phenotypes[v, l][ph.hash].log;
                            sb.Append("\t" + li.ToString(DECIMAL));
                        }
                    }
                }
                */

                foreach (int v in CANDIDATE_PLOIDY)
                    PrV2[v] = 0;

                //sum to one, assuming all ploidy is equal
                Parallel.ForEach(inds, new ParallelOptions() { MaxDegreeOfParallelism = N_THREADS }, ind =>
                //foreach (IND ind in inds)
                {
                    if (!ind.isfixed && runstate != runstates.end)
                    {
                        double sum = 0;
                        double max = -1e300;
                        foreach (int v in CANDIDATE_PLOIDY)
                            if (max < ind.pr[v])
                                max = ind.pr[v];
                        foreach (int v in CANDIDATE_PLOIDY)
                        {
                            ind.pr[v] = Math.Exp(ind.pr[v] - max);
                            sum += ind.pr[v];
                        }
                        foreach (int v in CANDIDATE_PLOIDY)
                            ind.pr[v] /= sum;
                    }
                    foreach (int v in CANDIDATE_PLOIDY)
                        PrV2[v] += ind.pr[v];
                });

                Unify(PrV2);

                foreach (int v in CANDIDATE_PLOIDY)
                    PrV2[v] += 0.001;

                Unify(PrV2);

                double maxprobdiff = 0;

                Parallel.ForEach(inds, new ParallelOptions() { MaxDegreeOfParallelism = N_THREADS }, ind =>
                //foreach (IND ind in inds)
                { 
                    if (runstate != runstates.end)
                    foreach (int v in CANDIDATE_PLOIDY)
                    {
                        if (Math.Abs(ind.pr[v] - ind.pr2[v]) > maxprobdiff)
                        {
                            lock (this)
                            {
                                maxprobdiff = Math.Abs(ind.pr[v] - ind.pr2[v]);
                            }
                        }
                    }
                });

                //update phenotypes[v, l]
                foreach (int v in CANDIDATE_PLOIDY)
                {
                    Parallel.For(0, L, new ParallelOptions() { MaxDegreeOfParallelism = N_THREADS }, l =>
                    //for (int l = 0; l < L; ++l)
                    {
                        if (runstate != runstates.end)
                        {
                            foreach (PHENOTYPE ph in phenotypes[v, l].Values)
                                ph.count = 0;
                            foreach (IND ind in inds)
                                if (ind.pr[v] > 0)
                                    phenotypes[v, l][ind.phenotypes[l].hash].count += ind.pr[v];
                        }
                    });
                }

                CURRENT_ASSIGNMENT_DIFF = maxprobdiff;
                return maxprobdiff;
            }

            private void GetAlphaPES(int l, double rs)
            {
                for (int v = 4; v <= MAX_PLOIDY; v += 2)
                {
                    int D = v / 4;
                    double[] apie = new double[D + 1];
                    for (int i = 0; i <= D; ++i)
                        apie[i] = BINOMIAL[v / 2, i] * BINOMIAL[v / 2 - i, v / 2 - 2 * i] * Math.Pow(2, v / 2 - 2 * i) / BINOMIAL[v, v / 2];

                    for (int dd = 0; dd <= D; ++dd)
                    {
                        ALPHA[l, v][dd] = 0;
                        for (int j = dd; j <= D; ++j)
                            for (int i = j; i <= D; ++i)
                                ALPHA[l, v][dd] += apie[i] * BINOMIAL[i, j] * Math.Pow(2, -i) * BINOMIAL[j, dd] * Math.Pow(rs, dd) * Math.Pow(1 - rs, j - dd);
                    }

                    LAMBDA[l, v] = 0;
                    for (int i = 0; i < ALPHA[l, v].Length; ++i)
                        LAMBDA[l, v] += ALPHA[l, v][i] * i;
                }
            }

            private double EMSub(int v, LOC lo)
            {
                Dictionary<int, double> fre1 = lo.allele, fre2 = Clone(fre1);

                int l = lo.id;
                double s = lo.s;
                double f = s2f(s, v, l);
                double beta1 = CONSIDER_BETA ? 0.05 : 0;// lo.beta;
                double beta2 = 0;
                var keys = fre1.Keys.ToArray();
                //em algorithm for population p, locus l
                double maxdiff = 0, lnLPheno = 0;
                foreach (int k in keys)
                    fre1[k] = (fre1[k] + 0.05) / (1.0 + keys.Length * 0.05);

                for (int count = 0; count < MAX_ITER_FREQ; ++count)
                {
                    if (runstate == runstates.end) return 0;
                    //check break, move to 2b
                    foreach (int k in keys)
                    {
                        fre2[k] = fre1[k];
                        fre1[k] = 1e-20;
                    }
                    beta2 = beta1;
                    beta1 = 0;

                    //calculate the allele frequency, save to loc2
                    double scountneg = 0;
                    foreach (PHENOTYPE ph in phenotypes[v, l].Values)
                    {
                        if (ph.count == 0) continue;
                        scountneg += ph.count;//total number of amplifications
                        if (ph.obsallele.Count == 0 && !CONSIDER_BETA && !CONSIDER_NULL) continue;
                        double spr = ph.spr = ph.PFZFalse(fre2, beta2, ALPHA[l, v], f, v);
                        if (ph.obsallele.Count == 0 && CONSIDER_BETA && beta2 > 0)
                        {
                            double ci = ph.count * beta2 / spr;//number of negative amplifications
                            beta1 = ci;
                        }
                        if (spr < 1e-10) continue; //prevent underflow or pr > spr

                        double spr2 = 0, invspr = 1.0 / spr;
                        double pt = (1 - beta2) * ONEMINUS_FALSE_RATE_POWER[fre2.Count - ph.obsallele.Count - (CONSIDER_NULL ? 1 : 0)];
                        foreach (GENOTYPE gh in ph.genotypes[v])
                        {
                            double pr = FALSE_RATE_POWER[gh.nfalse] * pt * (CONSIDER_SELFING ? gh.GFZ(fre2, f, v) : gh.GFZ(fre2, ALPHA[l, v], v));
                            spr2 += pr;
                            double ci = ph.count * pr * invspr; //number of this genotype
                            foreach (int a in gh.alleles.Keys)
                                fre1[a] += ci * gh.alleles[a];
                        }
                        if (ph.obsallele.Count > 0 && Math.Abs(spr - spr2) > 1e-5)
                            spr2 += 0;
                    }
                    beta1 /= scountneg; //number of negtive amplification divided by total number of amplifications
                    Unify(fre1);

                    maxdiff = Math.Abs(beta1 - beta2);
                    foreach (int k in loc[l].allele.Keys)
                    {
                        double diff = Math.Abs(fre2[k] - fre1[k]);
                        if (diff > maxdiff)
                            maxdiff = diff;
                    }
                    if (maxdiff < MAX_DIFF_FREQ || count == MAX_ITER_FREQ - 1)
                    {
                        foreach (PHENOTYPE ph in phenotypes[v, l].Values)
                        {
                            if (ph.obsallele.Count == 0 && !CONSIDER_BETA && !CONSIDER_NULL) continue;
                            lnLPheno += ph.count * Math.Log(ph.spr);
                        }
                        break;
                    }
                }
                lo.beta = beta1;

                return lnLPheno;
            }

            private double EMSubS(int v, POINT xx)
            {
                xx.Image2Real();
                xx.li = 0;
                Parallel.For(0, L, new ParallelOptions() { MaxDegreeOfParallelism = N_THREADS }, l =>
                {
                    loc2[v][l].s = xx.real;
                    double li = EMSub(v, loc2[v][l]);
                    lock (xx)  { xx.li += li; }
                });
                return xx.li;
            }
            private double EMSubRs(int l, POINT xx)
            {
                xx.Image2Real();
                GetAlphaPES(l, xx.real);
                xx.li = 0;
                foreach (int v in CANDIDATE_PLOIDY)
                {
                    loc2[v][l].rs = xx.real;
                    xx.li += EMSub(v, loc2[v][l]);
                }
                return xx.li;
            }

            private void UpdateFreqSelfing()
            {
                foreach (int v in CANDIDATE_PLOIDY)
                {
                    int dem = 1;
                    POINT[] xx = new POINT[dem + 1];
                    //Downhill simplex

                    /*
                    int SEP = 20;
                    POINT init = new POINT();

                    double maxinit = 0, maxinitli = -1e300;
                    for (int i = 0; i < SEP; ++i)
                    {
                        init.real = (i + 0.5) / SEP;
                        init.Real2Image();
                        init.li = 0;
                        Parallel.For(0, L, new ParallelOptions() { MaxDegreeOfParallelism = N_THREADS }, l =>
                        {
                            loc2[v][l].s = init.real;
                            double li = EMSub(v, loc2[v][l]);
                            lock (xx) { init.li += li; }
                        });
                        if (init.li > maxinitli)
                        {
                            maxinitli = init.li;
                            maxinit = init.real;
                        }
                    }
                    */
                    for (int i = 0; i <= dem; ++i)
                    {
                        xx[i] = new POINT();
                        xx[i].real = loc2[v][0].s;// maxinit;
                        if (xx[i].real <= 1e-20) xx[i].real = 1e-20;
                        if (xx[i].real >= 0.99999999999999) xx[i].real = 0.99999999999999;
                        xx[i].Real2Image();
                        if (i > 0) xx[i].image = (xx[i].image - 0.1) * 0.9;
                        EMSubS(v, xx[i]);
                    }

                    //Order

                    //downhill simplex method
                    for(int count = 0; count < MAX_ITER_SIMPLEX; ++count)
                    {
                        if (runstate == runstates.end) return;

                        POINT.Order(xx);
                        if (POINT.Distance(xx[0], xx[1]) < MAX_DIFF_SIMPLEX || Math.Abs(xx[0].real - xx[1].real) < MAX_DIFF_SIMPLEX * 0.001) break;
                        //Reflect
                        POINT x0 = xx[0];
                        for (int i = 1; i < dem; ++i)
                            x0 += xx[i];
                        x0 /= dem;
                        POINT xr = x0 + (x0 - xx[dem]);
                        EMSubS(v, xr);

                        //Expansion
                        //best
                        if (xr > xx[0])
                        {
                            //POINT xe = x0 + (x0 - xx[dem]) * 2;
                            POINT xe = x0 + (xr - x0) * 2;
                            EMSubS(v, xe);
                            xx[1] = xx[0];
                            xx[0] = xe > xr ? xe : xr;
                            continue;
                        }
                        //better than second worst
                        if (xr > xx[dem - 1])
                        {
                            xx[dem] = xr;
                            POINT.Order(xx);
                            continue;
                        }
                        //worse than second worst
                        //Contraction
                        //POINT xc = xx[dem] + (x0 - xx[dem]) * 0.5;
                        POINT xc = x0 + (xx[dem] - x0) * 0.5;
                        EMSubS(v, xc);
                        if (xc > xx[dem])
                        {
                            xx[dem] = xc;
                            POINT.Order(xx);
                            continue;
                        }

                        //Reduction
                        for (int i = 1; i <= dem; ++i)
                        {
                            //xx[i] = (xx[0] + xx[i]) / 2;
                            xx[i] = xx[0] + (xx[i] - xx[0]) * 0.5;
                            EMSubS(v, xx[i]);
                        }
                    }

                    for (int l = 0; l < L; ++l)
                        loc2[v][l].s = xx[0].real;
                }
                return;
            }

            private void UpdatePES()
            {
                Parallel.For(0, L, new ParallelOptions() { MaxDegreeOfParallelism = N_THREADS }, l =>
                {
                    int dem = 1;
                    POINT[] xx = new POINT[dem + 1];
                    /*
                    int SEP = 20;
                    POINT init = new POINT();
                    double maxinit = 0, maxinitli = -1e300;
                    for (int i = 0; i < SEP; ++i)
                    {
                        init.real = (i + 0.5) / SEP;
                        init.Real2Image();
                        init.li = 0;
                        GetAlphaPES(l, init.real);
                        foreach (int v in CANDIDATE_PLOIDY)
                        {
                            loc2[v][l].rs = init.real;
                            init.li += EMSub(v, loc2[v][l]);
                        }
                        if (init.li > maxinitli)
                        {
                            maxinitli = init.li;
                            maxinit = init.real;
                        }
                    }
                    */
                    //PES
                    //Downhill simplex
                    for (int i = 0; i <= dem; ++i)
                    {
                        xx[i] = new POINT();
                        xx[i].real = loc2[CANDIDATE_PLOIDY[0]][l].rs;// maxinit;
                        if (xx[i].real <= 1e-20) xx[i].real = 1e-20;
                        if (xx[i].real >= 0.99999999999999) xx[i].real = 0.99999999999999;
                        xx[i].Real2Image();
                        if (i > 0) xx[i].image = (xx[i].image - 0.1) * 0.9;
                        EMSubRs(l, xx[i]);
                    }

                    //Order
                    //downhill simplex method
                    for (int count = 0; count < MAX_ITER_SIMPLEX; ++count)
                    {
                        if (runstate == runstates.end) return;
                        POINT.Order(xx);
                        if (POINT.Distance(xx[0], xx[1]) < MAX_DIFF_SIMPLEX || Math.Abs(xx[0].real - xx[1].real) < MAX_DIFF_SIMPLEX * 0.001) break;

                        //Reflect
                        POINT x0 = xx[0];
                        for (int i = 1; i < dem; ++i)
                            x0 += xx[i];
                        x0 /= dem;
                        POINT xr = x0 + (x0 - xx[dem]);
                        EMSubRs(l, xr);

                        //Expansion
                        //best
                        if (xr > xx[0])
                        {
                            //POINT xe = x0 + (x0 - xx[dem]) * 2;
                            POINT xe = x0 + (xr - x0) * 2;
                            EMSubRs(l, xe);
                            xx[dem] = xe > xr ? xe : xr;
                            continue;
                        }

                        //better than second worst
                        if (xr > xx[dem - 1])
                        {
                            xx[dem] = xr;
                            continue;
                        }

                        //worse than second worst
                        //Contraction
                        //POINT xc = xx[dem] + (x0 - xx[dem]) * 0.5;
                        POINT xc = x0 + (xx[dem] - x0) * 0.5;
                        EMSubRs(l, xc);

                        if (xc > xx[dem])
                        {
                            xx[dem] = xc;
                            continue;
                        }

                        //Reduction
                        for (int i = 1; i <= dem; ++i)
                        {
                            xx[i] = xx[0] + (xx[i] - xx[0]) * 0.5;
                            EMSubRs(l, xx[i]);
                        }
                    }

                    foreach (int v in CANDIDATE_PLOIDY)
                        loc2[v][l].rs = xx[0].real;
                });
                return;
            }

            private void UpdateFreq()
            {
                if (!CONSIDER_SELFING && DR_MODE < 5)
                {
                    //double re = 0;
                    foreach(int v in CANDIDATE_PLOIDY)
                    Parallel.For(0, L, new ParallelOptions() { MaxDegreeOfParallelism = N_THREADS }, l =>
                    {
                        if (runstate != runstates.end)
                            EMSub(v, loc2[v][l]);
                    });
                    return;
                }

                if (DR_MODE != 5 && CONSIDER_SELFING)
                {
                    UpdateFreqSelfing();
                    return;
                }

                if (DR_MODE == 5 && !CONSIDER_SELFING)
                {
                    UpdatePES();
                    return;
                }
            }

            public void Outcome(bool ispreview, int sorttype)
            {
                if (n == 0 || L == 0 || APP1)
                    return;
                SortIndividuals();
                GetLociString(ref FEEDBACK_LOCUS);
                OIMAGE = n < 5000 ? ToImage(ispreview, sorttype) : null;
                GetModelString(ref FEEDBACK_MODEL);
                GetIndividualString(ref FEEDBACK_INDIVIDUAL);
                FEEKBACKFLAG = true;
            }

            public void IterationStepwise()
            {
                if (DR_MODE == 5 && chainlen == 0)
                    foreach (int v in CANDIDATE_PLOIDY)
                        foreach (LOC l in loc2[v])
                            l.rs = 0.5;
                
                if (CONSIDER_SELFING && chainlen == 0)
                    foreach (int v in CANDIDATE_PLOIDY)
                        foreach (LOC l in loc2[v])
                            l.s = 0.5;

                while (chainlen < NUM_ITER && runstate == runstates.running)
                {
                    if (UPDATE_PRIORI)
                        Array.Copy(PrV, PrV2, PrV.Length);

                    UpdateFreq();

                    UpdatePosterProb();

                    chainlen++;
                }
                Outcome(true, 0);
                GC.Collect();
            }

            public void Iteration()
            {
                //prepare phenotype count
                chainlen = 0;
                foreach (int v in CANDIDATE_PLOIDY)
                    for (int l = 0; l < L; ++l)
                        foreach (IND ind in inds)
                            phenotypes[v, l][ind.phenotypes[l].hash].count += ind.pr[v];


                if (DR_MODE == 5 && chainlen == 0)
                    foreach (int v in CANDIDATE_PLOIDY)
                        foreach (LOC l in loc2[v])
                            l.rs = 0.5;

                if (CONSIDER_SELFING && chainlen == 0)
                    foreach (int v in CANDIDATE_PLOIDY)
                        foreach (LOC l in loc2[v])
                            l.s = 0.5;

                int count = 0;
                while (runstate == runstates.running && count++ < MAX_ITER_ASSIGN)
                {
                    if (UPDATE_PRIORI)
                        Array.Copy(PrV, PrV2, PrV.Length);

                    UpdateFreq();

                    UpdatePosterProb();

                    if (++chainlen % DRAW_FREQ == 0)
                        Outcome(true, 0);

                    if (CURRENT_ASSIGNMENT_DIFF < MAX_DIFF_ASSIGN)
                        break;
                }
                GC.Collect();
            }

            public void ChiTest(int v, StringBuilder sb)
            {
                Dictionary<int, int>[] obs = new Dictionary<int, int>[L];
                int[] Valid = new int[L];
                double[] chi2 = new double[L];
                string[] ptype = new string[L];
                int[] pobs = new int[L];
                double[] pexp = new double[L];
                double[] pval = new double[L];
                for (int l = 0; l < L; ++l)
                    obs[l] = new Dictionary<int, int>();

                double[] df = new double[L];
                int[] k = new int[L];
                for (int l = 0; l < L; ++l)
                {
                    List<int> ks = new List<int>();

                    foreach (IND ind in inds)
                        if (ind.seq[0] == v)
                            foreach (int a in ind.phenotypes[l].obsallele)
                                if (!ks.Contains(a))
                                    ks.Add(a);

                    k[l] = ks.Count;
                    df[l] = PHENO_COUNT[v + MAX_FALSE, ks.Count] + ((CONSIDER_NULL || CONSIDER_BETA) ? 1 : 0) - 1;
                }

                foreach (IND ind in inds)
                {
                    if (v != ind.seq[0]) continue;
                    for (int l = 0; l < L; ++l)
                    {
                        if (ind.phenotypes[l].obsallele.Count == 0 && !CONSIDER_NULL && !CONSIDER_BETA) continue;
                        Valid[l]++;
                        if (obs[l].ContainsKey(ind.phenotypes[l].hash))
                            obs[l][ind.phenotypes[l].hash]++;
                        else
                            obs[l][ind.phenotypes[l].hash] = 1;
                    }
                }

                for (int l = 0; l < L; ++l)
                {
                    double sexp = 0;
                    double maxchi2 = 0;
                    foreach (int h in obs[l].Keys)
                    {
                        double exp = Math.Exp(phenotypes[v, l][h].log) * Valid[l];
                        double chi = Math.Pow(obs[l][h] - exp, 2) / exp;
                        if (chi > maxchi2)
                        {
                            maxchi2 = chi;
                            ptype[l] = GetPhenotype(phenotypes[v, l][h].obsallele);
                            pobs[l] = obs[l][h];
                            pexp[l] = exp;
                        }
                        chi2[l] += chi;
                        sexp += exp;
                    }
                    if (df[l] > obs[l].Count && Valid[l] > sexp) //add chi2 for unobserved phenotypes
                        chi2[l] += Valid[l] - sexp;
                    pval[l] = ChiDist(chi2[l], df[l]);
                }

                sb.Append(PLOIDY_NAME[v]);
                for (int l = 0; l < L; ++l)
                    sb.Append("\t" + loc[l].name);

                sb.Append("\r\nP-val");
                for (int l = 0; l < L; ++l)
                    sb.Append("\t" + pval[l].ToString(DECIMAL));

                sb.Append("\r\nχ2");
                for (int l = 0; l < L; ++l)
                    sb.Append("\t" + chi2[l].ToString(DECIMAL));

                sb.Append("\r\nd.f.");
                for (int l = 0; l < L; ++l)
                    sb.Append("\t" + df[l].ToString("F0"));

                sb.Append("\r\nk");
                for (int l = 0; l < L; ++l)
                    sb.Append("\t" + k[l]);

                sb.Append("\r\nMaxχ2");
                for (int l = 0; l < L; ++l)
                    sb.Append("\t" + ptype[l]);

                sb.Append("\r\nObs");
                for (int l = 0; l < L; ++l)
                    sb.Append("\t" + pobs[l]);

                sb.Append("\r\nExp");
                for (int l = 0; l < L; ++l)
                    sb.Append("\t" + pexp[l].ToString(DECIMAL2));

                sb.Append("\r\n\r\n");
            }

            public void GetIndividualString(ref StringBuilder o)
            {
                o = new StringBuilder("Ind\tPloidy");
                foreach (int v in CANDIDATE_PLOIDY)
                    o.Append("\t" + PLOIDY_NAME[v]);
                o.Append("\r\n");
                foreach (IND ind in inds)
                    ind.WritePosterProb(o);
            }

            public void GetLociString(ref StringBuilder o)
            {
                o = new StringBuilder();
                LOC[][] lo = new LOC[CANDIDATE_PLOIDY.Count][];
                double[] we = new double[CANDIDATE_PLOIDY.Count];
                for (int i = 0; i < CANDIDATE_PLOIDY.Count; ++i)
                {
                    lo[i] = loc2[CANDIDATE_PLOIDY[i]];
                    we[i] = CANDIDATE_PLOIDY[i] * PrV[CANDIDATE_PLOIDY[i]];
                }
                GST = GetGst(lo, we);
                o.Append("Gst = " + GST.ToString(DECIMAL) + "\r\n");

                foreach (int v in CANDIDATE_PLOIDY)
                {
                    o.Append("\r\n" + PLOIDY_NAME[v] + "\t" + PrV2[v].ToString(DECIMAL) + "\r\n");
                    LociToString(loc2[v], o);
                }
            }

            public void GetModelString(ref StringBuilder o)
            {
                o = new StringBuilder();
                StringBuilder mismatch = new StringBuilder();
                lnL = lnL_trun = 0;
                lnLcount = 0;

                foreach (IND ind in inds)
                {
                    int v = ind.seq[0];
                    bool ismismatch = false;

                    for (int l = 0; l < L; ++l)
                    {
                        if (ind.phenotypes[l].obsallele.Count == 0 && !CONSIDER_BETA && !CONSIDER_NULL)
                            continue;
                        else if (ind.phenotypes[l].obsallele.Count > v)
                        {
                            mismatch.Append(ismismatch ? ", " + loc[l].name : ("\r\n" + ind.name + " at " + loc[l].name));
                            ismismatch = true;
                            if (ind.phenotypes[l].obsallele.Count > v + MAX_FALSE)
                                continue;
                        }
                        lnL_trun += phenotypes[v, l][ind.phenotypes[l].hash].log;
                        lnLcount++;
                    }
                }

                lnL = 0;
                foreach (int v in CANDIDATE_PLOIDY)
                    for (int l = 0; l < L; ++l)
                        foreach (var ph in phenotypes[v, l].Values)
                            if (ph.count > 0)
                                lnL += ph.count * ph.log;

                StringBuilder sb = new StringBuilder();
                foreach (int v in CANDIDATE_PLOIDY)
                    ChiTest(v, sb);

                npar = (DR_MODE == 5 ? loc.Length : 0) + (CONSIDER_SELFING ? CANDIDATE_PLOIDY.Count : 0);
                foreach (LOC l in loc)
                    npar += CANDIDATE_PLOIDY.Count * (l.allele.Count - 1 + (CONSIDER_BETA ? 1 : 0));

                int nn = inds.Count;//inds.Count;
                AIC = 2 * npar - 2 * lnL;
                AIC_trun = 2 * npar - 2 * lnL_trun;
                AICc = AIC + 2 * npar * (npar + 1) / (nn - npar - 1);
                AICc_trun = AIC_trun + 2 * npar * (npar + 1) / (nn - npar - 1);
                BIC = -2 * lnL + npar * (Math.Log(nn) + Math.Log(Math.PI * 2));
                BIC_trun = -2 * lnL_trun + npar * (Math.Log(nn) + Math.Log(Math.PI * 2));
                string model = "";
                switch (DR_MODE)
                {
                    case 0: model = "RCS"; break;
                    case 1: model = "PRCS"; break;
                    case 2: model = "CES"; break;
                    case 3: model = "PES_0.25"; break;
                    case 4: model = "PES_0.5"; break;
                    case 5: model = "PES"; break;
                }

                o.AppendLine("Sample size: " + nn);
                o.AppendLine("Number of parameters: " + npar);
                o.AppendLine("(Mismatch phenotypes are ignored, for its lnL = -infinity)");

                o.AppendLine("\r\nBefore truncation:");
                o.AppendLine("Double-reduction model: " + model);
                o.AppendLine("lnL: " + lnL.ToString(DECIMAL));
                o.AppendLine("lnL per individual per locus: " + (lnL / lnLcount).ToString(DECIMAL));
                o.AppendLine("AIC: " + AIC.ToString(DECIMAL) + "\tAICc: " + AICc.ToString(DECIMAL) + "\tBIC: " + BIC.ToString(DECIMAL));

                o.AppendLine("\r\nAfter truncation: ");
                o.AppendLine("lnL: " + lnL_trun.ToString(DECIMAL));
                o.AppendLine("lnL per individual per locus: " + (lnL_trun / lnLcount).ToString(DECIMAL));
                o.AppendLine("AIC: " + AIC_trun.ToString(DECIMAL) + "\tAICc: " + AICc_trun.ToString(DECIMAL) + "\tBIC: " + BIC_trun.ToString(DECIMAL));

                o.AppendLine("\r\nChi-square test for phenotype distribution\r\n");
                o.AppendLine(sb.ToString());
                o.AppendLine("Mismatch phenotypes: ");
                o.AppendLine(mismatch.ToString());
            }

            public Image ToImage(bool ispreview, int sorttype)
            {
                if (APP2) return null;
                int xsep = (ispreview && CURRENT_PAGE != 3) ? ((PREWIDTH / n >= 1) ? (PREWIDTH / n) : 1) : ((PICWIDTH / n >= 1) ? (PICWIDTH / n) : 1);
                int margin = 0;
                int right = 0;
                int height = (ispreview && CURRENT_PAGE != 3) ? PREHEIGHT : PICHEIGHT;
                int theight = height + 2 * margin;
                int twidth = xsep * (n + right + 2 * margin);
                Bitmap bmp = new Bitmap(twidth, theight);
                Graphics g = Graphics.FromImage(bmp);
                Pen p = new Pen(PLOIDY_COLOR[0]);
                p.Width = xsep;
                g.Clear(Color.White);
                Point p1 = new Point(margin, margin);
                Point p2 = new Point(margin, margin + height);
                p1.X = xsep / 2;
                p2.X = xsep / 2;

                if (sorttype == 1)
                {
                    foreach (int i in seq)
                    {
                        p2.Y = 0;
                        for (int k = 0; k < CANDIDATE_PLOIDY.Count; ++k)
                        {
                            p.Color = PLOIDY_COLOR[inds[i].seq[k]];
                            p1.Y = p2.Y;
                            p2.Y = p2.Y + (int)(inds[i].pr[inds[i].seq[k]] * height + margin);
                            if (k == CANDIDATE_PLOIDY.Count - 1)
                                p2.Y = height + margin;
                            g.DrawLine(p, p1, p2);
                        }
                        p1.X += xsep;
                        p2.X += xsep;
                    }
                }
                else if (sorttype == 2)
                {
                    foreach (int i in seq)
                    {
                        p2.Y = 0;
                        foreach (int v in CANDIDATE_PLOIDY)
                        {
                            p.Color = PLOIDY_COLOR[v];
                            p1.Y = p2.Y;
                            p2.Y = p2.Y + (int)(inds[i].pr[v] * height + margin);
                            if (v == MAX_PLOIDY_USED)
                                p2.Y = height + margin;
                            g.DrawLine(p, p1, p2);
                        }
                        p1.X += xsep;
                        p2.X += xsep;
                    }
                }
                else if (sorttype == 0)
                {
                    foreach (IND ind in inds)
                    {
                        p2.Y = 0;
                        foreach (int v in CANDIDATE_PLOIDY)
                        {
                            p.Color = PLOIDY_COLOR[v];
                            p1.Y = p2.Y;
                            if (!double.IsNaN(ind.pr[v]) && !double.IsInfinity(ind.pr[v]))
                                p2.Y = p2.Y + (int)(ind.pr[v] * height + margin);
                            if (v == MAX_PLOIDY_USED)
                                p2.Y = height + margin;
                            g.DrawLine(p, p1, p2);
                        }
                        p1.X += xsep;
                        p2.X += xsep;
                    }
                }
                MemoryStream m = new MemoryStream();
                bmp.Save(m, System.Drawing.Imaging.ImageFormat.Png);
                g.Dispose();
                bmp.Dispose();
                return Image.FromStream(m);
            }
        }
        #endregion

        #region UI
        private void GenerateFounderPopulation(object sender, EventArgs e)
        {
            runstate = runstates.notstart;
            if (thread != null && thread.ThreadState == System.Threading.ThreadState.Running)
                thread.Abort();
            string[] s = SimParBox.Text.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            POP tpop = null;

            Random rnd;
            if (Seedbox.Text != "")
                rnd = new Random(int.Parse(Seedbox.Text));
            else
                rnd = new Random();
            UpdateParameters();

            DR_MODE = SIM_DR_MODE;
            pops = new List<POP>();
            for (int i = 0; i <= s.Length; ++i)
            {
                if (i == s.Length)
                {
                    pops.Add(tpop);
                    break;
                }
                int c = s[i].Length;
                while (c > 0 && (s[i][c - 1] == ' ' || s[i][c - 1] == '\t'))
                    c--;
                s[i] = s[i].Substring(0, c);
                if (s[i].Length >= 6 && s[i].Substring(0, 6).ToLower() == "ploidy")
                {
                    try
                    {
                        if (tpop != null)
                            pops.Add(tpop);
                        tpop = new POP(s, ref i, rnd);
                        i++;
                    }
                    catch (Exception e1)
                    {
                        MessageBox.Show("Simulation parameter format error, at row " + (i + 1) + ".\r\n" + e1.ToString(), "Error");
                        return;
                    }
                }
                else
                {
                    string[] sl = s[i].Split(new char[] { '\t' }, StringSplitOptions.None);
                    for (int j = 0; j < sl.Length - 1; j += 2)
                    {
                        try
                        {
                            if (sl[j].ToLower() == "null")
                                tpop.loc[j / 2].allele.Add(NULL_ALLELE, double.Parse(sl[j + 1]));
                            else if (sl[j].ToLower() == "beta")
                                tpop.loc[j / 2].beta = double.Parse(sl[j + 1]);
                            else if (sl[j] != "")
                            {
                                if (int.Parse(sl[j]) <= 0)
                                {
                                    MessageBox.Show("Allele identifier should be a positive integer.", "Error");
                                    return;
                                }
                                tpop.loc[j / 2].allele.Add(int.Parse(sl[j]), double.Parse(sl[j + 1]));
                            }
                        }
                        catch (Exception e1)
                        {
                            MessageBox.Show("Simulation parameter format error, at row " + (i + 1) + " col " + (j + 1) + ".\r\n" + e1.ToString(), "Error");
                            return;
                        }
                    }
                }
            }
            foreach (LOC l in tpop.loc)
            {
                if (l.allele.Count > MAX_ALLELES)
                {
                    MessageBox.Show("Number of alleles exceed " + MAX_ALLELES + ". At " + l.name + ".", "Error");
                    return;
                }
            }

            StringBuilder w = new StringBuilder();
            pops[0].WriteHeader(w);

            if (!GetAlpha(pops[0].L, SIM_DR_MODE == 5 ? pops[0].loc : null, SIM_DR_MODE))
                return;

            foreach (POP pp in pops)
            {
                Unify(pp.loc);
                pp.inds.Clear();
                for (int i = 0; i < pp.n; ++i)
                    pp.inds.Add(new IND(pp.loc, rnd, pp.v, true));
                pp.WritePhenotypes(rnd, w);
            }

            PhenotypeBox.Text = w.ToString();

            LOC[][] lo = new LOC[pops.Count][];
            double[] we = new double[pops.Count];
            for (int i = 0; i < pops.Count; ++i)
            {
                lo[i] = pops[i].loc;
                we[i] = pops[i].v * pops[i].n;
            }
            GST = GetGst(lo, we);
            GenLabel.Text = "Generation: " + pops[0].generation;
            GstLabel.Text = "Gst: " + GST.ToString(DECIMAL);
            return;
        }

        private void Run(object sender, EventArgs e)
        {
            if (runstate == runstates.running)
                return;

            UpdateParameters();
            SaveFile();

            PICORDER = 0;
            PicBox.Image = null;
            PosterProbBox.Text = ModelInfoBox.Text = AFOutBox.Text = "";
            CURRENT_ASSIGNMENT_DIFF = 1;
            CANDIDATE_PLOIDY = new List<int>();
            for (int i = 1; i <= MAX_PLOIDY; ++i)
                if (chbox[i].Checked)
                    CANDIDATE_PLOIDY.Add(i);

            if (CANDIDATE_PLOIDY.Count == 0)
            {
                MessageBox.Show("At least one candidate ploidy should be specified.", "Error");
                return;
            }

            MAX_PLOIDY_USED = CANDIDATE_PLOIDY[CANDIDATE_PLOIDY.Count - 1];

            runstate = runstates.running;

            if (thread != null) thread.Abort();
            thread = new Thread(new ThreadStart(Inference));
            toolStripProgressBar1.Maximum = (int)(-Math.Log10(MAX_DIFF_ASSIGN) * 1000) + FINAL_TICK;
            toolStripProgressBar1.Value = 0;
            PHENO_INPUT = PhenotypeBox.Text;

            thread.Start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (!TESTING)
            {
               // DebugOutput1.Visible = false;
                //DebugOutput2.Visible = false;
                App3Button.Visible = false;
                toolStripButton1.Visible = false;
                toolStripButton2.Visible = false;
            }
            else
            {
                //DebugOutput1.Visible = true;
                //DebugOutput2.Visible = true;
                App3Button.Visible = true;
                toolStripButton1.Visible = true;
                toolStripButton2.Visible = true;
            }

            LOADING = true;
            prepareCryptTable();
            BINOMIAL = new double[MAX_ALLELES + 2, MAX_ALLELES + 2];
            for (int i = 0; i <= MAX_ALLELES + 1; ++i)
                for (int j = 0; j <= i; ++j)
                    BINOMIAL[i, j] = Binomial(i, j);

            for (int v = 1; v <= MAX_PLOIDY + 4; ++v)
            {
                for (int k = 1; k <= MAX_ALLELES + 1; ++k)
                {
                    int maxk = Math.Min(k, v);
                    for (int i = 1; i <= maxk; ++i)
                        PHENO_COUNT[v, k] += BINOMIAL[k, i];
                    PHENO_COUNT[v, k] = Math.Round(PHENO_COUNT[v, k]);
                }
            }

            for (int v = 1; v <= MAX_PLOIDY; ++v)
            {
                chbox[v] = new CheckBox();
                chbox[v].Tag = v;
                chbox[v].Parent = groupBox8;
                chbox[v].SetBounds(16 + ((v + 1) % 2) * 16, -4 + 36 * v, 78, 16);
                chbox[v].Text = PLOIDY_NAME[v] + "ploid";
                chbox[v].TabIndex = v;
                chbox[v].CheckedChanged += ChBox_SelectedIndexChanged;

                numbox[v] = new NumericUpDown();
                numbox[v].Parent = groupBox8;
                numbox[v].Tag = v;
                numbox[v].Increment = 0.1m;
                numbox[v].Minimum = 0.0001m;
                numbox[v].Maximum = 1m;
                numbox[v].DecimalPlaces = 4;
                numbox[v].SetBounds(110, -4 + 36 * v, 70, 16);
                numbox[v].TabIndex = v;
                numbox[v].ValueChanged += PreSaveFile;
            }

            for (int i = 2; i <= 10; i += 2)
            {
                chbox[i].Checked = true;
                numbox[i].Value = 1;
            }

            button1.BackColor = PLOIDY_COLOR[1];
            button13.BackColor = PLOIDY_COLOR[2];
            button2.BackColor = PLOIDY_COLOR[3];
            button14.BackColor = PLOIDY_COLOR[4];
            button3.BackColor = PLOIDY_COLOR[5];
            button15.BackColor = PLOIDY_COLOR[6];
            button4.BackColor = PLOIDY_COLOR[7];
            button16.BackColor = PLOIDY_COLOR[8];
            button5.BackColor = PLOIDY_COLOR[9];
            button17.BackColor = PLOIDY_COLOR[10];
            button6.BackColor = PLOIDY_COLOR[11];
            button18.BackColor = PLOIDY_COLOR[12];


            LoadFile();

            if (DrBox.SelectedIndex == -1)
                DrBox.SelectedIndex = 0;
            if (SimDRBox.SelectedIndex == -1)
                SimDRBox.SelectedIndex = 0;

            PLOIDY_COLOR = new Color[] {Color.White, 
                    button1.BackColor, button13.BackColor, 
                    button2.BackColor, button14.BackColor, 
                    button3.BackColor, button15.BackColor, 
                    button4.BackColor, button16.BackColor, 
                    button5.BackColor, button17.BackColor, 
                    button6.BackColor, button18.BackColor};

            LOADING = false;
            ChBox_SelectedIndexChanged(null, null);
            DioeciousBox_CheckedChanged(null, null);
            //UpdateParameters();

            if (ARGS != null && ARGS.Length > 0 && ARGS[0] == "APP1")
            {
                this.WindowState = FormWindowState.Minimized;
                APP1Func();
            }

            if (ARGS != null && ARGS.Length > 0 && ARGS[0] == "APP2")
            {
                this.WindowState = FormWindowState.Minimized;
                APP2Func();
            }

            if (ARGS != null && ARGS.Length > 0 && ARGS[0] == "APP1F")
            {
                if (File.Exists(CDIR + "app1.txt"))
                    File.Delete(CDIR + "app1.txt");

                DirectoryInfo d = new DirectoryInfo(CDIR + "app1\\");
                StringBuilder sb = new StringBuilder();
                foreach (FileInfo f in d.GetFiles("*.txt").OrderBy(o => o.Name))
                    sb.AppendLine(File.ReadAllText(f.FullName));
                File.WriteAllText(CDIR + "app1.txt", sb.ToString());
                Environment.Exit(0);
            }

            if (ARGS != null && ARGS.Length > 0 && ARGS[0] == "APP2F")
            {
                if (File.Exists(CDIR + "app2.txt"))
                    File.Delete(CDIR + "app2.txt");

                DirectoryInfo d = new DirectoryInfo(CDIR + "app2\\");
                StringBuilder sb = new StringBuilder();
                foreach (FileInfo f in d.GetFiles("*.txt").OrderBy(o => o.Name))
                    sb.AppendLine(File.ReadAllText(f.FullName));
                File.WriteAllText(CDIR + "app2.txt", sb.ToString());
                Environment.Exit(0);
            }

        }

        private void About(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }
        
        private void LoadFile()
        {
            string[] a = null;

            try
            {
                for (int i = 0; i < 10; ++i)
                    a = File.ReadAllText(CDIR + "config.ini", Encoding.Unicode).Split(new string[] { IDENTIFIER }, StringSplitOptions.None);
            }
            catch
            {

            }

            try
            {
                int c = 0;
                SimParBox.Text = a[c++];
                PhenotypeBox.Text = a[c++];
                PosterProbBox.Text = a[c++];
                AFOutBox.Text = a[c++];
                button1.BackColor = StringToColor(a[c++]);
                button2.BackColor = StringToColor(a[c++]);
                button3.BackColor = StringToColor(a[c++]);
                button4.BackColor = StringToColor(a[c++]);
                button5.BackColor = StringToColor(a[c++]);
                button6.BackColor = StringToColor(a[c++]);
                button13.BackColor = StringToColor(a[c++]);
                button14.BackColor = StringToColor(a[c++]);
                button15.BackColor = StringToColor(a[c++]);
                button16.BackColor = StringToColor(a[c++]);
                button17.BackColor = StringToColor(a[c++]);
                button18.BackColor = StringToColor(a[c++]);
                FeedBackFreqBox.Text = a[c++];
                
                for (int i = 1; i <= MAX_PLOIDY; ++i)
                {
                    chbox[i].Checked = bool.Parse(a[c++]);
                    numbox[i].Value = decimal.Parse(a[c++]);
                }

                DecimalBox.Value = decimal.Parse(a[c++]);
                PicWidthBox.Value = decimal.Parse(a[c++]);
                PicHeightBox.Value = decimal.Parse(a[c++]);
                PreWidthBox.Value = decimal.Parse(a[c++]);
                PreHeightBox.Value = decimal.Parse(a[c++]);
                Seedbox.Text = a[c++];

                SimDioeciousBox.Checked = bool.Parse(a[c++]);
                //checkBox3.Checked = bool.Parse(a[c++]);
                SimFemaleRatioBox.Value = decimal.Parse(a[c++]);
                SimSelfingRateBox.Value = decimal.Parse(a[c++]);
                SimSampleRatioBOx.Value = decimal.Parse(a[c++]);
                GstBox.Text = a[c++];
                MaxDiffFreqBox.Text = a[c++];
                MaxDiffAssignBox.Text = a[c++];

                NullBox.Checked = bool.Parse(a[c++]);
                BetaBox.Checked = bool.Parse(a[c++]);

                MaxIterationAssignBox.Text = a[c++];
                MaxIterationFreqBox.Text = a[c++];
                DrBox.SelectedIndex = int.Parse(a[c++]);
                switch (a[c++])
                {
                    case "Normal": this.WindowState = FormWindowState.Normal; break;
                    case "Minimized": this.WindowState = FormWindowState.Minimized; break;
                    case "Maximized": this.WindowState = FormWindowState.Maximized; break;
                }
                this.Width = int.Parse(a[c++]);
                this.Height = int.Parse(a[c++]);

                splitContainer2.SplitterDistance = (int)(double.Parse(a[c++]) * (splitContainer2.Height));
                splitContainer3.SplitterDistance = (int)(double.Parse(a[c++]) * (splitContainer3.Width));
                splitContainer4.SplitterDistance = (int)(double.Parse(a[c++]) * (splitContainer4.Height));

                WarningBox.Checked = bool.Parse(a[c++]);
                SimDRBox.SelectedIndex = int.Parse(a[c++]);

                SimFalseAlleleRateaBox.Value = decimal.Parse(a[c++]);
                FalseAlleleRateBox.Value = decimal.Parse(a[c++]);
                SimMaxFalseAllelesBox.Value = decimal.Parse(a[c++]);
                MaxFalseAllelesBox.Value = decimal.Parse(a[c++]);

                ThreadBox.Value = decimal.Parse(a[c++]);
                SimBetaBox.Value = decimal.Parse(a[c++]);

                MaxDiffSimplexBox.Text = a[c++];
                MaxIterationSimplexBox.Text = a[c++];
                SelfingBox.Checked = bool.Parse(a[c++]);
                UpdatePrioriBox.Checked = bool.Parse(a[c++]);

                ModelInfoBox.Text = a[c++];
                PosterProbBox.Text = a[c++];
                AFOutBox.Text = a[c++];
            }
            catch
            {

            }
        }

        private void PreSaveFile(object sender = null, EventArgs e = null)
        {
            PRESAVE = true;
        }

        private void SaveFile(object sender = null, EventArgs e = null)
        {
            PRESAVE = false;
            if (!LOADING)
            {
                try
                {
                    StringBuilder a = new StringBuilder();
                    a.Append(SimParBox.Text);
                    a.Append(IDENTIFIER + PhenotypeBox.Text);
                    a.Append(IDENTIFIER + PosterProbBox.Text);
                    a.Append(IDENTIFIER + AFOutBox.Text);
                    a.Append(IDENTIFIER + ColorToString(button1.BackColor));
                    a.Append(IDENTIFIER + ColorToString(button2.BackColor));
                    a.Append(IDENTIFIER + ColorToString(button3.BackColor));
                    a.Append(IDENTIFIER + ColorToString(button4.BackColor));
                    a.Append(IDENTIFIER + ColorToString(button5.BackColor));
                    a.Append(IDENTIFIER + ColorToString(button6.BackColor));
                    a.Append(IDENTIFIER + ColorToString(button13.BackColor));
                    a.Append(IDENTIFIER + ColorToString(button14.BackColor));
                    a.Append(IDENTIFIER + ColorToString(button15.BackColor));
                    a.Append(IDENTIFIER + ColorToString(button16.BackColor));
                    a.Append(IDENTIFIER + ColorToString(button17.BackColor));
                    a.Append(IDENTIFIER + ColorToString(button18.BackColor));
                    a.Append(IDENTIFIER + FeedBackFreqBox.Text);
                    for (int i = 1; i <= MAX_PLOIDY; ++i)
                    {
                        a.Append(IDENTIFIER + chbox[i].Checked);
                        a.Append(IDENTIFIER + numbox[i].Value);
                    }

                    a.Append(IDENTIFIER + DecimalBox.Value);
                    a.Append(IDENTIFIER + PicWidthBox.Value);
                    a.Append(IDENTIFIER + PicHeightBox.Value);
                    a.Append(IDENTIFIER + PreWidthBox.Value);
                    a.Append(IDENTIFIER + PreHeightBox.Value);
                    a.Append(IDENTIFIER + Seedbox.Text);

                    a.Append(IDENTIFIER + SimDioeciousBox.Checked);
                    a.Append(IDENTIFIER + SimFemaleRatioBox.Value);
                    a.Append(IDENTIFIER + SimSelfingRateBox.Value);
                    a.Append(IDENTIFIER + SimSampleRatioBOx.Value);

                    a.Append(IDENTIFIER + GstBox.Text);
                    a.Append(IDENTIFIER + MaxDiffFreqBox.Text);
                    a.Append(IDENTIFIER + MaxDiffAssignBox.Text);

                    a.Append(IDENTIFIER + NullBox.Checked);
                    a.Append(IDENTIFIER + BetaBox.Checked);

                    a.Append(IDENTIFIER + MaxIterationAssignBox.Text);
                    a.Append(IDENTIFIER + MaxIterationFreqBox.Text);

                    a.Append(IDENTIFIER + DrBox.SelectedIndex);

                    a.Append(IDENTIFIER + this.WindowState.ToString());
                    a.Append(IDENTIFIER + this.Width);
                    a.Append(IDENTIFIER + this.Height);

                    a.Append(IDENTIFIER + (splitContainer2.SplitterDistance / (double)(splitContainer2.Height)));
                    a.Append(IDENTIFIER + (splitContainer3.SplitterDistance / (double)(splitContainer3.Width)));
                    a.Append(IDENTIFIER + (splitContainer4.SplitterDistance / (double)(splitContainer4.Height)));

                    a.Append(IDENTIFIER + WarningBox.Checked);
                    a.Append(IDENTIFIER + SimDRBox.SelectedIndex);

                    a.Append(IDENTIFIER + SimFalseAlleleRateaBox.Value);
                    a.Append(IDENTIFIER + FalseAlleleRateBox.Value);
                    a.Append(IDENTIFIER + SimMaxFalseAllelesBox.Value);
                    a.Append(IDENTIFIER + MaxFalseAllelesBox.Value);

                    a.Append(IDENTIFIER + ThreadBox.Value);
                    a.Append(IDENTIFIER + SimBetaBox.Value);

                    a.Append(IDENTIFIER + MaxDiffSimplexBox.Text);
                    a.Append(IDENTIFIER + MaxIterationSimplexBox.Text);
                    a.Append(IDENTIFIER + SelfingBox.Checked);
                    a.Append(IDENTIFIER + UpdatePrioriBox.Checked);

                    a.Append(IDENTIFIER + ModelInfoBox.Text);
                    a.Append(IDENTIFIER + PosterProbBox.Text);
                    a.Append(IDENTIFIER + AFOutBox.Text);


                    File.WriteAllText(CDIR + "config.ini", a.ToString(), Encoding.Unicode);
                }
                catch { }
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (PRESAVE)
                SaveFile();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            switch (APP2_STAGE)
            {
                case 0:
                    break;
                case 1:
                    if (runstate == runstates.simulatedend)
                    {
                        APP2_STAGE = 2;
                        Run(null, null);
                    }
                    break;
                case 2:
                    if (runstate == runstates.notstart)
                    {
                        //check results
                        APP2_STAGE = 3;
                        all.Outcome(false, 0);

                        int corr = 0;
                        foreach (IND ind in all.inds)
                        {
                            int v = ind.name[0] - '0';
                            if (v == 1) v = 10;
                            if (ind.seq[0] == v)
                                corr++;
                        }
                        APP2_CORRECT[APP2_MODEL] = corr;
                        APP2_BIC[APP2_MODEL] = all.BIC;
                        APP2_MODEL++;

                        if (APP2_MODEL == 8)
                        {
                            int minidx = 0;
                            double bicmin = APP2_BIC[0];
                            for (int i = 1; i < 8; ++i)
                            {
                                if (APP2_BIC[i] < bicmin)
                                {
                                    bicmin = APP2_BIC[i];
                                    minidx = i;
                                }
                            }

                            int ncorrect = APP2_CORRECT[minidx];
                            int ntotal = all.inds.Count;
                            string s = 
                                ARGS[1] +"\t" +
                                ARGS[2] + "\t" +
                                ARGS[3] + "\t" +
                                ARGS[4] + "\t" +
                                ARGS[5] + "\t" +
                                ARGS[6] + "\t" +
                                ARGS[7] + "\t" +
                                ARGS[8] + "\t" +
                                (ncorrect * 1.0 / ntotal).ToString(DECIMAL) + "\t" +
                                minidx + "\r\n";

                            for (; ; )
                            {
                                try
                                {
                                    File.AppendAllText("APP2\\" + ARGS[1] + ".txt", s);
                                    break;
                                }
                                catch { }
                            }

                            APP2_MODEL = 0;
                            if (APPLOOP-- != 0)
                                APP2Func();
                            else
                                Environment.Exit(0);
                            break;
                        }
                        else switch (APP2_MODEL)
                        {
                            case 1:
                                NullBox.Checked = true;
                                BetaBox.Checked = false;
                                SelfingBox.Checked = false;
                                APP2_STAGE = 2;
                                Run(null, null);
                                break;
                            case 2:
                                NullBox.Checked = false;
                                BetaBox.Checked = true;
                                SelfingBox.Checked = false;
                                APP2_STAGE = 2;
                                Run(null, null);
                                break;
                            case 3:
                                NullBox.Checked = false;
                                BetaBox.Checked = false;
                                SelfingBox.Checked = true;
                                APP2_STAGE = 2;
                                Run(null, null);
                                break;
                            case 4:
                                NullBox.Checked = false;
                                BetaBox.Checked = true;
                                SelfingBox.Checked = true;
                                APP2_STAGE = 2;
                                Run(null, null);
                                break;
                            case 5:
                                NullBox.Checked = true;
                                BetaBox.Checked = false;
                                SelfingBox.Checked = true;
                                APP2_STAGE = 2;
                                Run(null, null);
                                break;
                            case 6:
                                NullBox.Checked = true;
                                BetaBox.Checked = true;
                                SelfingBox.Checked = false;
                                APP2_STAGE = 2;
                                Run(null, null);
                                break;
                            case 7:
                                NullBox.Checked = true;
                                BetaBox.Checked = true;
                                SelfingBox.Checked = true;
                                APP2_STAGE = 2;
                                Run(null, null);
                                break;
                            }
                    }
                    break;
            }

            switch (APP3_STAGE)
            {
            case 0:
                break;
            case 1:
                if (runstate == runstates.notstart)
                {
                    APP3_STAGE = 2;
                    Run(null, null);
                }
                break;
            case 2:
                if (runstate == runstates.notstart)
                {
                    //check results
                    APP3_STAGE = 3;
                    all.Outcome(false, 0);
                        
                    int corr = 0, c24 = 0, c25 = 0, c42 = 0, c45 = 0, c52 = 0, c54 = 0;
                    foreach (IND ind in all.inds)
                    {
                        int v = ind.name[0] - '0';
                        if (v == 1)
                            v = 10 + ind.name[1] - '0';
                        if (ind.seq[0] == v)
                            corr++;
                        else if (v == 2 && ind.seq[0] == 4)
                            c24++;
                        else if (v == 2 && ind.seq[0] == 5)
                            c25++;
                        else if (v == 4 && ind.seq[0] == 2)
                            c42++;
                        else if (v == 4 && ind.seq[0] == 5)
                            c45++;
                        else if (v == 5 && ind.seq[0] == 2)
                            c52++;
                        else if (v == 5 && ind.seq[0] == 4)
                            c54++;
                        }

                    string s = DrBox.Text + "\t'" +
                    (NullBox.Checked ? "+p_y" : "") +
                    (BetaBox.Checked ? "+\\beta" : "") +
                    (SelfingBox.Checked ? "+s" : "") + "\t" +
                    all.npar + "\t" +
                    all.lnL + "\t" +
                    all.AIC + "\t" +
                    all.BIC + "\t" +
                    (corr / (double)all.inds.Count).ToString("F8") + "\t" +
                    (c24 / (double)all.inds.Count).ToString("F8") + "\t" +
                    (c25 / (double)all.inds.Count).ToString("F8") + "\t" +
                    (c42 / (double)all.inds.Count).ToString("F8") + "\t" +
                    (c45 / (double)all.inds.Count).ToString("F8") + "\t" +
                    (c52 / (double)all.inds.Count).ToString("F8") + "\t" +
                    (c54 / (double)all.inds.Count).ToString("F8") + "\r\n";

                    File.AppendAllText("APP3\\app3.txt", s);
                    APP3_MODEL++;
reset:
                    if (APP3_MODEL == 8)
                    {
                        if (DrBox.SelectedIndex == 5) Environment.Exit(0);
                        APP3_MODEL = 0;
                        DrBox.SelectedIndex = DrBox.SelectedIndex + 1;

                        NullBox.Checked = false;
                        BetaBox.Checked = false;
                        SelfingBox.Checked = false;
                        APP3_STAGE = 2;
                        Run(null, null);
                        break;
                    }
                    else switch (APP3_MODEL)
                    {
                    case 1:
                        NullBox.Checked = true;
                        BetaBox.Checked = false;
                        SelfingBox.Checked = false;
                        APP3_STAGE = 2;
                        Run(null, null);
                        break;
                    case 2:
                        NullBox.Checked = false;
                        BetaBox.Checked = true;
                        SelfingBox.Checked = false;
                        APP3_STAGE = 2;
                        Run(null, null);
                        break;
                    case 3:
                        if (DrBox.SelectedIndex == 5)
                        { APP3_MODEL++; goto reset; }
                        NullBox.Checked = false;
                        BetaBox.Checked = false;
                        SelfingBox.Checked = true;
                        APP3_STAGE = 2;
                        Run(null, null);
                        break;
                    case 4:
                        if (DrBox.SelectedIndex == 5)
                        { APP3_MODEL++; goto reset; }
                        NullBox.Checked = false;
                        BetaBox.Checked = true;
                        SelfingBox.Checked = true;
                        APP3_STAGE = 2;
                        Run(null, null);
                        break;
                    case 5:
                        if (DrBox.SelectedIndex == 5)
                        { APP3_MODEL++; goto reset; }
                        NullBox.Checked = true;
                        BetaBox.Checked = false;
                        SelfingBox.Checked = true;
                        APP3_STAGE = 2;
                        Run(null, null);
                        break;
                    case 6:
                        NullBox.Checked = true;
                        BetaBox.Checked = true;
                        SelfingBox.Checked = false;
                        APP3_STAGE = 2;
                        Run(null, null);
                        break;
                    case 7:
                        if (DrBox.SelectedIndex == 5)
                        { APP3_MODEL++; goto reset; }
                        NullBox.Checked = true;
                        BetaBox.Checked = true;
                        SelfingBox.Checked = true;
                        APP3_STAGE = 2;
                        Run(null, null);
                        break;
                    }
                }
                break;
            }

            if (FEEKBACKFLAG)
            {
                try
                {
                    PosterProbBox.Text = FEEDBACK_INDIVIDUAL.ToString();
                    AFOutBox.Text = FEEDBACK_LOCUS.ToString();
                    ModelInfoBox.Text = FEEDBACK_MODEL.ToString();
                    PicBox.Image = PreviewBox.Image = OIMAGE;
                    FEEKBACKFLAG = false;
                }
                catch
                {

                }
            }

            if (runstate == runstates.running || runstate == runstates.end || runstate == runstates.pause)
            {
                try
                {
                    ChainLenLabel.Text = "Chain len: " + all.chainlen;
                }
                catch
                {

                }
                if (CURRENT_ASSIGNMENT_DIFF == 0)
                    toolStripProgressBar1.Value = toolStripProgressBar1.Maximum;
                else
                {
                    int t = (int)(-Math.Log10(CURRENT_ASSIGNMENT_DIFF) * 1000);
                    t = t < 0 ? 0 : t;
                    toolStripProgressBar1.Value = t > toolStripProgressBar1.Maximum ? toolStripProgressBar1.Maximum : t;
                }
            }

            switch (runstate)
            {
                default:
                    if(!APP2) groupBox2.Enabled = groupBox1.Enabled = toolStrip2.Enabled = flowLayoutPanel1.Enabled = true;
                    break;
                case runstates.running:
                    if (!APP2) groupBox2.Enabled = groupBox1.Enabled = toolStrip2.Enabled = flowLayoutPanel1.Enabled = false;
                    break;
                case runstates.end:
                    runstate = runstates.notstart;
                    if (!APP2) groupBox2.Enabled = groupBox1.Enabled = toolStrip2.Enabled = flowLayoutPanel1.Enabled = true;
                    if (APP1)
                    {
                        APP1Write();
                        this.Text = "APP1 " + ARGS[1] + " " + APPLOOP;
                        APP1Func();
                    }
                    break;
                case runstates.pause:
                    if (!APP2) groupBox2.Enabled = groupBox1.Enabled = toolStrip2.Enabled = flowLayoutPanel1.Enabled = false;
                    runstate = runstates.pauseend;
                    break;
                case runstates.simulating:
                    if (!APP2) groupBox2.Enabled = groupBox1.Enabled = toolStrip2.Enabled = flowLayoutPanel1.Enabled = false;
                    toolStripProgressBar1.Value = pops[0].generation - NUM_REPRODUCE_START;
                    //toolStripProgressBar2.Value = pops[0].generation - NUM_REPRODUCE_START;
                    GenLabel.Text = "Generation: " + pops[0].generation;
                    GstLabel.Text = "Gst: " + GST.ToString(DECIMAL);
                    break;
                case runstates.simulated:
                    if (!APP2) groupBox2.Enabled = groupBox1.Enabled = toolStrip2.Enabled = flowLayoutPanel1.Enabled = true;
                    toolStripProgressBar1.Value = toolStripProgressBar1.Maximum;
                    //toolStripProgressBar2.Value = toolStripProgressBar2.Maximum;
                    runstate = runstates.simulatedend;

                    StringBuilder w = new StringBuilder();
                    pops[0].WriteHeader(w);
                    foreach (POP pp in pops)
                        pp.WritePhenotypes(grnd, w);
                    PhenotypeBox.Text = w.ToString();

                    GenLabel.Text = "Generation: " + pops[0].generation;
                    GstLabel.Text = "Gst: " + GST.ToString(DECIMAL);
                    break;
            }
        }

        private void Abort(object sender, EventArgs e)
        {
            APP2_STAGE = 0;
            if (thread != null) thread.Abort();
            thread = null;
            runstate = runstates.end;
        }

        private void ChangeSeed(object sender, EventArgs e)
        {
            Seedbox.Text = grnd.Next().ToString();
        }

        private void ChangeColor(object sender, EventArgs e)
        {
            Button t = (Button)sender;
            colorDialog1.Color = t.BackColor;
            if (DialogResult.OK == colorDialog1.ShowDialog())
            {
                t.BackColor = colorDialog1.Color;
                PLOIDY_COLOR = new Color[] {Color.White, 
                    button1.BackColor, button13.BackColor, 
                    button2.BackColor, button14.BackColor, 
                    button3.BackColor, button15.BackColor, 
                    button4.BackColor, button16.BackColor, 
                    button5.BackColor, button17.BackColor, 
                    button6.BackColor, button18.BackColor};
                SaveFile();
            }
        }

        private void SaveImage(object sender, EventArgs e)
        {
            //save image
            if (PicBox.Image == null)
                MessageBox.Show("Image is not loaded.", "Error");
            else if (DialogResult.OK == saveFileDialog1.ShowDialog())
            {
                try
                {
                    string ext = saveFileDialog1.FileName.Substring(saveFileDialog1.FileName.Length - 3);
                    switch (ext)
                    {
                        case "bmp": PicBox.Image.Save(saveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Bmp); break;
                        case "gif": PicBox.Image.Save(saveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Gif); break;
                        case "jpg": PicBox.Image.Save(saveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Jpeg); break;
                        case "png": PicBox.Image.Save(saveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Png); break;
                        case "tif": PicBox.Image.Save(saveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Tiff); break;
                        case "emf": PicBox.Image.Save(saveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Emf); break;
                        case "wmf": PicBox.Image.Save(saveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Wmf); break;
                    }
                }
                catch (Exception ee)
                {
                    MessageBox.Show(ee.ToString(), "Error");
                }
            }
        }

        private void Stepwise(object sender, EventArgs e)
        {
            if (runstate == runstates.notstart || runstate == runstates.pauseend)
            {
                if (runstate == runstates.notstart)
                {
                    PicBox.Image = null;

                    CANDIDATE_PLOIDY = new List<int>();
                    for (int i = 1; i <= MAX_PLOIDY; ++i)
                        if (chbox[i].Checked)
                            CANDIDATE_PLOIDY.Add(i);

                    if (CANDIDATE_PLOIDY.Count == 0)
                        return;

                    CURRENT_ASSIGNMENT_DIFF = 1;

                    MAX_PLOIDY_USED = CANDIDATE_PLOIDY[CANDIDATE_PLOIDY.Count - 1];

                    toolStripProgressBar1.Maximum = (int)(-Math.Log10(MAX_DIFF_ASSIGN) * 1000) + FINAL_TICK;
                    toolStripProgressBar1.Value = 0;
                    PHENO_INPUT = PhenotypeBox.Text;
                }

                switch (((ToolStripButton)sender).Text)
                {
                    case "Iter 1 (&Z)": NUM_ITER += 1; break;
                    case "Iter 5 (&X)": NUM_ITER += 5; break;
                    case "Iter 20 (&C)": NUM_ITER += 20; break;
                    case "Iter 100 (&V)": NUM_ITER += 100; break;
                }

                if (thread != null) thread.Abort();
                thread = new Thread(new ThreadStart(Stepwise));
                thread.Start();
            }
        }

        private void ResetStepwise(object sender, EventArgs e)
        {
            runstate = runstates.notstart;
            NUM_ITER = 0;
        }

        private void Print(object sender, EventArgs e)
        {
            PrintPreviewDialog MyPrintPreviewDialog = new PrintPreviewDialog();
            MyPrintPreviewDialog.ShowDialog();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            runstate = runstates.notstart;
            SaveFile();
            if (thread != null && thread.ThreadState == System.Threading.ThreadState.Running)
                thread.Abort();
            this.Dispose();
        }

        private void UpdateParameters(object sender = null, EventArgs e = null)
        {
            if (!LOADING)
            {
                try
                {
                    /*
                    if (APP1 == false && APP2 == false && APP3 == false)
                    {
                        //all = null;
                        //pops = null;

                        runstate = runstates.notstart;
                        if (thread != null && thread.ThreadState == System.Threading.ThreadState.Running)
                            thread.Abort();
                    }*/

                    switch (FeedBackFreqBox.Text)
                    {
                        case "per 1 iter": DRAW_FREQ = 1; break;
                        case "per 2 iter": DRAW_FREQ = 2; break;
                        case "per 5 iter": DRAW_FREQ = 5; break;
                        case "per 10 iter": DRAW_FREQ = 10; break;
                        case "per 20 iter": DRAW_FREQ = 20; break;
                        case "per 50 iter": DRAW_FREQ = 50; break;
                        case "per 100 iter": DRAW_FREQ = 100; break;
                        default: DRAW_FREQ = int.MaxValue; break;
                    }

                    MAX_DIFF_FREQ = double.Parse(MaxDiffFreqBox.Text);
                    MAX_DIFF_ASSIGN = double.Parse(MaxDiffAssignBox.Text);
                    DECIMAL = "F" + ((int)DecimalBox.Value);
                    DECIMAL2 = "F" + ((int)(DecimalBox.Value / 2));
                    PICWIDTH = (int)PicWidthBox.Value;
                    PICHEIGHT = (int)PicHeightBox.Value;
                    PREWIDTH = (int)PreWidthBox.Value;
                    PREHEIGHT = (int)PreHeightBox.Value;

                    SIM_DIOECIOUS = SimDioeciousBox.Checked;
                    SIM_FEMALE_RATIO = (double)SimFemaleRatioBox.Value;
                    SIM_SELFING_RATIO = (double)SimSelfingRateBox.Value;
                    SIM_SAMPLING_RATIO = (double)SimSampleRatioBOx.Value;

                    GST_TERMINAL = double.Parse(GstBox.Text);

                    CONSIDER_NULL = NullBox.Checked;
                    CONSIDER_BETA = BetaBox.Checked;

                    MAX_ITER_ASSIGN = int.Parse(MaxIterationAssignBox.Text);
                    MAX_ITER_FREQ = int.Parse(MaxIterationFreqBox.Text);

                    DR_MODE = DrBox.SelectedIndex;
                    //DISTANCE_STRING = DistanceBox.Text;

                    ALLOW_WARNING = WarningBox.Checked;

                    SIM_DR_MODE = SimDRBox.SelectedIndex;

                    SIM_FALSE_RATE = (double)SimFalseAlleleRateaBox.Value;
                    FALSE_RATE = (double)FalseAlleleRateBox.Value;
                    SIM_MAX_FALSE = (int)SimMaxFalseAllelesBox.Value;
                    MAX_FALSE = (int)MaxFalseAllelesBox.Value;

                    double E = FALSE_RATE, F = 1 - E;
                    ONEMINUS_FALSE_RATE_POWER[0] = FALSE_RATE_POWER[0] = 1;
                    for (int i = 1; i < FALSE_RATE_POWER.Length; ++i)
                    {
                        FALSE_RATE_POWER[i] = FALSE_RATE_POWER[i - 1] * E;
                        ONEMINUS_FALSE_RATE_POWER[i] = ONEMINUS_FALSE_RATE_POWER[i - 1] * F;
                    }
                    N_THREADS = (int)ThreadBox.Value;
                    SIM_BETA = (double)SimBetaBox.Value;

                    MAX_DIFF_SIMPLEX = double.Parse(MaxDiffSimplexBox.Text);
                    MAX_ITER_SIMPLEX = int.Parse(MaxIterationSimplexBox.Text);

                    CONSIDER_SELFING = SelfingBox.Checked;
                    UPDATE_PRIORI = UpdatePrioriBox.Checked;
                    PreSaveFile();
                }
                catch { }

            }
        }

        public static bool GetAlpha(int L, LOC[] loc, int drmode)
        {
            ALPHA = new double[L, MAX_PLOIDY + 1][];
            LAMBDA = new double[L, MAX_PLOIDY + 1];
            for (int l = 0; l < L; ++l)
            {
                if (loc != null || drmode >= 3)
                {
                    double rs = 0.5;
                    switch (drmode)
                    {
                        case 3: rs = 0.25; break;
                        case 4: rs = 0.5; break;
                        case 5: rs = 0.75; break;
                    }
                    if (loc != null)
                        rs = loc[l].rs;

                    ALPHA[l, 2] = new double[] { 1 };
                    ALPHA[l, 4] = new double[] { 0, 0 };
                    ALPHA[l, 6] = new double[] { 0, 0 };
                    ALPHA[l, 8] = new double[] { 0, 0, 0 };
                    ALPHA[l, 10] = new double[] { 0, 0, 0 };

                    for (int v = 4; v <= MAX_PLOIDY; v += 2)
                    {
                        int D = v / 4;
                        double[] ap = new double[D + 1];
                        for (int i = 0; i <= D; ++i)
                            ap[i] = BINOMIAL[v / 2, i] * BINOMIAL[v / 2 - i, v / 2 - 2 * i] * Math.Pow(2, v / 2 - 2 * i) / BINOMIAL[v, v / 2];

                        for (int dd = 0; dd <= D; ++dd)
                        {
                            ALPHA[l, v][dd] = 0;
                            for (int j = dd; j <= D; ++j)
                                for (int i = j; i <= D; ++i)
                                    ALPHA[l, v][dd] += ap[i] * BINOMIAL[i, j] * Math.Pow(2, -i) * BINOMIAL[j, dd] * Math.Pow(rs, dd) * Math.Pow(1 - rs, j - dd);
                        }
                    }
                }
                else if (drmode == 0)
                {
                    //RCS
                    ALPHA[l, 2] = new double[] { 1 };
                    ALPHA[l, 4] = new double[] { 1, 0 };
                    ALPHA[l, 6] = new double[] { 1, 0 };
                    ALPHA[l, 8] = new double[] { 1, 0, 0 };
                    ALPHA[l, 10] = new double[] { 1, 0, 0 };
                }
                else if (drmode == 1)
                {
                    //PRCS
                    ALPHA[l, 2] = new double[] { 1 };
                    ALPHA[l, 4] = new double[] { 6.0 / 7, 1.0 / 7 };
                    ALPHA[l, 6] = new double[] { 8.0 / 11, 3.0 / 11 };
                    ALPHA[l, 8] = new double[] { 40.0 / 65, 24.0 / 65, 1.0 / 65 };
                    ALPHA[l, 10] = new double[] { 168.0 / 323, 140.0 / 323, 15.0 / 323 };
                }
                else if (drmode == 2)
                {
                    //CES
                    ALPHA[l, 2] = new double[] { 1 };
                    ALPHA[l, 4] = new double[] { 5.0 / 6, 1.0 / 6 };
                    ALPHA[l, 6] = new double[] { 7.0 / 10, 3.0 / 10 };
                    ALPHA[l, 8] = new double[] { 83.0 / 140, 54.0 / 140, 3.0 / 140 };
                    ALPHA[l, 10] = new double[] { 127.0 / 252, 110.0 / 252, 15.0 / 252 };
                }

                for (int v = 1; v <= 10; ++v)
                {
                    LAMBDA[l, v] = 0;
                    if (v % 2 == 1) continue;
                    for (int i = 0; i < ALPHA[l, v].Length; ++i)
                        LAMBDA[l, v] += ALPHA[l, v][i] * i;
                }
            }

            return true;
        }

        private void tabControl1_Selected(object sender, TabControlEventArgs e)
        {
            CURRENT_PAGE = tabControl1.SelectedIndex;
        }

        private void OriginalOrder(object sender, EventArgs e)
        {
            PICORDER = 0;
            if (all != null && (runstate == runstates.pauseend || runstate == runstates.notstart))
                all.Outcome(false, 0);
        }

        private void Sort(object sender, EventArgs e)
        {
            PICORDER = 1;
            if (all != null && (runstate == runstates.pauseend || runstate == runstates.notstart))
                all.Outcome(false, 1);
        }

        private void SortbyQ(object sender, EventArgs e)
        {
            PICORDER = 2;
            if (all != null && (runstate == runstates.pauseend || runstate == runstates.notstart))
                all.Outcome(false, 2);
        }

        private void ReproduceGenerations(object sender, EventArgs e)
        {
            if (runstate == runstates.simulating)
                return;

            if (thread != null && thread.ThreadState == System.Threading.ThreadState.Running)
                thread.Abort();

            ToolStripButton t = (ToolStripButton)sender;
            if (pops == null || pops.Count == 0)
                GenerateFounderPopulation(null, null);

            foreach (POP p in pops)
                if (p.v % 2 == 1)
                {
                    MessageBox.Show("Can not simulate odd ploidy.", "Error");
                    runstate = runstates.notstart;
                    return;
                }

            NUM_REPRODUCE = int.Parse(t.Text);
            NUM_REPRODUCE_START = pops[0].generation;
            if (thread != null) thread.Abort();

            if (APP2)
                ReproduceGenerationsSub();
            else
            {
                thread = new Thread(new ThreadStart(ReproduceGenerationsSub));
                toolStripProgressBar1.Maximum = NUM_REPRODUCE;
                toolStripProgressBar1.Value = 0;
                thread.Start();
            }
        }

        public void ReproduceGenerationsSub()
        {
            runstate = runstates.simulating;
            for (int i = 0; i < NUM_REPRODUCE; ++i)
                foreach (POP p in pops)
                    p.ReproducePopulation(grnd);
            LOC[][] lo = new LOC[pops.Count][];
            double[] we = new double[pops.Count];
            for (int i = 0; i < pops.Count; ++i)
            {
                pops[i].CountAlleles();
                lo[i] = pops[i].loc;
                we[i] = pops[i].v * pops[i].n;
            }
            GST = GetGst(lo, we);
            runstate = runstates.simulated;
        }

        private void ReproduceGst(object sender, EventArgs e)
        {
            if (runstate == runstates.simulating)
                return;

            if (thread != null && thread.ThreadState == System.Threading.ThreadState.Running)
                thread.Abort();

            if (pops == null || pops.Count == 0)
                GenerateFounderPopulation(null, null);

            foreach (POP p in pops)
                if (p.v % 2 == 1)
                {
                    MessageBox.Show("Can not simulate odd ploidy.", "Error");
                    runstate = runstates.notstart;
                    return;
                }

            NUM_REPRODUCE = 1000000;
            NUM_REPRODUCE_START = pops[0].generation;
            if (thread != null) thread.Abort();
            thread = new Thread(new ThreadStart(ReproduceGstSub));
            toolStripProgressBar1.Maximum = NUM_REPRODUCE;
            toolStripProgressBar1.Value = 0;
            thread.Start();
        }

        public void ReproduceGstSub()
        {
            runstate = runstates.simulating;
            LOC[][] lo = new LOC[pops.Count][];
            double[] we = new double[pops.Count];
            for (int i = 0; i < pops.Count; ++i)
            {
                lo[i] = pops[i].loc;
                we[i] = pops[i].v * pops[i].n;
            }
            while (true)
            {
                foreach (POP p in pops)
                    p.ReproducePopulation(grnd);
                for (int i = 0; i < pops.Count; ++i)
                    pops[i].CountAlleles();
                GST = GetGst(lo, we);
                if (GST >= GST_TERMINAL)
                    break;
            }
            runstate = runstates.simulated;
        }

        private void UpdateFeedBack(object sender, EventArgs e)
        {
            switch (FeedBackFreqBox.Text)
            {
                case "per 1 iter": DRAW_FREQ = 1; break;
                case "per 2 iter": DRAW_FREQ = 2; break;
                case "per 5 iter": DRAW_FREQ = 5; break;
                case "per 10 iter": DRAW_FREQ = 10; break;
                case "per 20 iter": DRAW_FREQ = 20; break;
                case "per 50 iter": DRAW_FREQ = 50; break;
                case "per 100 iter": DRAW_FREQ = 100; break;
                default: DRAW_FREQ = int.MaxValue; break;
            }
            GST_TERMINAL = double.Parse(GstBox.Text);
            SaveFile();
        }

        private void APP1Func()
        {
            APP1 = true;
            //APP1  v k  n    L LOOP  1000
            int v = int.Parse(ARGS[2]);
            int k = int.Parse(ARGS[3]);
            int n = int.Parse(ARGS[4]);
            int l = int.Parse(ARGS[5]);
            int loop = int.Parse(ARGS[6]);
            double s = double.Parse(ARGS[8]);

            if (ARGS[0] == "APP1")
            {
                ARGS[0] += "_";
                APPLOOP = loop;
                Seedbox.Text = "";
                SimDioeciousBox.Checked = false;
                SimFemaleRatioBox.Value = 0.5m;
                SimSelfingRateBox.Value = (decimal)s;
                SimSampleRatioBOx.Value = 1m;
                SimBetaBox.Value = k == 3 ? 0m : 0.05m;
                SimFalseAlleleRateaBox.Value = 0.05m;
                SimMaxFalseAllelesBox.Value = 2m;
                SimDRBox.SelectedIndex = s > 0.00001 ? 1 : 5;//PES

                FeedBackFreqBox.SelectedIndex = 7;
                MaxDiffAssignBox.Text = "0.0001";
                MaxIterationAssignBox.Text = "1";
                MaxDiffFreqBox.Text = "0.00001";
                MaxIterationFreqBox.Text = "50";
                MaxDiffSimplexBox.Text = "0.00001";
                MaxIterationSimplexBox.Text = "200";
                DrBox.SelectedIndex = s > 0.00001 ? 1 : 5;//PES
                UpdatePrioriBox.Checked = false;
                NullBox.Checked = true;
                BetaBox.Checked = k != 3;
                SelfingBox.Checked = s > 0.01;
                FalseAlleleRateBox.Value = 0.05m;
                MaxFalseAllelesBox.Value = 2m;
                ThreadBox.Value = 1m;

                for (int i = 1; i < MAX_PLOIDY; ++i)
                {
                    chbox[i].Checked = false;
                    numbox[i].Value = 1m;
                }
                chbox[v].Checked = true;
                UpdateParameters();
            }
            APPLOOP = loop;
            if (File.Exists("APP1\\" + ARGS[1] + ".txt"))
            {
                for (; ; )
                {
                    try
                    {
                        APPLOOP = loop - File.ReadAllLines("APP1\\" + ARGS[1] + ".txt").Length;
                        break;
                    }
                    catch
                    {
                    }
                }
            }

            if (APPLOOP <= 0)
                Environment.Exit(0);

            grnd = new Random();

            POP tpop = new POP(v, k, n, l);
            if (tpop.n <= 1 || tpop.n > MAX_INDS)
            {
                MessageBox.Show("Number of individual out of range!", "Error");
                return;
            }

            pops = new List<POP>();
            pops.Add(tpop);
            pops[0].APP1Sub(grnd, true);
            pops[0].CountAlleles();
            StringBuilder w = new StringBuilder();
            pops[0].WriteHeader(w);
            pops[0].WritePhenotypes(grnd, w);

            //estimate
            if (runstate == runstates.running)
                return;

            PicBox.Image = null;
            CURRENT_ASSIGNMENT_DIFF = 1;
            CANDIDATE_PLOIDY = new List<int>();
            CANDIDATE_PLOIDY.Add(v);
            MAX_PLOIDY_USED = CANDIDATE_PLOIDY[CANDIDATE_PLOIDY.Count - 1];
            if (thread != null) thread.Abort();
            thread = new Thread(new ThreadStart(Inference));
            toolStripProgressBar1.Maximum = (int)(-Math.Log10(MAX_DIFF_ASSIGN) * 1000) + FINAL_TICK;
            toolStripProgressBar1.Value = 0;
            PHENO_INPUT = w.ToString();
            //SaveFile(); PhenotypeBox.Text = 
            runstate = runstates.running;
            thread.Start();
        }

        public void APP1Write()
        {
            LOC[] est = all.loc2[CANDIDATE_PLOIDY[0]];
            LOC[] ori = pops[0].loc;

            double r_null = 0, r_vis = 0, b_null = 0, b_vis = 0, r_rs = 0, b_rs = 0, r_s = 0, b_s = 0, r_beta = 0, b_beta = 0, nvis = 0;
            int L = ori.Length;
            int vl = 0;
            for (int l = 0; l < L; ++l)
            {
                if (est[l].allele.Count + (CONSIDER_NULL ? 1 : 0) <= 2)//monomorphic
                    continue;
                vl++;
                double d1 = 0;
                if (est[l].allele.ContainsKey(NULL_ALLELE))
                    d1 = est[l].allele[NULL_ALLELE] - ori[l].allele[NULL_ALLELE];
                else if (ori[l].allele.ContainsKey(NULL_ALLELE))
                    d1 = -ori[l].allele[NULL_ALLELE];
                else
                    d1 = 0;
                if (!double.IsNaN(d1))
                {
                    r_null += d1 * d1;
                    b_null += d1;
                }

                double rvis = 0, bvis = 0;
                foreach (int a in est[l].allele.Keys)
                {
                    if (a == NULL_ALLELE) continue;
                    double d2 = est[l].allele[a] - ori[l].allele[a];
                    if (!double.IsNaN(d2))
                    {
                        rvis += d2 * d2;
                        bvis += d2;
                    }
                }

                r_vis += rvis;
                b_vis += bvis;
                nvis += ori[l].allele.Count - (CONSIDER_NULL ? 1 : 0);
                d1 = ori[l].rs - est[l].rs;

                if (!double.IsNaN(d1))
                {
                    r_rs += d1 * d1;
                    b_rs += d1;
                }

                d1 = ori[l].beta - est[l].beta;
                if (!double.IsNaN(d1))
                {
                    r_beta += d1 * d1;
                    b_beta += d1;
                }
            }

            double d3 = ori[0].s - est[0].s;
            if (!double.IsNaN(d3))
            {
                r_s += d3 * d3;
                b_s += d3;
            }

            //p  k  n  r_null b_null r_vis b_vis
            int k = int.Parse(ARGS[3]);
            string re = 
                ARGS[1] +"\t" +
                ARGS[2] + "\t" +
                ARGS[3] + "\t" +
                ARGS[4] + "\t" +
                ARGS[5] + "\t" +
                ARGS[6] + "\t" +
                ARGS[7] + "\t" +
                ARGS[8] + "\t" +
                r_null.ToString(DECIMAL) + "\t" + /*Nrep * L*/
                b_null.ToString(DECIMAL) + "\t" +
                r_vis.ToString(DECIMAL) + "\t" +  /*Nrep * L * K'*/
                b_vis.ToString(DECIMAL) + "\t" +
                r_rs.ToString(DECIMAL) + "\t" +   /*Nrep * L*/
                b_rs.ToString(DECIMAL) + "\t" +
                r_beta.ToString(DECIMAL) + "\t" + /*Nrep * L*/
                b_beta.ToString(DECIMAL) + "\t" +
                r_s.ToString(DECIMAL) + "\t" +    /*Nrep*/
                b_s.ToString(DECIMAL) + "\t" +
                nvis + "\t" +
                vl + "\r\n";

            for (; ; )
            {
                try
                {
                    File.AppendAllText("APP1\\" + ARGS[1] + ".txt", re);
                    break;
                }
                catch { }
            }

            return;
        }
        
        private void APP2Func()
        {
            APP2 = true;
            int id = int.Parse(ARGS[1]);
            int k = int.Parse(ARGS[2]);
            int n = int.Parse(ARGS[3]);
            int L = int.Parse(ARGS[4]);
            int loop = int.Parse(ARGS[5]);
            double fst = double.Parse(ARGS[6]);
            double py = double.Parse(ARGS[7]);
            double s = double.Parse(ARGS[8]);

            if (ARGS[0] == "APP2")
            {
                timer1.Interval = 300;

                APPLOOP = loop - 1;
                ARGS[0] += "_";
                //APP2	id	k	n	l	loop	Fst	Py	s
                //0     1   2   3   4   5       6   7   8
                Seedbox.Text = "";
                SimDioeciousBox.Checked = false;
                SimFemaleRatioBox.Value = 0.5m;
                SimSelfingRateBox.Value = decimal.Parse(ARGS[8]);
                SimSampleRatioBOx.Value = (decimal)(double.Parse(ARGS[3]) / 1000.0);
                SimBetaBox.Value = 0.05m;
                SimFalseAlleleRateaBox.Value = 0.05m;
                SimMaxFalseAllelesBox.Value = 2m;
                SimDRBox.SelectedIndex = 5;

                FeedBackFreqBox.SelectedIndex = 7;
                MaxDiffAssignBox.Text = "0.001";
                MaxIterationAssignBox.Text = "100";
                MaxDiffFreqBox.Text = "0.001";
                MaxIterationFreqBox.Text = "10";
                MaxDiffSimplexBox.Text = "0.001";
                MaxIterationSimplexBox.Text = "20";
                DrBox.SelectedIndex = 3; // PES 0.25
                UpdatePrioriBox.Checked = false;
                FalseAlleleRateBox.Value = 0.05m;
                MaxFalseAllelesBox.Value = 2m;
                ThreadBox.Value = 1m;

                grnd = new Random();
                chbox[2].Checked = chbox[4].Checked = chbox[6].Checked = chbox[8].Checked = chbox[10].Checked = true;
                chbox[1].Checked = chbox[3].Checked = chbox[5].Checked = chbox[7].Checked = chbox[9].Checked = false;
            }

            APPLOOP = loop;
            if (File.Exists("APP2\\" + ARGS[1] + ".txt"))
            {
                for (; ; )
                {
                    try
                    {
                        APPLOOP = loop - File.ReadAllLines("APP2\\" + ARGS[1] + ".txt").Length;
                        break;
                    }
                    catch
                    {

                    }
                }
            }

            if (APPLOOP <= 0)
                Environment.Exit(0);

            this.Text = "APP2 " + ARGS[1] + " " + APPLOOP;
            APP2_STAGE = 0;

            double[] pr = new double[k];
            double[] pr2 = new double[k];
            pr[0] = py * (1.0 / fst - 1);
            for (int i = 1; i < k; ++i)
                pr[i] = (1.0 - py) * (1.0 / fst - 1) / (k - 1);

            StringBuilder sb = new StringBuilder();

            for (int p = 2; p <= 10; p += 2)
            {
                string[,] fre = new string[k * 2, L];
                for (int l = 0; l < L; ++l)
                {
                    GetRDirichlet(grnd, pr, pr2);

                    fre[0, l] = "Null";
                    fre[1, l] = pr2[0].ToString("F8");
                    for (int i = 1; i < k; ++i)
                    {
                        fre[i * 2, l] = (i + 1).ToString();
                        fre[i * 2 + 1, l] = pr2[i].ToString("F8");
                    }
                }

                sb.Append("ploidy\t" + p + "\tninds\t1000\r\n");
                for (int l = 0; l < L; ++l)
                    sb.Append("loc" + (l + 1).ToString() + "\t\t");
                sb.Remove(sb.Length - 2, 2);
                sb.Append("\r\n");

                for (int i = 0; i < k; ++i)
                {
                    for (int l = 0; l < L; ++l)
                        sb.Append(fre[i * 2, l] + "\t" + fre[i * 2 + 1, l] + "\t");
                    sb.Remove(sb.Length - 1, 1);
                    sb.Append("\r\n");
                }
            }
            SimParBox.Text = sb.ToString();
            GenerateFounderPopulation(null, null);
            Reproduce10Button.Text = "15";
            ReproduceGenerations(Reproduce10Button, null);

            APP2_MODEL = 0;
            BetaBox.Checked = false;
            NullBox.Checked = false;
            SelfingBox.Checked = false;

            APP2_STAGE = 1;
        }

        private void SaveFile(object sender, SplitterEventArgs e)
        {
            SaveFile();
        }

        private string splitstr(string o, string sp)
        {
            return o.Substring(0, o.IndexOf(sp));
        }

        private void App3(object sender, EventArgs e)
        {
            PhenotypeBox.Text = @"Ind	Ploidy	Ox02	Ox15	Ox29	Ox07	Ox32	Ox42	Ox31
2_43		236	135,137	230	125,139	236,242		115,123
2_44		239,257	141,149	230,242	125	238	100,104	117,123
2_45		239,257	139,143	230,240	129,137	232	100,104	109
2_46		239	141	230,238	131	232	100,104	119
2_47		239	143,149	230,240	131	238	96,100	119
2_48		242	141,145	230	127,129	232	100,104	119
2_49		239	139,141	230	129	232	100,104	117,123
2_50		242,257	141,143	230	127,131	232	100	117,121
2_51		239,242	141,143	230	129,131	232,238	100,104	115,123
2_52		239,257	143,145	230	127,129	232,236	100,104	117
2_53		239,242	137,141	230,240	131	232,242	100,104	117,123
2_54		239	141	230	127,129	232	100,104	117
2_55		239	139,147	230	129,157	232,238	100,104	111,117
2_56		242	141	230	131	232	100,104	121
2_57		239	137,141	230	129	232,242	98,104	113,119
2_58		239	139,141	230,238	123,125	232	100,104	117
2_59		239	139,141	230	125,129	238		115,117
2_60		242	147	230	129	232,234	100,104	123
2_61		239,242	141	230,242	127	238	100,104	115,119
2_62		242	147	230	129	232,234	100,104	123
2_63		242	141,143	230,240	127,137	232	100,104	117
2_64		239	141,143	230	125,127	238	100	109,117
2_65		239	143		125,127	238	100	
2_66		239	137,147	232	125	238	100	109,115
2_67		239	141,145	230	125	238	100	117
2_68			139,143	230	127,129	238	100	117
2_69		239	141,143	230	127	238	100	117,119
2_70		239	139,141	230	127	238	100	117
2_71		239	141,145	230	125	238	100	109
2_72		239	141	230	127	232	100,104	117
2_73		239	137,139	232	125,131	238	100,104	113,117
2_74			137,143	230	125,129	238	100	115
2_75		242	139,143	230	125	238	100	117
2_76		242	141,143	230	125,131	238	100	117
2_77		242	139	230	147	238	100	113
2_78		239	141,165	232	125	232	100	109,117
2_79			139,145	230	125,127	236,242	98	117
2_80			137,139	230	125	232	100,104	115
2_81		242	143,145	230	125,127	232,238	100	117
2_82		242	143	230	127	238	100	109
2_83			141	230	125	238	100	117
2_84			139,145	230	125	232,238	100	113,117
4_10		239	139,145,147	228,230,232	123,125,131	238,242	100,104	117
4_100		239,245,257	141	230,232,236,240	125,129	236	100,102,104	113,119,123
4_101		242,245	141	230,236,238	125	236,240	100,102,104	119,123
4_102		239,242,245	141	228,230,238	127,129,141	236	100,102	117,119
4_103		239,245,251	141	228,230,234,238	127,131,141	236,238	100,102	113,117,119
4_104		245	141	234,236,242	129,135,139	232,236	100,102,104	117,119
4_105		239,245,248	141	236,238,240	125,131	236,238	100,102	113,117,119
4_106		239,245	141	232,240	127,133	236,240	100,104	115,123,125
4_107		245,257	141,145	232	129	232,236	100,102,104	113,119
4_108		245,257	139	230,232,238	129	240	100,102,104	113,117,119
4_109		239	141,143	230,234,238	133,153	236	100,102,104	113,117,125
4_11		239,242,251,257	139,141	230,232	125,127,131	242	100,104,108	115
4_110		239	141	230,238	129,133	234	100	113,115
4_111		245	137,141	232,234,240	129,131	232	100	117,119,121,125
4_112		242,248,260	141	230	127,129,133	232,236,240	100,102,104	117,121,123
4_113		239,245	137,141	230,234	125,127,133	240	100,102,104	113,117,119,123
4_114		239,242	141,145	230,232,236,238	125,133,135,153	238	100,102,104	113,115,119
4_115		257	141	232,234,238	123,127	238	98,100	117,121
4_116		242,245	141	230,240	129,133	236	100,104	113,117,121,123
4_117		242	141,145	232,240	127,133	236,238	100,104	113,121,123
4_118		242,248,260	141	230,234,238	123,133	236	100,104	115,117,121
4_119		242,248	139,143	230,232,234	127,131,133	232	100,102,104	113,117,123
4_12		239,257	139,141,143,145	228,230	123,131	238	100,102	113,117,119
4_120		242,245	137,141,145	234,238	133,149	232,236	100,102,104,106	115,119,123,125
4_121		242	141,143	230,234,238	129,133	232,240	100,102	113,117,119,121
4_122		245,257	141,145,169	230,232,234	129,133	236,238,240,242	100,102,104,110	115,119,121
4_123			139,141	230,238	127,131,133,135	236	100,104	113,119,123
4_124		242,248	139	230,238	129,133	236,238	100,102,104	113,115,117,123
4_125		242,245,260	135,139	230,234,238	129,139	238	100,102,104	113,115,117,121
4_126		242,245,248,260	139,143	230,234,238	123,127,129	232,234,238	100,104	113,117,123,125
4_127		239,242	141,143	230,238	123	236,238	100,102	113
4_128		239,257	139,141	230,238	127,129,137	238	100	115,117,119
4_129		239	139,151	228,230	127,129	234,236,240	100	109,113,115,119
4_13		239	139,141,145	228,230,232	125	238	100,104,108	113,115,117
4_130		245,257	149,169	230,238	127,137	232,234,238	100	113,121
4_131		242,245	141,143,149	230,238	127,129,137	232,234	100	113,117,121
4_132		239,245	141,143,149	230,238	129,137	232,234,238	100	113,119
4_133		242,245,257	135,141,147	228,230,240	127,137	234	100	113
4_134		242,245,257	135,139,143,147	230,238	127,129	234,238	100,104	113,117,121
4_135		245	137,141,149,171	230,238	127,129,137	234,238	100,104	113,117,121
4_136		245,257	141,143,149	230,238	127,133,135		100	109,113,115,119
4_137		245	135,139,151	228,230,238	127,133	236,238	100,102	113,119,121
4_138		242,245,248,260	139,147,169	230,238	127,137	232,234	100,104	113,117
4_139		242,245,248	135,141,147	230,238	127,137	232,234,238	100,102	113,117,121
4_14		254,257	139,145	228,230	125,131	232,238,246	100,104	117
4_140		245,248	135,139,147,169	230,238	127,129	234,238	100	113,117,121
4_141		239	139,141	230	129	234,238	100	115,117,119
4_142		242	141,143,149,153	238	127,129	234,236	100,102	113,115,119
4_143		242,248	139,141	230,238	125	236,240	100	113,115,119
4_144		242	139,151	230,234	127,129	234,238	100	113,119,121
4_145		242,248	139	230,238	127,137	238	100	115,117,119,121
4_146		245	139,151	230,238	127,135	236,238	100,102,104	113,115,121
4_147			139,141	230,238	123,127,129,135	232,238	100,102,104	113,115,119
4_148		239	137,141	230,236,238	121,127,133	232	100,102,104	115,119,121
4_149		242	139	230,234	127,139	238	100,102,104	115,119
4_15		257	139,141	228,230	125,131	232,238,242	100,102	113,115,117
4_150		239	139	230,236	127,133,135	234,238	100,102,104	117,121,125
4_151		236,239	143	230,236	127,133,151	236	100,104	115,117,121,125
4_152		239,242	141,143,145	230,236	127	232,234,240	100,104	111,115,121
4_153		242	141	230,236	127,135	240	100,104	115,117
4_154		239,242,245	139,141,155	230,238	127,133	240	100,104	109,111,115
4_155		239,245	139,145	226,230,238	127,129	232,238	100,102,104	113,115,125
4_156		239,242	141,143	226,230,238	127,141,157	232,238	100,102,104	113,115
4_157		239,242	141	230,238	129,133	232,234,238	100,102,104	117,121,125
4_158		242	139	230,232,238	129,133,141	236,240	100,102,104	113,115,119
4_159		242,245	139	230,238	129	238	100,104	113,115,117
4_16		239	139,141	230	123,125,131	238,246	100	113,117
4_160		239,242	139	230,240	127,143	232,238	100,104	115
4_161		242,260	139	230,236	127,129	234	100,104	119,121
4_162		239,257	141,157	228,232,236	123,125,127,133	238	100,102,104	115,125
4_163		239,242	141	230,234,236	125,133,155	232	98,100	115,119,121
4_164		239,242,245	139,143	232,234,238	129,135	232	100,104	113,115,117,119
4_165		242	139,143,155	230,232,236	121,127,131	234	100,102,104	117,119
4_166		242	139,155,165	230,240	129	232	100	115,117
4_167		239,242,245	139,143,151	230,232	127,135	232,238	100,104	113,115,119,123
4_168		236	141	230,238	129	240	100,102	115,117,119
4_169		239	139	234,238	125	242	100,102,104	113,115,119
4_17		239,251,257	137,139,141,145	228,232,240	131	238	100	117
4_170		242	141	230,238	127	238	100,102,104	115,117,119
4_171		239,257	141	230,234,240	125,127,133	238,242	100,102	113,119
4_172		239,257	141	230,234,240	129	236	100,102	115,117,119
4_173		239,242,257	139,141	230,234,240	129,135	238,242	100	113,119
4_174		242	139,141	232,240	127,133,147		100,102	115,119
4_175		239	139,143,145	230	121	232,236,238	96,100	113,117,119
4_176		239	139,145,155	230,238	123,141	232,236,238	100,102,106	113,117,119
4_177		236	141	230,238	127,129	236,242	100,102,104	113,115,119
4_178		242	141,155	230,238	125,135	238	100,102	113,117,119
4_179		239,257	141,145	230,234	129,143	238	100,102	113,115,117,119
4_18		242,260	139,141	234	123,125	234	98	115,117
4_180		257	139,141	230,238	127,133	238	100,102,104	113,115,117,119
4_181		239,242	139,141	230,234	125,133	238,242	100,102,104	117,119
4_182		239,257	139,141	230,234,238	125,133	238	100,102,104	113,119
4_183		239,257	139,141	230,238	123,125,141,143	240,242,250	100,102,104	113,115,117
4_184		239	137,139	230,238	129	242	100	113,115,119
4_185		239	139,141	230,234	123,125,133	238	100,102	113,115,117,119
4_186		239,257	139,141	230,232,234	129,133,143	238,242	100,102	117,119
4_187		239	139,141	230,240	123,125,133	238,242	100,104	113,115,117,119
4_188		239	137,139	240	125,133,143	238,242	100,102	115,119
4_189		242,257	137,139	230,232,236	125,129,135	232,238	100	113,115,117
4_19		239	137,139,145	226,230	125	238	100,104	111,113,115,117
4_190		257	137,139	230,232,238	135	232,238	100	113,117
4_191		239,242	141,143	230,238	135	232,238	100	113,117
4_192		257	135,137,141,143	230,232	125,131,135	232,238,242	100,104	117
4_193		257	137,139,141	230,236,238	125,129	238	100,104,108	113,117
4_194		260	137,139,141	230,234,238	125,129,135	232,238	100,108	113,117
4_195		260	137,139,141	230,236,238	125,129,135	232,238	100,108	113,117
4_196		254	139	230,232,238	135	238	100	109,113,115,117
4_197		257	137,139	230,238		234,240,244	100,108	113,117,121
4_198		257	137,139	230,238	123,135	240	100	113,115
4_199		254,260	137,139	230,236	125	238,246	100,104	113,115
4_2		257	139,147	228,230,238	121,123,125	232,238,242	100,104	113,117
4_20		260	139,147	228,236,238	119,125	232,238	100,104	117
4_200		260	137,139	230,232,238	123,125,131,135	238,246	100,104	113,117
4_201		245,260	137,139	230	125,135	232,238	100,108	115,117
4_202		260	141	230,238	123,135	238,242	100,106	113,115
4_204		257	137,139,143	230,232,238	125,127,133,137	238	100	117
4_206		260	137,139	230,234,238	127,135	238	94,100,102	111,117
4_208		257	137,141,143	228,232,236,238	125,137	238	100,104	113,115,117
4_21		242	139	228,230	119,123,127	238,240	100,104	117
4_219		239,257	141,143	230,236	125,127,135	238	100,104	117,119
4_22		239	139,141,145	228,230,238	121,125,129	232,238,246	100,104	117
4_220		239,257	141,143	230,236	125,127,135	238	100,104	117,119
4_221		239,257	141,143	230,236	125,127,135	238	100	117,119
4_222		239,257	141,143	230,236	125,127,135	238	100,104	117,119
4_223		239,257	141,143	230,236	125,127,135	238	100,104	117,119
4_224		239,257	141,143	230,236	125,127,135	238	100,104	117,119
4_225		239,257	141,143	230,236	125,127,135	238	100,104	117,119
4_226		239,257	141,143	230,236	125,127,135	238	100,104	117,119
4_227		239,257	141,143	230,236	125,127,135	238	100,104	117,119
4_228		239,257	141,143	230,236	125,127,135	238	100,104	117,119
4_23		239,257	137,139	228,230,238	125	238	100,102	113,117
4_239		239,257	139,143	230,234	127,135	238	108,110	117,119
4_24		260	139,141,143	228,230,238	125,135,139	238	100,104	113,117
4_240		239	139,143	230,234	125,127,135	238	100,102	117,119
4_241		242,260	141,143	230,234	125,127,135	238	100,104	117,119
4_242		257	139,143,145,147	230,238	125,127,135	232,238,250	100,104	115,119
4_243		257	141,143,147	230	125,127,135	238	100,104	117,119
4_244		239,257	141,143	230	125,127,135			119
4_245		239,257	141	228,230,238	125,127,135	238	100,104	113,115,119
4_246			139,143,147	228,230,236,238	125,135	238,248	100,104	113,115,117,119
4_247		239	139	230,238	125,127	238,248	100,104	117
4_248		260	139	230,238	125	238	100	113,115,117
4_249		260	141,147	228,230,234,238	125,127	232,238,248	100,104	113,115,117,119
4_25		239,257	139,141,143	228,230,236,240	125,139	238,244	100,102,104	113,115,117
4_250		257	141,147	228,234,238	125,127	232,238,248	100,104	113,115,117
4_251		257	141,145	230,234,236	125,127,135	238	100,104	113,115,117
4_252		239,257	141,143	230,238	125,127,135	238,248	100,104	113,117,119
4_259		239,257	141	230,232,236	125,127	238	100,104	117,119
4_26		257	137,139	230,232,238	127,139,157	232,238	100	115,121
4_27		242,260	137	228,230,238	125,139	238	100,104	113,115,117
4_270		239,257	141,143	230,234	125,127,135	238	100,104	117,119
4_271		239,257	141,143	230,234	125,127,135	238	100,104	117,119
4_272		239,257	141,143	230,234	125,127,135	238	100,104	117,119
4_273		239,257	141,143	230,234	125,127,135	238	100,104	117,119
4_274		239,257	141,143	230,236	125,127,135	238	100,104	117,119
4_275		239,257	141,143	230,234	125,127,135	238	100,104	117,119
4_276		239,257	141,143	230,234	125,127,135	238	100,104	117,119
4_277		239,257	141,143	230,234	125,127,135	238	100,104	117,119
4_278		239,257	141,143	230,234	125,127,135	238	100,104	117,119
4_279		239,257	141,143	230,234	125,127,135	238	100,104	117,119
4_28		257	139,141	228,230,238	125,127,139	236,238	100	113,117
4_29		242	137,139	228,230,238	125	238	100,102,104	117
4_290		257	139,143,145	230,232,236,238	125,137	238	100	113,115,117
4_291		257	139,143,145	230,232,236,238	125,137	242	100,104	113,115,117
4_292		257	139,143,145	230,232,236,238	125,137	232	100,104,106	113,115,117
4_293		239,257	139,141	228,238	125,135	238	100,104,108	115,119
4_294		239,257	139,141,145	232,238	125	238	100,104	115
4_295		239,257	139,141	228,238	125,135	238	100,104,108	115,119
4_3		239,257	139,141,143	228,238	123,125,131	238,244	100,102,104	113,115
4_30		257	141,143	232,234,236	127,129,139	236,238,244	104,108	113,117
4_304		257	139,141	228,238	125,135	238	100,104,108	115,119
4_31		239,257	141,143	228,230,232,236	125,129	232,236,238	100,104	115
4_313		257	139,141	228,230,236	125,129,133	238,240	100,104	113,115,117
4_314		257	139,141	228,230,236	127,129,133	232,238,240	102,106	113,115,117
4_315		257	139,141,143	228,230,236	125,129,133	238,240	100,104	113,115,117
4_316		257	141	230,236	125,129,133	238,240	100,104	113,115,117
4_317		257	141	230,236	125,129,133	238,240	100,104	113,115,117
4_318		257	141	230,236	125,129,133	238,240	100,104	113,115,117
4_319		257	141	230,236	125,129,133	238	98,102	113,115,117
4_32		239,257	139,153,155	230,234,236,238	125	238	100,102,104	115,117
4_329		242	141	228,230,236	125,129,133	238	100,104	113,115,117
4_33		242	139,141,143	230,232,238	125,127	238	100,104	115
4_330		239	139	228,230,236	125,129,133	238	100,104	113,115,117
4_331		239	141	228,230,234,236	125,129,133	238	100,104	113,115,117
4_332		257	139	230,236	125,129,133	238,240	100,104	113,115,117
4_333		257	139	230,236	125,129,133	238,240	98,102	113,115,117
4_334		257	141	230,236	125,129,133	238,240	98,102	113,115,117
4_335		257	141	230,236	125,129,133	238,240	98,102	113,115,117
4_336		257	139,141	230,232,236,238	125,129,133	238	98,102	113,115,117
4_337		260	139	228,230,236	125,129,133	238,240	100,104	113,115,117
4_338		260	141	228,230,236	125,129,133	238,240	100,104	113,115,117
4_34		242,260	137	228,230,232,238	125,127	238	100,104	113,117
4_342		257	141	228,230,236	127,131,135	232,238	100,104,108	
4_343		257	141	228,230,236	125,129,133	232,238	100,104,106	
4_345		239,257	141,143		125,137	238	100,104	
4_346		239,257	141,143	230,234	125,127,135,137	238	98,102	
4_347		239,257	141,143	230,234	125,127,135,137	238	100,104	
4_35		242,260		228,230	125,131,139	232,238,244	100,102	113,115
4_350		257	139,143,145	228,232,236,238	125,127,135,137	238	100,104	113,115,117
4_351		260	139,141,147	228,230,238	127,135	238,248	100,104	113,117,119
4_352		242,260	141,143,147	228,232,236,238	125	238	100,104	113,115,117
4_353		242,260	141,143	230,238	127,135	238	100,104	117,119
4_354		260	141	230,234,238	125,127	232,238	100,104	115,117
4_355		242,260	141,143	228,230,236	125,135	232,238,248	100,104	115,117,119
4_356		242	141	230,234,238	125,127,135	238	100,104	117
4_357		242,260	141,143	230,236	125,127,135	238	100,104	117,119
4_358		239,257	141,143	230,234,238	125,127,135	238	102,104	115,117,119
4_359		239,242	137,141,143,147	230,234	125,127,135	238	100,104	117,119
4_36		242,260	137,139,153	228,230,232	125,139	238,244	100,102,104	113,115,117
4_360		239	137,139,141	230,234,238	125,127	232,238	100,104	113,117,119
4_361		260	141,143	228,230,234	125,127,135	232,238	100,104	115,117,119
4_362		260	141,143,145	230,238	125,127,137	238	100,104	115,117,119
4_363		260	139,141,143	230,232,238	125,127	238	100,104	113,115,119
4_364		257,260	141,143,147	228,230,236,238	125,127	232,238,248	100,104	113,115,117,119
4_367		242,254,257	137,139,143,147	230,236,238	125,127,129	232,238	100,104	115,119
4_37		257	139,141,143	228,230,232	125,129	238	100,102,104	113,115,117
4_38		239,257	139,141	228,230,240	125	238	100,102,104	113,117
4_39		242,260	137,139,143,169	228,230	125	238	100	115,117
4_4		239,242,257	139,147	230,238	125	238,242	100,104	117
4_40		242,260	137,139,141,165	228,232,238	127,131,135	238	100	115
4_41		242,260	137,139,141,165	228,232,238	127,131,135	238	100	115
4_42		260	137,139	228,230,238	139	238	100	113,115,117
4_5		239	139,141,145	230,238	125,131	238,242,246	100,106	113,117
4_6		239	139	230,232	123,127	238	100,102,104	113,117,119
4_7		242	139,141,147	228,230	125,131	238,242	100	113,117
4_8		257	139	230,232,238	119,125,131	238	100	113,117,119
4_85		239,245,254	141	230,238	125,133	238	100,102,104	111,113,117,119
4_86		245,248,251,257	141,145	230,238	149	236,238,240	100,102	111,113,117,119
4_87		242,245	141	228,230,236	129	240	100,102,104	119,121
4_88		245	141	230,236,238	125,139	236	100	113,119
4_89		248,251	141	230,236	125,129,133	236,238,242	100	119,121
4_9		239,257	139,141,145,147	228,232,238	125,127,131	238,246	100,104	113,117
4_90		242,245,248	141	230,238	131	240,242	100	117,119,121
4_91		242	141	230,234,236,238	131,133,141	236,238	100	117,119,121,123
4_92		242,245	141,143	230,232,238	149	238,244	100	111,117,119
4_93		239,242,245	137,139,141,147	230,236,238	125,139	240,242	100,102,104	117,119
4_94		245	139,141,145	230,234	125,131	242,244	100,102,104	119
4_95		242	141	228,232,236,238	125,131,133	236,238	100,102	115,117,119,121
4_96		248	141	230	125	236,238	100,104,110	117,119
4_97		245	141	230,236,238	125,131,139	236	100,102,104	113,119
4_98		245	141	234,236	125,137	232,236,238	100	117,119,121
4_99		239,257	141	230,236,238	125,131,135	240,242	100,102,104	119,121
5_203		257	137,139	230,236,238	125	240	100	113
5_205		257	137,141,143	228,232,236,238	125	238	100,102	113,115,117
5_207		260	137,141,143	228,232,236,238	125,137	244	100	113,115,117
5_209		257	139,143,145	230,232,236,238	125,137	238	100	113,115,117
5_210		257	139,143,145	230,232,236,238	125,137	238	100	113,115,117
5_211		257	137,141,143	230,232,236,238	125,137	238	100	113,115,117
5_212		257	137,141,143	228,232,236,238	125,137	238	100	113,115,117
5_213		257	137,141,143	228,232,236,238	125,137	238	100	113,115,117
5_214		257	137,141,143	230,232,236,238	125,137	238	100	113,115,117
5_215		257	137,141,143	228,232,236,238	125,137	238	100	113,115,117
5_216		257	137,141,143	228,232,236,238	125	238	100	113,115,117
5_217		257	137,141,143	228,232,236,238	125,137	238	100	113,115,117
5_218		254,257	137,141,143	228,232,236,238	125	238	100	113,115,117
5_229		257	139,143,145	232,234,238,240	125,137	238	100,104	113,115,117
5_230		257	139,143,145	228,232,236,238	125,137	238	100	113,115,117
5_231		257	139,143,145	228,232,236,238	125	238	100	113,115,117
5_232		257	139,143,145	228,232,236,238	125	238	100	113,115,117
5_233		257	139,143,145	228,232,236,238	125	238	100	113,115,117
5_234		257	139,143,145	228,232,236,238	125	238	100	113,115,117
5_235		257	139,143,145	228,232,236,238	125	238	100	113,115,117
5_236		257	139,143,145	228,232,236,238	125	238	100	113,115,117
5_237		257	139,143,145	228,232,236,238	125,137	238	100	113,115,117
5_238		257	137,141,143	228,232,236,238	125	238	100	113,115,117
5_253		257	139,143	228,230,238	125,127,135	238	100,104	113,115,117,119
5_254		257	137,143,145	230,238	125	238	100	113,115,117,119
5_255		242,260	141,143	230,234	125,127,135	238	100,104	117,119
5_256		257	139,143,145	228,232,236,238	125	238	100,104	113,115,117
5_257		257	139,143,145	228,232,236,238	125	238	100,104	113,115,117
5_258		239,257	141,143,147	228,230,234,238	125,127	238	100,104	113,115,117,119
5_260		260	137,141,143	230,232,236,238	125,137	238	100	113,115,117
5_261		257	139,143,145	230,232,236,240	125,137	238	100	113,115,117
5_262		260	137,141,143	228,232,236,238	125,137	238	100,104	113,115,117
5_263		260	137,141,143	228,232,236,238	125,137	238	100,104	113,115,117
5_264		260	137,141,143	228,232,236,238	125,137	238	100,104	113,115,117
5_265		260	137,141,143	228,232,236,238	125,137	238	100	113,115,117
5_266		260	137,141,143	228,232,236,238	125,137	238	100	113,115,117
5_267		260	137,141,143	228,232,236,238	125,137	238	100	113,115,117
5_268		260	137,141,143	228,232,236,238	125,137	238	100	113,115,117
5_269		260	137,141,143	228,232,236,238	125	238	100	113,115,117
5_280		257	139,143,145	228,232,236,238	125,137	238	100	113,115,117
5_281		257	139,143,145	228,232,236,238	125	238	100	113,115,117
5_282		257	137,141,143	228,232,236,238	125,137	238	100	113,115,117
5_283		257	137,141,143	232,234,238,240	125,137	238	100	113,115,117
5_284		257	137,141,143	228,232,236,238	125	238	100	113,115,117
5_285		257	137,141,143	228,232,236,238	125,137	238	100	113,115,117
5_286		257	137,141,143	228,232,236,238	125,137	238	100	113,115,117
5_287		257	137,141,143	228,232,236,238	125	238	100	113,115,117
5_288		257	137,141,143	228,232,236,238	125	238	100	113,115,117
5_289		257	137,141,143	228,232,236,238	125	238	100	113,115,117
5_296		260	143,145	228,238	125,135	242	100,104,110	113,115,117
5_297		257	139,141	228,238	125,135	238	100,104,110	113,115,117
5_298		239,257	137,139	228,238	125,135	238	100,104,110	113,115,117
5_299		257	139,143,145	230,232,236,238	125,137	238	100,104	113,115,117
5_300		257	139,143,145	228,232,236,238	125,137	238	100	113,115,117
5_301		257	139,143,145	228,232,236,238	125,137	238	100,104	113,115,117
5_302		257	139,143,145	228,232,236,238	125,137	238	100,104	113,115,117
5_303		257	139,143,145	228,232,236,238	125,137	238	100,104	113,115,117
5_305		239,254,257	139,141	230,232,236,238	127			113,115,117
5_306		257	139,143,145	230,232,236,238	125	238	100	113,115,117
5_307		257	139,143,145	228,232,236,238				113,115,117
5_308		257	139,143,145	228,232,236,238	125,137	238	100	113,115,117
5_309		257	139,143,145	228,232,236,238	125,137	238	100	113,115,117
5_310		257	139,143,145	228,232,236,238	125,137	238	100	113,115,117
5_311		257	139,143,145	228,232,236,238	125,137	238	100	113,115,117
5_312		257	139,143,145	228,232,236,238	125,137	238	100	113,115,117
5_320		239	143	230,234,238,240	125	238	100	113,115,117
5_321		239,257	137,143,145	232,234,238,240	125	238	100	113,115,117
5_322		242,257	137,143,145	228,232,236,238	125	232,238	100,104	113,115,117
5_323		257	139,143,145	228,232,236,238	125,137	238	100	113,115,117
5_324		257	139,143,145	228,232,236,238	125,137	238	100	113,115,117
5_325		257	139,143,145	228,232,236,238	125,137	238	100	113,115,117
5_326		257	139,141,143	228,232,236,238	125,137	238	100	113,115,117
5_327		257	137,141,143	228,232,236,238	125,137	238	100	113,115,117
5_328		257	137,141,143	228,232,236,238	125,137	238	100	113,115,117
5_339		257	139,143,145	228,232,236,238	125,137	238	100,104	113,115,117
5_340		242,245,248,257		228,232,236,238	125,137	238	100	113,115,117
5_341		257	139,143,145	228,232,236,238	125,137	238	100	
5_344		257	139,143,145	228,232,236,238	125	238	100,104	
5_348		257	139,143,145	228,232,236,238	127,129,135,137	232,238	104,108	
5_349		257	139,143,145	228,232,236,238	125,127,135	232,238	100,104	
5_365		257	137,143,145	228,232,236,238	125	238	100	113,115,117
5_366		257	137,143,145	228,232,236,238	125	238	100,104	113,115,117
5_368		257	139,143,145	230,232,236,238	125,137	238	98,102	113,115,117,119
5_369		260	139,143,145	230,232,236,238	125,137	238	98,102	113,115,117
5_370		260	139,143,145	230,232,236,238	125,137	238	98,102	113,115,117
5_371		260	139,143,145	230,232,236,238	125,137	238	98,102	113,115,117
5_372		257	139,143,145	230,232,236,238	125,137	238	100	113,115,117
5_373		257	139,143,145	230,232,236,238	125,137	238	100	113,115,117
5_374		257	139,143,145	230,232,236,238	125,137	238	100	113,115,117
5_375		260	139,143,145	230,232,236,238	125,137	238	100,104	113,115,117
5_376		260	139,143,145	230,232,236,238	125,137	238	100,104	113,115,117
5_377		260	139,143,145	230,232,236,238	125,137	238	100,104	113,115,117
5_378		260	139,143,145	230,232,236,238	125,137	238	100,104	113,115,117
5_379		260	139,143,145	230,232,236,238	125,137	238	100,104	113,115,117
5_380		260	139,143,145	230,232,236,238	125,137	238	100,104	113,115,117
5_381		260	139,143,145	230,232,236,238	125,137	238	100,104	113,115,117";
            File.Delete("APP3\\app3.txt");
            APP3 = true;
            Seedbox.Text = "";

            FeedBackFreqBox.SelectedIndex = 7;
            MaxDiffAssignBox.Text = "0.0001";
            MaxIterationAssignBox.Text = "1000";
            MaxDiffFreqBox.Text = "0.0001";
            MaxIterationFreqBox.Text = "50";
            MaxDiffSimplexBox.Text = "0.0001";
            MaxIterationSimplexBox.Text = "200";
            UpdatePrioriBox.Checked = false;
            ThreadBox.Value = 6m;

            FalseAlleleRateBox.Value = 0.01m;
            MaxFalseAllelesBox.Value = 2m;

            grnd = new Random();
            chbox[2].Checked = chbox[4].Checked = chbox[5].Checked = true;
            chbox[1].Checked = chbox[3].Checked = chbox[6].Checked = chbox[7].Checked = chbox[9].Checked = chbox[8].Checked = chbox[10].Checked = false;
            for (int v = 1; v <= MAX_PLOIDY; ++v)
                numbox[v].Value = 1m;

            APP3_MODEL = 0;
            DrBox.SelectedIndex = 0;
            BetaBox.Checked = false;
            NullBox.Checked = false;
            SelfingBox.Checked = false;
            APP3_STAGE = 1;
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process pexec = new System.Diagnostics.Process();
            pexec.StartInfo.FileName = CDIR + "PloidyInfer User Manual.pdf";
            if (File.Exists(pexec.StartInfo.FileName))
            {
                pexec.StartInfo.Arguments = "start";
                pexec.Start();
            }
        }

        private void NullBox_CheckedChanged(object sender, EventArgs e)
        {
            //if (NullBox.Checked && SelfingBox.Checked && BetaBox.Checked)
                //((CheckBox)sender).Checked = false;
            if (DrBox.SelectedIndex == 5)
                SelfingBox.Checked = false;
            UpdateParameters();
        }

        private void DrModeBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DrBox.SelectedIndex == 5)
                SelfingBox.Checked = false;
            UpdateParameters();
        }

        private void ChBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int v = 1; v < MAX_PLOIDY; ++v)
                numbox[v].Enabled = chbox[v].Checked;
            PreSaveFile();
        }

        private void RunCommands(object sender, EventArgs e)
        {
            //this.ShowIcon = false;
            this.WindowState = FormWindowState.Minimized;
            int ncore = (int)(Environment.ProcessorCount * 1.2);
            if (Environment.ProcessorCount < 13) ncore = Environment.ProcessorCount / 2;
            Random grnd = new Random();
            PROC = new Process[ncore];
            string[] name = new string[ncore];
            DateTime[] time = new DateTime[ncore];

            for (int i = 0; i < ncore; ++i)
            {
                time[i] = DateTime.Now;
                name[i] = "";
            }

            string APP = "";
            for (; ; )
            {
                string[] cmd2 = PhenotypeBox.Text.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
                List<string> cmd = new List<string>();

                for (int i = 0; i < cmd2.Length; ++i)
                {
                    string[] con = cmd2[i % cmd2.Length].Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                    APP = con[0] + "\\";
                    if (!File.Exists(APP + con[1] + ".txt"))
                    {
                        cmd.Add(cmd2[i % cmd2.Length].Replace("\t", " "));
                        continue;
                    }

                    int ncalced = File.ReadAllLines(APP + con[1] + ".txt").Length + 1;

                    if (con[0] == "APP1" && int.Parse(con[6]) > ncalced)
                        cmd.Add(cmd2[i % cmd2.Length].Replace("\t", " "));

                    if (con[0] == "APP2" && int.Parse(con[5]) > ncalced)
                            cmd.Add(cmd2[i % cmd2.Length].Replace("\t", " "));
                }

                if (cmd.Count == 0) break;

                int ll = cmd.Count;
                while (cmd.Count < ncore)
                    cmd.Add(cmd[grnd.Next(ll)]);

                int[] seq = new int[cmd.Count];
                for (int i = 0; i < cmd.Count; ++i)
                    seq[i] = i;
                Permute(seq, grnd);

                int cmdp = 0;
                string path = Environment.GetCommandLineArgs()[0];
                
                while (cmdp < cmd.Count)
                {
                    for (int i = 0; i < ncore; ++i)
                    {
                        this.Text = cmdp + " / " + cmd.Count;
                        if (cmdp >= seq.Length) continue;

                        if (PROC[i] == null || PROC[i].HasExited)
                        {
                            PROC[i] = Process.Start("PloidyInferAPP2.exe", cmd[seq[cmdp++]]);
                            //7PROC[i] = Process.Start(cmd[0][3] == '1' ? path.Replace(".vshost", "") : "PloidyInferAPP2.exe", cmd[seq[cmdp++]]);
                            time[i] = DateTime.Now;
                            Thread.Sleep(1000);
                        }

                        if ((DateTime.Now - time[i]).Minutes >= 25000000)
                        {
                            time[i] = DateTime.Now;

                            StringBuilder sb = new StringBuilder(5120);
                            GetWindowText(PROC[i].MainWindowHandle, sb, sb.Capacity);

                            if (name[i] != sb.ToString())
                                name[i] = sb.ToString();
                            else
                            {
                                while (!PROC[i].HasExited)
                                {
                                    Process.Start("ntsd.exe", "-c q -p " + PROC[i].Id);
                                    Thread.Sleep(1000);
                                    Process.Start("taskkill.exe", "/IM ntsd.exe /f ");
                                    Thread.Sleep(1000);
                                }
                            }
                        }

                    }
                    Thread.Sleep(1000);
                }
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            foreach(FileInfo f in new DirectoryInfo("APP1").GetFiles("*.txt"))
            {
                string[] c = File.ReadAllLines(f.FullName);
                string[] c0 = c[0].Split(new char[] { '\t' }, StringSplitOptions.None);
                for (int i = 0; i < 8; ++i)
                    sb.Append(c0[i] + "\t");
                double[] rmse = new double[5], bias = new double[5];
                double nvis = 0, vl = 0;
                foreach (string b in c)
                {
                    string[] a = b.Split(new char[] { '\t' }, StringSplitOptions.None);
                    if (a.Length < 10) continue;
                    for(int i = 8; i < 17; i += 2)
                    {
                        rmse[(i - 8) / 2] += double.Parse(a[i]);
                        bias[(i - 8) / 2] += double.Parse(a[i + 1]);
                    }
                    nvis += double.Parse(a[18]);
                    vl += 20;// double.Parse(a[19]);
                }
                for (int i = 0; i < 5; ++i)
                {
                    if (i == 1)
                    {
                        rmse[i] = Math.Sqrt(rmse[i] / nvis);
                        bias[i] /= nvis;
                    }
                    else
                    {
                        rmse[i] = Math.Sqrt(rmse[i] / vl);
                        bias[i] /= vl;
                    }
                    sb.Append(rmse[i].ToString("F15") + "\t");
                    sb.Append(bias[i].ToString("F15") + "\t");
                }
                sb.Remove(sb.Length - 1, 1);
                sb.Append("\r\n");
            }
            File.WriteAllText("app1.txt", sb.ToString());


            sb = new StringBuilder();
            foreach (FileInfo f in new DirectoryInfo("APP2").GetFiles("*.txt"))
            {
                string[] c = File.ReadAllLines(f.FullName);
                string[] c0 = c[0].Split(new char[] { '\t' }, StringSplitOptions.None);
                for (int i = 0; i < 8; ++i)
                    sb.Append(c0[i] + "\t");
                double avg = 0;
                foreach (string b in c)
                {
                    string[] a = b.Split(new char[] { '\t' }, StringSplitOptions.None);
                    avg += double.Parse(a[8]);
                }
                avg = avg / c.Length * 100;
                sb.Append(avg.ToString("F8") + "\r\n");
            }
            File.WriteAllText("app2.txt", sb.ToString());
        }

        private void DioeciousBox_CheckedChanged(object sender, EventArgs e)
        {
            if (SimDioeciousBox.Checked == true)
            {
                SimSelfingRateBox.Enabled = false;
                SimFemaleRatioBox.Enabled = true;
            }
            else
            {
                SimSelfingRateBox.Enabled = true;
                SimFemaleRatioBox.Enabled = false;
            }
            UpdateParameters();
        }
        #endregion
    }
}
